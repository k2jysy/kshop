<?php
kt_download_media(2113, 'banner-megamenu', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/12/banner-megamenu.jpg');

kt_download_media(2115, '35', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/35.jpg');

kt_download_media(2116, '36', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/36.jpg');

kt_download_media(2117, '37', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/37.jpg');

kt_download_media(2118, '39', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/39.jpg');

kt_download_media(2119, '47', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/47.jpg');

kt_download_media(2120, '48', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/48.jpg');
