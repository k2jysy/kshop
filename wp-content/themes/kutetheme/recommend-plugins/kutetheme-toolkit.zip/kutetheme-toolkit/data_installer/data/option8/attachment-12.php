<?php
kt_download_media(2076, 'nt_14260.2751431962951', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/nt_14260.2751431962951.jpg');

kt_download_media(2077, 'nt_21123.2841431987953', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/nt_21123.2841431987953.jpg');

kt_download_media(2078, 'nt_21123.8121431987952', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/nt_21123.8121431987952.jpg');

kt_download_media(2080, 'nt_21133.2141431990130', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/nt_21133.2141431990130.jpg');
