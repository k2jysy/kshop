<?php
kt_download_media(2072, '4682anvelop-v-yakali-elbise5504', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/4682anvelop-v-yakali-elbise5504.jpg');

kt_download_media(2073, 'nt_14175.9001431990714', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/nt_14175.9001431990714.jpg');

kt_download_media(2074, 'nt_14175.9401431990713', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/nt_14175.9401431990713.jpg');

kt_download_media(2075, 'nt_14260.41431962953', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/nt_14260.41431962953.jpg');
