<?php
kt_download_media(150, 'blog41', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/blog41.jpg');

kt_download_media(220, 's1', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/s11.png');

kt_download_media(221, 's2', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/s21.png');

kt_download_media(222, 's3', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/s31.png');

kt_download_media(236, 'line5.png', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/revslider/kute-opt12/line5.png');

kt_download_media(241, 'shopnow.png', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/revslider/kute-opt11/shopnow.png');
