<?php
kt_download_media(2241, '18', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/12/18.jpg');

kt_download_media(2244, '20', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/12/20.jpg');

kt_download_media(2245, '21', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/12/21.jpg');

kt_download_media(2272, '22', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/22.jpg');
