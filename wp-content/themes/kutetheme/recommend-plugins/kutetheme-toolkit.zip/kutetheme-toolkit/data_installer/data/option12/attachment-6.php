<?php
kt_download_media(2044, 'bg4.png', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/revslider/kute-opt12/bg4.png');

kt_download_media(2046, '38', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/38.jpg');

kt_download_media(2047, '26', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/261.jpg');

kt_download_media(2048, '58', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/58.jpg');

kt_download_media(2050, '36', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/36.jpg');

kt_download_media(2051, '37', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/37.jpg');

kt_download_media(2054, '18', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/18.jpg');
