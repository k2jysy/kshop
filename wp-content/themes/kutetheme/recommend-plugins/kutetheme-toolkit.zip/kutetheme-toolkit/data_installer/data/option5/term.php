<?php
// Custom term
kt_add_category( 263, '1.6 pixel', '1-6-pixel', 'pa_pixel', '0', '' );

kt_add_category( 259, '10 kilogram', '10-kilogram', 'pa_weight', '0', '' );

kt_add_category( 265, '14 inch', '14-inch', 'pa_inch', '0', '' );

kt_add_category( 260, '2 liter', '2-liter', 'pa_liter', '0', '' );

kt_add_category( 264, '2 pixel', '2-pixel', 'pa_pixel', '0', '' );

kt_add_category( 266, '21 inch', '21-inch', 'pa_inch', '0', '' );

kt_add_category( 261, '3 liter', '3-liter', 'pa_liter', '0', '' );

kt_add_category( 267, '32 inch', '32-inch', 'pa_inch', '0', '' );

kt_add_category( 245, '34', '34', 'pa_size', '0', '' );

kt_add_category( 246, '35', '35', 'pa_size', '0', '' );

kt_add_category( 247, '36', '36', 'pa_size', '0', '' );

kt_add_category( 248, '37', '37', 'pa_size', '0', '' );

kt_add_category( 257, '5 kilogram', '5-kilogram', 'pa_weight', '0', '' );

kt_add_category( 262, '5 liter', '5-liter', 'pa_liter', '0', '' );

kt_add_category( 258, '7 kilogram', '7-kilogram', 'pa_weight', '0', '' );

kt_add_category( 26, 'Active', 'active', 'product_tag', '0', '' );

kt_add_category( 27, 'actual', 'actual', 'product_tag', '0', '' );

kt_add_category( 28, 'adf', 'adf', 'product_tag', '0', '' );

kt_add_brand( 29, 'Ame', 'ame', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_category( 30, 'auto', 'auto', 'product_tag', '0', '' );

kt_add_category( 31, 'beauty', 'beauty', 'product_tag', '0', '' );

kt_add_category( 226, 'Blue', 'blue', 'pa_color', '0', '' );

kt_add_category( 33, 'chance', 'chance', 'product_tag', '0', '' );

kt_add_brand( 34, 'Chanee', 'chanee', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_brand( 35, 'Chanleno', 'chanleno', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_category( 36, 'charming', 'charming', 'product_tag', '0', '' );

kt_add_category( 37, 'colorful', 'colorful', 'product_tag', '0', '' );

kt_add_category( 38, 'comfort', 'comfort', 'product_tag', '0', '' );

kt_add_category( 39, 'cooker', 'cooker', 'product_tag', '0', '' );

kt_add_category( 40, 'cute', 'cute', 'product_tag', '0', '' );

kt_add_category( 227, 'Darkbrown', 'darkbrown', 'pa_color', '0', '' );

kt_add_category( 249, 'Diamond', 'diamond', 'pa_material', '0', '' );

kt_add_category( 5, 'external', 'external', 'product_type', '0', '' );

kt_add_category( 250, 'Gold', 'gold', 'pa_material', '0', '' );

kt_add_category( 229, 'Gray', 'gray', 'pa_color', '0', '' );

kt_add_category( 228, 'Green', 'green', 'pa_color', '0', '' );

kt_add_category( 3, 'grouped', 'grouped', 'product_type', '0', '' );

kt_add_brand( 46, 'Hermee', 'hermee', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_category( 230, 'Light Blue', 'light-blue', 'pa_color', '0', '' );

kt_add_category( 231, 'Light Brown', 'light-brown', 'pa_color', '0', '' );

kt_add_category( 232, 'Light Pink', 'light-pink', 'pa_color', '0', '' );

kt_add_category( 50, 'long', 'long', 'product_tag', '0', '' );

kt_add_brand( 51, 'Lorea', 'lorea', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_category( 238, 'M', 'm', 'pa_size', '0', '' );

kt_add_brand( 53, 'Mamypokon', 'mamypokon', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_category( 233, 'Maroon', 'maroon', 'pa_color', '0', '' );

kt_add_category( 252, 'Metal', 'metal', 'pa_material', '0', '' );

kt_add_category( 56, 'modern', 'modern', 'product_tag', '0', '' );

kt_add_category( 57, 'Moving', 'moving', 'product_tag', '0', '' );

kt_add_category( 58, 'new', 'new', 'product_tag', '0', '' );

kt_add_category( 234, 'Orange', 'orange', 'pa_color', '0', '' );

kt_add_brand( 60, 'Pamperson', 'pamperson', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_category( 251, 'Pearl', 'pearl', 'pa_material', '0', '' );

kt_add_category( 61, 'pearl', 'pearl', 'product_tag', '0', '' );

kt_add_category( 63, 'picture', 'picture', 'product_tag', '0', '' );

kt_add_category( 235, 'Pink', 'pink', 'pa_color', '0', '' );

kt_add_category( 253, 'Plastic', 'plastic', 'pa_material', '0', '' );

kt_add_category( 66, 'Playing', 'playing', 'product_tag', '0', '' );

kt_add_category( 67, 'pretty', 'pretty', 'product_tag', '0', '' );

kt_add_brand( 68, 'Pumano', 'pumano', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_category( 236, 'Red', 'red', 'pa_color', '0', '' );

kt_add_category( 254, 'Ruby', 'ruby', 'pa_material', '0', '' );

kt_add_category( 239, 'S', 's', 'pa_size', '0', '' );

kt_add_category( 72, 'sexy', 'sexy', 'product_tag', '0', '' );

kt_add_category( 73, 'short', 'short', 'product_tag', '0', '' );

kt_add_category( 255, 'Silver', 'silver', 'pa_material', '0', '' );

kt_add_category( 2, 'simple', 'simple', 'product_type', '0', '' );

kt_add_category( 75, 'style', 'style', 'product_tag', '0', '' );

kt_add_brand( 76, 'Super', 'super', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_category( 77, 'transparent', 'transparent', 'product_tag', '0', '' );

kt_add_category( 4, 'variable', 'variable', 'product_type', '0', '' );

kt_add_category( 78, 'wash', 'wash', 'product_tag', '0', '' );

kt_add_category( 79, 'women', 'women', 'product_tag', '0', '' );

kt_add_category( 80, 'Woo', 'woo', 'product_tag', '0', '' );

kt_add_category( 256, 'Wood', 'wood', 'pa_material', '0', '' );

kt_add_category( 240, 'X', 'x', 'pa_size', '0', '' );

kt_add_category( 241, 'XL', 'xl', 'pa_size', '0', '' );

kt_add_category( 242, 'XS', 'xs', 'pa_size', '0', '' );

kt_add_category( 243, 'XXL', 'xxl', 'pa_size', '0', '' );

kt_add_category( 244, 'XXS', 'xxs', 'pa_size', '0', '' );

kt_add_category( 237, 'Yellow', 'yellow', 'pa_color', '0', '' );

kt_add_product_cat( 281, 'Accessories', 'accessories-2', 'product_cat', '0', '', '0' );

kt_add_product_cat( 88, 'Digital', 'digital', 'product_cat', '0', '', '0' );

kt_add_product_cat( 89, 'Electronic', 'electronic', 'product_cat', '0', '', '0' );

kt_add_product_cat( 90, 'Fashion', 'fashion', 'product_cat', '0', '', '0' );

kt_add_product_cat( 120, 'Flash Drives', 'otg-flash-drives', 'product_cat', '88', '', '' );

kt_add_product_cat( 92, 'Foods', 'foods', 'product_cat', '0', '', '' );

kt_add_product_cat( 274, 'Fridge', 'fridge', 'product_cat', '89', '', '0' );

kt_add_product_cat( 93, 'Furniture', 'furniture', 'product_cat', '0', '', '0' );

kt_add_product_cat( 96, 'Health &amp; Beauty', 'health-beauty', 'product_cat', '90', '', '' );

kt_add_product_cat( 98, 'Home Audio', 'home-audio-electronic', 'product_cat', '89', '', '' );

kt_add_product_cat( 99, 'Home Storage', 'home-storage', 'product_cat', '93', '', '' );

kt_add_product_cat( 100, 'Jackets', 'jackets-fashion', 'product_cat', '90', '', '' );

kt_add_product_cat( 101, 'Jewelry', 'jewelry', 'product_cat', '0', '', '0' );

kt_add_product_cat( 102, 'Jewelry &amp; Watches', 'jewelry-watches', 'product_cat', '101', '', '' );

kt_add_product_cat( 103, 'Jumpsuits', 'jumpsuits', 'product_cat', '90', '', '' );

kt_add_product_cat( 104, 'Kids', 'kids', 'product_cat', '90', '', '0' );

kt_add_product_cat( 105, 'Kitchen Tools', 'kitchen-tools', 'product_cat', '93', '', '' );

kt_add_product_cat( 106, 'Laptop', 'laptop', 'product_cat', '88', '', '' );

kt_add_product_cat( 108, 'Livingroom', 'livingroom', 'product_cat', '93', '', '' );

kt_add_product_cat( 109, 'Loveseats', 'loveseats', 'product_cat', '93', '', '' );

kt_add_product_cat( 269, 'Media', 'media', 'product_cat', '88', '', '0' );

kt_add_product_cat( 111, 'Mens', 'mens', 'product_cat', '90', '', '0' );

kt_add_product_cat( 112, 'Mens Watches', 'mens-watches', 'product_cat', '101', '', '0' );

kt_add_product_cat( 113, 'Mobile', 'mobile', 'product_cat', '88', '', '' );

kt_add_product_cat( 114, 'MP3 Player', 'mp3-player', 'product_cat', '89', '', '' );

kt_add_product_cat( 117, 'Necklaces', 'necklaces-jewelry', 'product_cat', '101', '', '' );

kt_add_product_cat( 118, 'Notebook', 'notebook', 'product_cat', '88', '', '' );

kt_add_product_cat( 119, 'Office Furniture', 'office-furniture', 'product_cat', '93', '', '' );

kt_add_product_cat( 121, 'Painting', 'painting', 'product_cat', '93', '', '' );

kt_add_product_cat( 123, 'Pearl Jewelry', 'pearl-jewelry', 'product_cat', '101', '', '' );

kt_add_product_cat( 277, 'Power Supplies', 'power-supplies', 'product_cat', '89', '', '0' );

kt_add_product_cat( 124, 'Printed', 'printer-supplies', 'product_cat', '88', '', '' );

kt_add_product_cat( 268, 'Radio', 'radio', 'product_cat', '88', '', '0' );

kt_add_product_cat( 279, 'Scarves', 'scarves', 'product_cat', '90', '', '0' );

kt_add_product_cat( 131, 'Skirts', 'skirts-fashion', 'product_cat', '90', '', '' );

kt_add_product_cat( 271, 'Smartphone', 'smartphone', 'product_cat', '88', '', '0' );

kt_add_product_cat( 133, 'SOOCOO S60', 'soocoo-s60', 'product_cat', '89', '', '' );

kt_add_product_cat( 134, 'Speaker', 'speaker', 'product_cat', '89', '', '' );

kt_add_product_cat( 135, 'Sports', 'sports', 'product_cat', '0', '', '0' );

kt_add_product_cat( 136, 'Sunglasses', 'sunglasses-sports', 'product_cat', '135', '', '' );

kt_add_product_cat( 137, 'Surfing', 'surfing', 'product_cat', '135', '', '' );

kt_add_product_cat( 138, 'T-Shirts', 't-shirts', 'product_cat', '90', '', '' );

kt_add_product_cat( 139, 'Tablet PC', 'tablet-pc', 'product_cat', '88', '', '' );

kt_add_product_cat( 140, 'Television', 'television-2', 'product_cat', '89', '', '' );

kt_add_product_cat( 141, 'Tennis', 'tennis', 'product_cat', '135', '', '' );

kt_add_product_cat( 144, 'Trending', 'trending', 'product_cat', '90', '', '' );

kt_add_product_cat( 273, 'Washing Machine', 'washing-machine', 'product_cat', '89', '', '0' );

kt_add_product_cat( 146, 'Wedding rings', 'wedding-rings-jewelry', 'product_cat', '101', '', '' );

kt_add_product_cat( 147, 'Womens', 'womens', 'product_cat', '90', '', '0' );

kt_add_product_cat( 148, '925 Silver', '925-silver', 'product_cat', '101', '', '' );

kt_add_product_cat( 149, 'Accessories', 'accessories', 'product_cat', '101', '', '' );

kt_add_product_cat( 153, 'Air Conditional', 'air-conditional', 'product_cat', '89', '', '' );

kt_add_product_cat( 154, 'ARM', 'arm', 'product_cat', '89', '', '' );

kt_add_product_cat( 155, 'Basketball Shoes', 'basketball-shoes', 'product_cat', '135', '', '' );

kt_add_product_cat( 280, 'Beauty', 'beauty', 'product_cat', '90', '', '0' );

kt_add_product_cat( 158, 'Bedding', 'bedding', 'product_cat', '93', '', '' );

kt_add_product_cat( 159, 'Bike Light', 'bike-light', 'product_cat', '135', '', '' );

kt_add_product_cat( 160, 'Body Chains', 'body-chains', 'product_cat', '101', '', '' );

kt_add_product_cat( 164, 'Boxing', 'boxing', 'product_cat', '135', '', '' );

kt_add_product_cat( 165, 'Camera', 'camera', 'product_cat', '88', '', '' );

kt_add_product_cat( 168, 'Camping Stoves', 'camping-stoves', 'product_cat', '135', '', '' );

kt_add_product_cat( 278, 'Casual', 'casual', 'product_cat', '90', '', '0' );

kt_add_product_cat( 169, 'Chairs &amp; Recliners', 'chairs-recliners', 'product_cat', '93', '', '' );

kt_add_product_cat( 171, 'Climbing', 'climbing', 'product_cat', '135', '', '' );

kt_add_product_cat( 270, 'Computer', 'computer', 'product_cat', '88', '', '0' );

kt_add_product_cat( 287, 'Computer', 'computer-electronic', 'product_cat', '89', '', '0' );

kt_add_product_cat( 275, 'Cooker', 'cooker', 'product_cat', '89', '', '0' );

kt_add_product_cat( 173, 'Cooking Tools', 'cooking-tools', 'product_cat', '93', '', '' );

kt_add_product_cat( 174, 'Cross Stitch', 'cross-stitch', 'product_cat', '93', '', '' );

kt_add_product_cat( 175, 'Curtain', 'curtain', 'product_cat', '93', '', '' );

kt_add_product_cat( 176, 'Cycling Jerseys', 'cycling-jerseys', 'product_cat', '135', '', '' );

kt_add_product_cat( 177, 'Decorative', 'decorative', 'product_cat', '93', '', '' );

kt_add_product_cat( 272, 'Device', 'device', 'product_cat', '88', '', '0' );

kt_add_product_cat( 178, 'Diamond Jewelry', 'diamond-jewelry', 'product_cat', '101', '', '' );

kt_add_product_cat( 179, 'Digital Watches', 'digital-watches', 'product_cat', '101', '', '' );

kt_add_product_cat( 180, 'Dress Watches', 'dress-watches', 'product_cat', '101', '', '' );

kt_add_product_cat( 276, 'Dynamo', 'dynamo', 'product_cat', '89', '', '0' );

kt_add_product_cat( 182, 'Engagement Rings', 'engagement-rings', 'product_cat', '101', '', '' );

kt_add_product_cat( 183, 'Fishing Tackle Bags', 'fishing-tackle-bags', 'product_cat', '135', '', '' );

kt_add_product_cat( 184, 'Fitness', 'fitness', 'product_cat', '135', '', '' );

kt_add_product_cat( 185, 'Football', 'football', 'product_cat', '135', '', '' );

kt_add_product_cat( 188, 'Gold Jewelry', 'gold-jewelry', 'product_cat', '101', '', '' );

kt_add_product_cat( 189, 'Hiking Shoes', 'hiking-shoes', 'product_cat', '135', '', '' );

kt_add_product_cat( 190, 'Keepfit', 'keepfit', 'product_cat', '135', '', '' );
