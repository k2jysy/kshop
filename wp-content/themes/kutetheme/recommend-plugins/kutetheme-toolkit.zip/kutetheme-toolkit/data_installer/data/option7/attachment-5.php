<?php
kt_download_media(2251, '13', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/13.jpg');

kt_download_media(2252, '14', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/14.jpg');

kt_download_media(2253, '15jpg', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/15jpg.jpg');

kt_download_media(2254, '16', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/16.jpg');

kt_download_media(2255, '17', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/17.jpg');

kt_download_media(2256, '18', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/18.jpg');

kt_download_media(2257, '19', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/19.jpg');
