<?php
kt_download_media(2146, 'brand3', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/12/brand3.jpg');

kt_download_media(2147, 'brand4', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/12/brand4.jpg');

kt_download_media(2148, 'brand5', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/12/brand5.jpg');