<?php
kt_download_media(2367, '17', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/10/17.png');

kt_download_media(2368, '18', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/10/18.png');

kt_download_media(2369, '19', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/10/19.png');

kt_download_media(2370, '20', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/10/20.png');

kt_download_media(2371, '21', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/10/21.png');

kt_download_media(2372, '22', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/10/22.png');
