<?php
// Attachment
kt_download_media(1880, 's1', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/s1.png');

kt_download_media(1881, 's2', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/s2.png');

kt_download_media(1882, 's3', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/s3.png');


