<?php
kt_download_media(2130, 'p77', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/p77.jpg');

kt_download_media(2131, 'p80', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/p80.jpg');

kt_download_media(2132, 'icon-s1', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/icon-s1.png');

kt_download_media(2133, 'trademark-cn', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/12/trademark-cn.jpg');

kt_download_media(2134, 'trademark-dhl', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/12/trademark-dhl.jpg');

kt_download_media(2135, 'trademark-ems', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/12/trademark-ems.jpg');
