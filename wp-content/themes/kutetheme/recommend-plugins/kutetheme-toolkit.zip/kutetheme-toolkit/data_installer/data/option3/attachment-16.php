<?php
kt_download_media(2244, 'blog7', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/blog7.jpg');

kt_download_media(2247, 'blog8', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/blog8.jpg');

kt_download_media(2248, 'blog11', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/blog11.jpg');

kt_download_media(2249, 'blog22', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/blog22.jpg');

kt_download_media(2250, 'blog31', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/blog31.jpg');

kt_download_media(2251, 'blog41', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/blog41.jpg');

kt_download_media(2270, 'heart1.png', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/revslider/kute-opt3/heart1.png');

kt_download_media(2271, 'heart2.png', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/revslider/kute-opt3/heart2.png');
