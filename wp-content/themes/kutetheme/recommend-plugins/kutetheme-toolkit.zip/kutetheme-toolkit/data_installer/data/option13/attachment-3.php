<?php
kt_download_media(2012, '9', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/9.jpg');

kt_download_media(2013, '10', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/10.jpg');

kt_download_media(2014, '11', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/11.jpg');
