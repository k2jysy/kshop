<?php
kt_download_media(2113, 'i 13', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/10/i-13.jpg');

kt_download_media(2114, 'i 14', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/10/i-14.jpg');

kt_download_media(2137, 'i 4', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/10/i-4.jpg');

kt_download_media(2138, 'i 1', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/10/i-1.jpg');

kt_download_media(2139, 'i 2', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/10/i-2.jpg');

kt_download_media(2140, 'i 5', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/10/i-5.jpg');

kt_download_media(2174, 'i 26', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/10/i-26.jpg');

kt_download_media(2186, 'i 24', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/10/i-24.jpg');
