<?php
kt_download_media(2027, '74', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/08/74.jpg');

kt_download_media(2028, '75', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/08/75.jpg');

kt_download_media(2029, '76', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/08/76.jpg');
