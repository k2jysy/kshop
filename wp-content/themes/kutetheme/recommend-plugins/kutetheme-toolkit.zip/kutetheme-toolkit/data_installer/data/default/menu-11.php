<?php
//Menu
$menu_id = kt_add_menu( 174, 'My account', '' );

 // Menu Item
kt_add_menu_item( 1930, $menu_id, 0, 'My Order', 'custom', 1930, 'custom', '#', '', '', '' );

kt_add_menu_item( 1931, $menu_id, 0, 'My Wishlist', 'custom', 1931, 'custom', '#', '', '', '' );

kt_add_menu_item( 1932, $menu_id, 0, 'My Credit Slip', 'custom', 1932, 'custom', '#', '', '', '' );

kt_add_menu_item( 1933, $menu_id, 0, 'My Addresses', 'custom', 1933, 'custom', '#', '', '', '' );

kt_add_menu_item( 1934, $menu_id, 0, 'My Personal In', 'custom', 1934, 'custom', '#', '', '', '' );
