<?php
kt_download_media(993, 'trademark-ups', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/trademark-ups1.jpg');

kt_download_media(994, 'trademark-qiwi', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/trademark-qiwi1.jpg');

kt_download_media(995, 'trademark-wu', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/trademark-wu1.jpg');

kt_download_media(996, 'trademark-cn', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/trademark-cn1.jpg');

kt_download_media(997, 'trademark-visa', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/trademark-visa1.jpg');

kt_download_media(998, 'trademark-mc', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/trademark-mc1.jpg');

kt_download_media(999, 'trademark-ems', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/trademark-ems1.jpg');
