<?php
kt_download_media(2157, 's3', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/s3.jpg');

kt_download_media(2158, 'logo', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/12/logo.png');

kt_download_media(2161, 'b1', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/b1.jpg');

kt_download_media(2162, 'b2', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/b2.jpg');

kt_download_media(2163, 'b3', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/b3.jpg');

kt_download_media(2164, 'b4', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/b4.jpg');
