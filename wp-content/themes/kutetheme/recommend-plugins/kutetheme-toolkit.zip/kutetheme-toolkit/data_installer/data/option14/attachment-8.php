<?php
kt_download_media(2061, 'blog6', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/08/blog6.jpg');

kt_download_media(2062, 'blog7', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/08/blog7.jpg');

kt_download_media(2063, 'blog8', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/08/blog8.jpg');
