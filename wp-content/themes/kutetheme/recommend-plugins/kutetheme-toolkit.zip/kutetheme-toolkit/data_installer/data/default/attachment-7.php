<?php
kt_download_media(2020, '12', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/12.jpg');

kt_download_media(2021, '13', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/13.jpg');

kt_download_media(2022, '9', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/9.jpg');

kt_download_media(2023, '8', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/8.jpg');

kt_download_media(2024, 'i 10', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/i-10.jpg');

kt_download_media(2025, 'i 11', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/i-11.jpg');
