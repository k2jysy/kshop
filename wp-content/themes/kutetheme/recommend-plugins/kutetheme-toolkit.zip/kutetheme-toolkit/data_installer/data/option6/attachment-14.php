<?php
kt_download_media(1518, 'popular1', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/09/popular1.jpg');

kt_download_media(1520, 'popular2', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/09/popular2.jpg');

kt_download_media(1522, 'popular3', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/09/popular3.jpg');

kt_download_media(1525, 'banner1', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/banner11.jpg');

kt_download_media(1526, 'banner2', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/banner2.jpg');

kt_download_media(1530, 'banner9', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/banner9.jpg');

kt_download_media(1531, 'banner10', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/banner10.jpg');
