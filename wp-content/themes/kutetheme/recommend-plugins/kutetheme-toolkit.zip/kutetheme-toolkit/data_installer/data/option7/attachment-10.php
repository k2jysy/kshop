<?php
kt_download_media(2285, '47', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/47.jpg');

kt_download_media(2286, '48', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/48.jpg');

kt_download_media(2362, '12', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/10/12.png');

kt_download_media(2363, '13', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/10/13.png');

kt_download_media(2364, '14', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/10/14.png');

kt_download_media(2365, '15', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/10/15.png');

kt_download_media(2366, '16', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/10/16.png');
