<?php
kt_download_media(2033, '18', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/18.jpeg');

kt_download_media(2034, '19', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/19.jpg');

kt_download_media(2035, '60', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/60.jpg');

kt_download_media(2036, '63', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/63.jpg');

kt_download_media(2037, '64', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/64.jpg');

kt_download_media(2038, '67', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/67.jpg');
