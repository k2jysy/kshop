<?php
kt_download_media(2272, 'heart3.png', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/revslider/kute-opt3/heart3.png');

kt_download_media(2274, 'sexy.png', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/revslider/kute-opt3/sexy.png');

kt_download_media(2282, 'electronic', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/10/electronic.png');

kt_download_media(2283, 'sports&o', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/10/sportso.png');

kt_download_media(2284, 'smartphone', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/10/smartphone.png');

kt_download_media(2285, 'healthy', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/10/healthy.png');

kt_download_media(2286, 'shoes&acc', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/10/shoesacc.png');

kt_download_media(2287, 'toys', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/10/toys.png');
