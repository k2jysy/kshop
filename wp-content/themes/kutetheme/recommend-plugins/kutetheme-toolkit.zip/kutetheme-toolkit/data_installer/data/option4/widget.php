<?php
 // Widgets
kt_add_widget( 'categories', 'sidebar-primary', '2', 'YTo0OntzOjU6InRpdGxlIjtzOjE1OiJCTE9HIENBVEVHT1JJRVMiO3M6NToiY291bnQiO2k6MDtzOjEyOiJoaWVyYXJjaGljYWwiO2k6MDtzOjg6ImRyb3Bkb3duIjtpOjA7fQ==', '2' );

kt_add_widget( 'wpp', 'sidebar-primary', '2', 'YToxNTp7czo1OiJ0aXRsZSI7czoxMjoiUG9wdWxhciBQb3N0IjtzOjU6ImxpbWl0IjtzOjI6IjEwIjtzOjU6InJhbmdlIjtzOjM6ImFsbCI7czo4OiJvcmRlcl9ieSI7czo1OiJ2aWV3cyI7czo5OiJwb3N0X3R5cGUiO3M6NDoicG9zdCI7czo5OiJmcmVzaG5lc3MiO2I6MTtzOjM6InBpZCI7czowOiIiO3M6MzoiY2F0IjtzOjA6IiI7czo2OiJhdXRob3IiO3M6MDoiIjtzOjEzOiJzaG9ydGVuX3RpdGxlIjthOjM6e3M6NToid29yZHMiO3M6MToiMCI7czo2OiJhY3RpdmUiO2I6MDtzOjY6Imxlbmd0aCI7czoyOiIyNSI7fXM6MTI6InBvc3QtZXhjZXJwdCI7YTo0OntzOjExOiJrZWVwX2Zvcm1hdCI7YjowO3M6NToid29yZHMiO3M6MToiMCI7czo2OiJhY3RpdmUiO2I6MDtzOjY6Imxlbmd0aCI7czoyOiI1NSI7fXM6OToidGh1bWJuYWlsIjthOjU6e3M6NjoiYWN0aXZlIjtiOjE7czo1OiJ3aWR0aCI7aTo3MDtzOjY6ImhlaWdodCI7aTo0OTtzOjU6ImJ1aWxkIjtzOjEwOiJwcmVkZWZpbmVkIjtzOjQ6ImNyb3AiO2I6MTt9czo2OiJyYXRpbmciO2I6MDtzOjk6InN0YXRzX3RhZyI7YTo1OntzOjEzOiJjb21tZW50X2NvdW50IjtiOjA7czo1OiJ2aWV3cyI7YjowO3M6NjoiYXV0aG9yIjtiOjA7czo0OiJkYXRlIjthOjI6e3M6NjoiYWN0aXZlIjtiOjE7czo2OiJmb3JtYXQiO3M6NjoiRiBqLCBZIjt9czo4OiJjYXRlZ29yeSI7YjowO31zOjY6Im1hcmt1cCI7YTo2OntzOjExOiJjdXN0b21faHRtbCI7YjowO3M6OToid3BwLXN0YXJ0IjtzOjM3OiImbHQ7dWwgY2xhc3M9JnF1b3Q7d3BwLWxpc3QmcXVvdDsmZ3Q7IjtzOjc6IndwcC1lbmQiO3M6MTE6IiZsdDsvdWwmZ3Q7IjtzOjk6InBvc3QtaHRtbCI7czo0NDoiJmx0O2xpJmd0O3t0aHVtYn0ge3RpdGxlfSB7c3RhdHN9Jmx0Oy9saSZndDsiO3M6MTE6InRpdGxlLXN0YXJ0IjtzOjA6IiI7czo5OiJ0aXRsZS1lbmQiO3M6MDoiIjt9fQ==', '2' );

kt_add_widget( 'kt_image', 'sidebar-primary', '2', 'YTo0OntzOjQ6ImxpbmsiO3M6MToiIyI7czo2OiJ0YXJnZXQiO3M6NToiX3NlbGYiO3M6NDoic2l6ZSI7czowOiIiO3M6MTA6ImF0dGFjaG1lbnQiO2k6MjQxMjt9', '2' );

kt_add_widget( 'recent-comments', 'sidebar-primary', '2', 'YToyOntzOjU6InRpdGxlIjtzOjE0OiJSZWNlbnQgQ29tbWVudCI7czo2OiJudW1iZXIiO2k6NTt9', '2' );

kt_add_widget( 'woocommerce_product_tag_cloud', 'sidebar-primary', '2', 'YToxOntzOjU6InRpdGxlIjtzOjEyOiJQcm9kdWN0IFRhZ3MiO30=', '2' );

kt_add_widget( 'kt_image', 'sidebar-primary', '3', 'YTo0OntzOjQ6ImxpbmsiO3M6MToiIyI7czo2OiJ0YXJnZXQiO3M6NToiX3NlbGYiO3M6NDoic2l6ZSI7czowOiIiO3M6MTA6ImF0dGFjaG1lbnQiO2k6MjQxMzt9', '3' );

kt_add_widget( 'woocommerce_product_categories', 'sidebar-shop', '2', 'YTo2OntzOjU6InRpdGxlIjtzOjEzOiJQcm9kdWN0IFR5cGVzIjtzOjc6Im9yZGVyYnkiO3M6NDoibmFtZSI7czo4OiJkcm9wZG93biI7aTowO3M6NToiY291bnQiO2k6MDtzOjEyOiJoaWVyYXJjaGljYWwiO3M6MToiMSI7czoxODoic2hvd19jaGlsZHJlbl9vbmx5IjtpOjA7fQ==', '2' );

kt_add_widget( 'woocommerce_layered_nav_filters', 'sidebar-shop', '2', 'YToxOntzOjU6InRpdGxlIjtzOjE0OiJBY3RpdmUgRmlsdGVycyI7fQ==', '2' );

kt_add_widget( 'woocommerce_price_filter', 'sidebar-shop', '2', 'YToxOntzOjU6InRpdGxlIjtzOjE1OiJGaWx0ZXIgYnkgcHJpY2UiO30=', '2' );

kt_add_widget( 'yith-woo-ajax-navigation', 'sidebar-shop', '2', 'YTo4OntzOjU6InRpdGxlIjtzOjE1OiJGaWx0ZXIgYnkgQ29sb3IiO3M6OToiYXR0cmlidXRlIjtzOjU6ImNvbG9yIjtzOjEwOiJxdWVyeV90eXBlIjtzOjM6ImFuZCI7czo0OiJ0eXBlIjtzOjU6ImNvbG9yIjtzOjY6ImNvbG9ycyI7YToxMDp7aToxNzc7czo3OiIjMDEwMTAxIjtpOjE3ODtzOjc6IiMwYzNhOTAiO2k6MTg1O3M6NzoiIzcwNzMwMCI7aToxNzk7czo3OiIjOTM5ODk0IjtpOjE4MDtzOjc6IiMwZmE4MDAiO2k6MTgxO3M6NzoiI2ZkYWYwNyI7aToxODI7czo3OiIjZmYwMGZlIjtpOjE4MztzOjc6IiNmZjAxMDMiO2k6MTg2O3M6NzoiI2JjMDRkZSI7aToxODQ7czo3OiIjZmZmNDA0Ijt9czoxMDoibXVsdGljb2xvciI7YTowOnt9czo2OiJsYWJlbHMiO2E6MDp7fXM6NzoiZGlzcGxheSI7czozOiJhbGwiO30=', '2' );

kt_add_widget( 'woocommerce_layered_nav', 'sidebar-shop', '2', 'YTo0OntzOjU6InRpdGxlIjtzOjE0OiJGaWx0ZXIgYnkgU2l6ZSI7czo5OiJhdHRyaWJ1dGUiO3M6NDoic2l6ZSI7czoxMjoiZGlzcGxheV90eXBlIjtzOjQ6Imxpc3QiO3M6MTA6InF1ZXJ5X3R5cGUiO3M6MzoiYW5kIjt9', '2' );

kt_add_widget( 'widget_kt_slider', 'sidebar-shop', '2', 'YTo3OntzOjg6ImF1dG9wbGF5IjtzOjI6Im9uIjtzOjEwOiJzbGlkZXNwZWVkIjtpOjI1MDtzOjU6InRpdGxlIjthOjM6e2k6MDtzOjA6IiI7aToxO3M6MDoiIjtpOjI7czowOiIiO31zOjU6ImltYWdlIjthOjM6e2k6MDtpOjI0MTI7aToxO2k6MjQxMztpOjI7aToyNDE0O31zOjQ6ImxpbmsiO2E6Mzp7aTowO3M6MToiIyI7aToxO3M6MToiIyI7aToyO3M6MToiIyI7fXM6NjoidGFyZ2V0IjtOO3M6NDoibG9vcCI7czowOiIiO30=', '2' );

kt_add_widget( 'woocommerce_product_tag_cloud', 'sidebar-shop', '3', 'YToxOntzOjU6InRpdGxlIjtzOjQ6IlRhZ3MiO30=', '3' );

kt_add_widget( 'widget_kt_product_special', 'sidebar-shop', '2', 'YTo0OntzOjU6InRpdGxlIjtzOjg6IlNwZWNpYWxzIjtzOjc6Im9yZGVyYnkiO3M6NDoiZGF0ZSI7czo1OiJvcmRlciI7czo0OiJkZXNjIjtzOjE0OiJwb3N0c19wZXJfcGFnZSI7aTozO30=', '2' );

kt_add_widget( 'widget_kt_testimonial', 'sidebar-shop', '2', 'YTo3OntzOjU6InRpdGxlIjtzOjExOiJUZXN0aW1vbmlhbCI7czo4OiJhdXRvcGxheSI7czoyOiJvbiI7czoxMDoic2xpZGVzcGVlZCI7aToyNTA7czo2OiJudW1iZXIiO2k6MztzOjc6Im9yZGVyYnkiO3M6NDoiZGF0ZSI7czo1OiJvcmRlciI7czo0OiJkZXNjIjtzOjQ6Imxvb3AiO3M6MDoiIjt9', '2' );

kt_add_widget( 'nav_menu', 'footer-menu-1', '2', 'YToyOntzOjU6InRpdGxlIjtzOjc6IkNvbXBhbnkiO3M6ODoibmF2X21lbnUiO2k6MTUxO30=', '2' );

kt_add_widget( 'nav_menu', 'footer-menu-2', '3', 'YToyOntzOjU6InRpdGxlIjtzOjEwOiJNeSBBY2NvdW50IjtzOjg6Im5hdl9tZW51IjtpOjE2NTt9', '3' );

kt_add_widget( 'nav_menu', 'footer-menu-3', '4', 'YToyOntzOjU6InRpdGxlIjtzOjc6IlN1cHBvcnQiO3M6ODoibmF2X21lbnUiO2k6MTc0O30=', '4' );

