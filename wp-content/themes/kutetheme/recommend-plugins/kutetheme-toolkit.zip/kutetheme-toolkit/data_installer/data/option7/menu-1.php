<?php
// Other
kt_other_post_type(55, 'megamenu', 0 ,'Main menu - Fashion', 'W3ZjX3Jvd11bdmNfY29sdW1uIHdpZHRoPSIxLzQiXVt2Y19zaW5nbGVfaW1hZ2UgaW1hZ2U9IjI2NjciIGltZ19zaXplPSJmdWxsIl1bdmNfd3BfY3VzdG9tbWVudSBuYXZfbWVudT0iMTMwIiB0aXRsZT0iTWVuJ3MiXVsvdmNfY29sdW1uXVt2Y19jb2x1bW4gd2lkdGg9IjEvNCJdW3ZjX3NpbmdsZV9pbWFnZSBpbWFnZT0iMjY2OSIgaW1nX3NpemU9ImZ1bGwiXVt2Y193cF9jdXN0b21tZW51IG5hdl9tZW51PSIxMzAiIHRpdGxlPSJXb21lbidzIl1bL3ZjX2NvbHVtbl1bdmNfY29sdW1uIHdpZHRoPSIxLzQiXVt2Y19zaW5nbGVfaW1hZ2UgaW1hZ2U9IjI2NzAiIGltZ19zaXplPSJmdWxsIl1bdmNfd3BfY3VzdG9tbWVudSBuYXZfbWVudT0iMTI4IiB0aXRsZT0iS2lkJ3MiXVsvdmNfY29sdW1uXVt2Y19jb2x1bW4gd2lkdGg9IjEvNCJdW3ZjX3NpbmdsZV9pbWFnZSBpbWFnZT0iMjY3MSIgaW1nX3NpemU9ImZ1bGwiXVt2Y193cF9jdXN0b21tZW51IG5hdl9tZW51PSIxNDMiIHRpdGxlPSJUcmVuZGluZyJdWy92Y19jb2x1bW5dWy92Y19yb3dd', 'http://dev02.ovicsoft.com/thang/kutetheme-wp/?post_type=megamenu&#038;p=55', '', 'closed', 'a:6:{s:17:"kt_megamenu_width";a:2:{i:0;s:3:"830";i:1;s:3:"830";}s:17:"_vc_post_settings";a:4:{i:0;s:30:"a:1:{s:10:"vc_grid_id";a:0:{}}";i:1;s:30:"a:1:{s:10:"vc_grid_id";a:0:{}}";i:2;s:30:"a:1:{s:10:"vc_grid_id";a:0:{}}";i:3;s:30:"a:1:{s:10:"vc_grid_id";a:0:{}}";}s:14:"slide_template";a:4:{i:0;s:7:"default";i:1;s:7:"default";i:2;s:7:"default";i:3;s:7:"default";}s:17:"_wpb_vc_js_status";a:4:{i:0;s:4:"true";i:1;s:4:"true";i:2;s:4:"true";i:3;s:4:"true";}s:10:"_edit_last";a:4:{i:0;s:1:"1";i:1;s:1:"1";i:2;s:1:"1";i:3;s:1:"1";}s:10:"_edit_lock";a:1:{i:0;s:12:"1446017139:1";}}' );

kt_other_post_type(764, 'megamenu', 0 ,'Vertical Menu - Shoes', 'W3ZjX3Jvd11bdmNfY29sdW1uXVtsaXN0X3Byb2R1Y3QgbnVtYmVyPSI0IiB0eXBlcz0icmV2aWV3IiBjYXQ9IjQ4Il1bL3ZjX2NvbHVtbl1bL3ZjX3Jvd10=', 'http://dev02.ovicsoft.com/thang/kutetheme-wp/?post_type=megamenu&#038;p=764', '', 'closed', 'a:6:{s:14:"slide_template";a:2:{i:0;s:7:"default";i:1;s:7:"default";}s:17:"_vc_post_settings";a:2:{i:0;s:30:"a:1:{s:10:"vc_grid_id";a:0:{}}";i:1;s:30:"a:1:{s:10:"vc_grid_id";a:0:{}}";}s:17:"_wpb_vc_js_status";a:2:{i:0;s:4:"true";i:1;s:4:"true";}s:10:"_edit_last";a:2:{i:0;s:1:"1";i:1;s:1:"1";}s:17:"kt_megamenu_width";a:2:{i:0;s:3:"830";i:1;s:3:"830";}s:10:"_edit_lock";a:1:{i:0;s:12:"1446087171:1";}}' );

kt_other_post_type(766, 'megamenu', 0 ,'Vertical Menu - Sport', 'W3ZjX3Jvd11bdmNfY29sdW1uIHdpZHRoPSIxLzMiXVt2Y193cF9jdXN0b21tZW51IG5hdl9tZW51PSIxNDAiIHRpdGxlPSJUZW5uaXMiXVsvdmNfY29sdW1uXVt2Y19jb2x1bW4gd2lkdGg9IjEvMyJdW3ZjX3dwX2N1c3RvbW1lbnUgbmF2X21lbnU9IjE0MCIgdGl0bGU9IlN3aW1taW5nIl1bL3ZjX2NvbHVtbl1bdmNfY29sdW1uIHdpZHRoPSIxLzMiXVt2Y193cF9jdXN0b21tZW51IG5hdl9tZW51PSIxNDAiIHRpdGxlPSJTaG9lcyJdWy92Y19jb2x1bW5dWy92Y19yb3ddW3ZjX3JvdyBjc3M9Ii52Y19jdXN0b21fMTQ0MjIxMzcxNzU0OHttYXJnaW4tdG9wOiAxMHB4ICFpbXBvcnRhbnQ7cGFkZGluZy10b3A6IDEwcHggIWltcG9ydGFudDt9Il1bdmNfY29sdW1uXVt2Y19zaW5nbGVfaW1hZ2UgaW1hZ2U9IjI2NjYiIGltZ19zaXplPSJmdWxsIiBvbmNsaWNrPSJjdXN0b21fbGluayIgbGluaz0iIyIgY3NzPSIudmNfY3VzdG9tXzE0NDYwMTcwMzU1OTZ7bWFyZ2luLXRvcDogMTBweCAhaW1wb3J0YW50O30iXVsvdmNfY29sdW1uXVsvdmNfcm93XQ==', 'http://dev02.ovicsoft.com/thang/kutetheme-wp/?post_type=megamenu&#038;p=766', '', 'closed', 'a:7:{s:10:"_edit_last";a:2:{i:0;s:1:"1";i:1;s:1:"1";}s:17:"_wpb_vc_js_status";a:2:{i:0;s:4:"true";i:1;s:4:"true";}s:17:"_vc_post_settings";a:2:{i:0;s:30:"a:1:{s:10:"vc_grid_id";a:0:{}}";i:1;s:30:"a:1:{s:10:"vc_grid_id";a:0:{}}";}s:14:"slide_template";a:2:{i:0;s:7:"default";i:1;s:7:"default";}s:26:"_wpb_shortcodes_custom_css";a:2:{i:0;s:137:".vc_custom_1442213717548{margin-top: 10px !important;padding-top: 10px !important;}.vc_custom_1446017035596{margin-top: 10px !important;}";i:1;s:137:".vc_custom_1442213717548{margin-top: 10px !important;padding-top: 10px !important;}.vc_custom_1446017035596{margin-top: 10px !important;}";}s:17:"kt_megamenu_width";a:2:{i:0;s:3:"830";i:1;s:3:"830";}s:10:"_edit_lock";a:1:{i:0;s:12:"1446016901:1";}}' );

kt_other_post_type(835, 'megamenu', 0 ,'Main menu - Foods', 'W3ZjX3Jvd11bdmNfY29sdW1uIHdpZHRoPSIxLzQiXVt2Y193cF9jdXN0b21tZW51IG5hdl9tZW51PSIxMTUiIHRpdGxlPSJBU0lBTiJdW3ZjX3dwX2N1c3RvbW1lbnUgbmF2X21lbnU9IjEzOCIgdGl0bGU9IlNBVVNBR0VTIl1bL3ZjX2NvbHVtbl1bdmNfY29sdW1uIHdpZHRoPSIxLzQiXVt2Y193cF9jdXN0b21tZW51IG5hdl9tZW51PSIxMjIiIHRpdGxlPSJFVVJPUEVBTiJdW3ZjX3dwX2N1c3RvbW1lbnUgbmF2X21lbnU9IjExNyIgdGl0bGU9IkNISUNLRU4iXVsvdmNfY29sdW1uXVt2Y19jb2x1bW4gd2lkdGg9IjEvNCJdW3ZjX3dwX2N1c3RvbW1lbnUgbmF2X21lbnU9IjEyNCIgdGl0bGU9IkZBU1QiXVt2Y193cF9jdXN0b21tZW51IG5hdl9tZW51PSIxMzciIHRpdGxlPSJTQU5EV0lDSCJdWy92Y19jb2x1bW5dW3ZjX2NvbHVtbiB3aWR0aD0iMS80Il1bdmNfc2luZ2xlX2ltYWdlIGltYWdlPSIyNjY0IiBpbWdfc2l6ZT0iZnVsbCIgYWxpZ25tZW50PSJyaWdodCIgb25jbGljaz0iY3VzdG9tX2xpbmsiIGxpbms9IiMiXVsvdmNfY29sdW1uXVsvdmNfcm93XQ==', 'http://dev02.ovicsoft.com/thang/kutetheme-wp/?post_type=megamenu&#038;p=835', '', 'closed', 'a:6:{s:17:"kt_megamenu_width";a:2:{i:0;s:3:"830";i:1;s:3:"830";}s:14:"slide_template";a:2:{i:0;s:7:"default";i:1;s:7:"default";}s:17:"_vc_post_settings";a:2:{i:0;s:30:"a:1:{s:10:"vc_grid_id";a:0:{}}";i:1;s:30:"a:1:{s:10:"vc_grid_id";a:0:{}}";}s:17:"_wpb_vc_js_status";a:2:{i:0;s:4:"true";i:1;s:4:"true";}s:10:"_edit_last";a:2:{i:0;s:1:"1";i:1;s:1:"1";}s:10:"_edit_lock";a:1:{i:0;s:12:"1446042023:1";}}' );

kt_other_post_type(647, 'service', 0 ,'SHOP WITH CONFIDENCE', 'TmFtIGFkaXBpc2NpbmcuIE51bGxhbSB2ZWwgc2VtLiBDdXJhYml0dXIgdmVzdGlidWx1bSBhbGlxdWFtIGxlby4gRnVzY2UgdnVscHV0YXRlIGVsZWlmZW5kIHNhcGllbi4gQWVuZWFuIGxlbyBsaWd1bGEsIHBvcnR0aXRvciBldSwgY29uc2VxdWF0IHZpdGFlLCBlbGVpZmVuZCBhYywgZW5pbS4NCg0KTnVsbGEgcG9ydGEgZG9sb3IuIFZpdmFtdXMgZWxlbWVudHVtIHNlbXBlciBuaXNpLiBOYW0gcHJldGl1bSB0dXJwaXMgZXQgYXJjdS4gQ3VyYWJpdHVyIGF0IGxhY3VzIGFjIHZlbGl0IG9ybmFyZSBsb2JvcnRpcy4gQWVuZWFuIHV0IGVyb3MgZXQgbmlzbCBzYWdpdHRpcyB2ZXN0aWJ1bHVtLg0KDQpOdWxsYSBmYWNpbGlzaS4gTWFlY2VuYXMgdWxsYW1jb3JwZXIsIGR1aSBldCBwbGFjZXJhdCBmZXVnaWF0LCBlcm9zIHBlZGUgdmFyaXVzIG5pc2ksIGNvbmRpbWVudHVtIHZpdmVycmEgZmVsaXMgbnVuYyBldCBsb3JlbS4gRXRpYW0gaW1wZXJkaWV0IGltcGVyZGlldCBvcmNpLiBTdXNwZW5kaXNzZSBlbmltIHR1cnBpcywgZGljdHVtIHNlZCwgaWFjdWxpcyBhLCBjb25kaW1lbnR1bSBuZWMsIG5pc2kuIEN1cmFiaXR1ciB1bGxhbWNvcnBlciB1bHRyaWNpZXMgbmlzaS4NCg0KRXRpYW0gZmV1Z2lhdCBsb3JlbSBub24gbWV0dXMuIFZlc3RpYnVsdW0gcHVydXMgcXVhbSwgc2NlbGVyaXNxdWUgdXQsIG1vbGxpcyBzZWQsIG5vbnVtbXkgaWQsIG1ldHVzLiBOYW0gaXBzdW0gcmlzdXMsIHJ1dHJ1bSB2aXRhZSwgdmVzdGlidWx1bSBldSwgbW9sZXN0aWUgdmVsLCBsYWN1cy4gTW9yYmkgbmVjIG1ldHVzLiBQaGFzZWxsdXMgdGVtcHVzLg0KDQpQZWxsZW50ZXNxdWUgaGFiaXRhbnQgbW9yYmkgdHJpc3RpcXVlIHNlbmVjdHVzIGV0IG5ldHVzIGV0IG1hbGVzdWFkYSBmYW1lcyBhYyB0dXJwaXMgZWdlc3Rhcy4gTW9yYmkgbWF0dGlzIHVsbGFtY29ycGVyIHZlbGl0LiBJbnRlZ2VyIHRpbmNpZHVudC4gRnVzY2UgYSBxdWFtLiBNb3JiaSBtYXR0aXMgdWxsYW1jb3JwZXIgdmVsaXQu', 'http://dev02.ovicsoft.com/thang/kutetheme-wp/?post_type=service&#038;p=647', '', 'closed', 'a:8:{s:26:"_kt_page_service_sub_title";a:2:{i:0;s:23:"Safe Shopping Guarantee";i:1;s:23:"Safe Shopping Guarantee";}s:27:"_kt_about_service_sub_title";a:2:{i:0;s:23:"Safe Shopping Guarantee";i:1;s:23:"Safe Shopping Guarantee";}s:14:"slide_template";a:2:{i:0;s:7:"default";i:1;s:7:"default";}s:17:"_vc_post_settings";a:2:{i:0;s:30:"a:1:{s:10:"vc_grid_id";a:0:{}}";i:1;s:30:"a:1:{s:10:"vc_grid_id";a:0:{}}";}s:10:"_edit_last";a:2:{i:0;s:1:"1";i:1;s:1:"1";}s:21:"_kt_page_service_desc";a:2:{i:0;s:65:"Our Buyer Protection covers your purchase from click to delivery.";i:1;s:65:"Our Buyer Protection covers your purchase from click to delivery.";}s:10:"_edit_lock";a:1:{i:0;s:12:"1446001621:1";}s:13:"_thumbnail_id";a:2:{i:0;s:4:"2603";i:1;s:4:"2603";}}' );

kt_other_post_type(652, 'service', 0 ,'SAFE PAYMENT', 'Q3VyYWJpdHVyIGEgZmVsaXMgaW4gbnVuYyBmcmluZ2lsbGEgdHJpc3RpcXVlLiBVdCBub24gZW5pbSBlbGVpZmVuZCBmZWxpcyBwcmV0aXVtIGZldWdpYXQuIEluIGNvbnNlY3RldHVlciB0dXJwaXMgdXQgdmVsaXQuIFZlc3RpYnVsdW0gc3VzY2lwaXQgbnVsbGEgcXVpcyBvcmNpLiBNYWVjZW5hcyB2ZXN0aWJ1bHVtIG1vbGxpcyBkaWFtLg0KDQpQcm9pbiB2aXZlcnJhLCBsaWd1bGEgc2l0IGFtZXQgdWx0cmljZXMgc2VtcGVyLCBsaWd1bGEgYXJjdSB0cmlzdGlxdWUgc2FwaWVuLCBhIGFjY3Vtc2FuIG5pc2kgbWF1cmlzIGFjIGVyb3MuIFZpdmFtdXMgZXVpc21vZCBtYXVyaXMuIFBoYXNlbGx1cyB0ZW1wdXMuIENyYXMgcmlzdXMgaXBzdW0sIGZhdWNpYnVzIHV0LCB1bGxhbWNvcnBlciBpZCwgdmFyaXVzIGFjLCBsZW8uIFByb2luIG1hZ25hLg0KDQpWZXN0aWJ1bHVtIHZvbHV0cGF0IHByZXRpdW0gbGliZXJvLiBWaXZhbXVzIGV1aXNtb2QgbWF1cmlzLiBEb25lYyB2ZW5lbmF0aXMgdnVscHV0YXRlIGxvcmVtLiBQZWxsZW50ZXNxdWUgZGFwaWJ1cyBoZW5kcmVyaXQgdG9ydG9yLiBTdXNwZW5kaXNzZSBwb3RlbnRpLg0KDQpDdXJhYml0dXIgdmVzdGlidWx1bSBhbGlxdWFtIGxlby4gUHJhZXNlbnQgdHVycGlzLiBBZW5lYW4gdXQgZXJvcyBldCBuaXNsIHNhZ2l0dGlzIHZlc3RpYnVsdW0uIFBlbGxlbnRlc3F1ZSBjb21tb2RvIGVyb3MgYSBlbmltLiBDcmFzIHVsdHJpY2llcyBtaSBldSB0dXJwaXMgaGVuZHJlcml0IGZyaW5naWxsYS4NCg0KQ3JhcyBub24gZG9sb3IuIEFlbmVhbiBjb21tb2RvIGxpZ3VsYSBlZ2V0IGRvbG9yLiBGdXNjZSBwaGFyZXRyYSBjb252YWxsaXMgdXJuYS4gQWVuZWFuIHBvc3VlcmUsIHRvcnRvciBzZWQgY3Vyc3VzIGZldWdpYXQsIG51bmMgYXVndWUgYmxhbmRpdCBudW5jLCBldSBzb2xsaWNpdHVkaW4gdXJuYSBkb2xvciBzYWdpdHRpcyBsYWN1cy4gRnVzY2UgZmVybWVudHVtIG9kaW8gbmVjIGFyY3Uu', 'http://dev02.ovicsoft.com/thang/kutetheme-wp/?post_type=service&#038;p=652', '', 'closed', 'a:8:{s:26:"_kt_page_service_sub_title";a:2:{i:0;s:18:"On order over $200";i:1;s:18:"On order over $200";}s:27:"_kt_about_service_sub_title";a:2:{i:0;s:18:"On order over $200";i:1;s:18:"On order over $200";}s:14:"slide_template";a:2:{i:0;s:7:"default";i:1;s:7:"default";}s:17:"_vc_post_settings";a:2:{i:0;s:30:"a:1:{s:10:"vc_grid_id";a:0:{}}";i:1;s:30:"a:1:{s:10:"vc_grid_id";a:0:{}}";}s:10:"_edit_last";a:2:{i:0;s:1:"1";i:1;s:1:"1";}s:21:"_kt_page_service_desc";a:2:{i:0;s:63:"Pay with the world’s most popular and secure payment methods.";i:1;s:63:"Pay with the world’s most popular and secure payment methods.";}s:10:"_edit_lock";a:1:{i:0;s:12:"1446001616:1";}s:13:"_thumbnail_id";a:2:{i:0;s:4:"2604";i:1;s:4:"2604";}}' );

kt_other_post_type(653, 'service', 0 ,'WORLDWIDE DELIVERY', 'UHJvaW4gcHJldGl1bSwgbGVvIGFjIHBlbGxlbnRlc3F1ZSBtb2xsaXMsIGZlbGlzIG51bmMgdWx0cmljZXMgZXJvcywgc2VkIGdyYXZpZGEgYXVndWUgYXVndWUgbW9sbGlzIGp1c3RvLiBTdXNwZW5kaXNzZSBuaXNsIGVsaXQsIHJob25jdXMgZWdldCwgZWxlbWVudHVtIGFjLCBjb25kaW1lbnR1bSBlZ2V0LCBkaWFtLiBQcm9pbiBzYXBpZW4gaXBzdW0sIHBvcnRhIGEsIGF1Y3RvciBxdWlzLCBldWlzbW9kIHV0LCBtaS4gU3VzcGVuZGlzc2UgcG90ZW50aS4gVXQgdGluY2lkdW50IHRpbmNpZHVudCBlcmF0Lg0KDQpQaGFzZWxsdXMgbmVjIHNlbSBpbiBqdXN0byBwZWxsZW50ZXNxdWUgZmFjaWxpc2lzLiBTZWQgYXVndWUgaXBzdW0sIGVnZXN0YXMgbmVjLCB2ZXN0aWJ1bHVtIGV0LCBtYWxlc3VhZGEgYWRpcGlzY2luZywgZHVpLiBTdXNwZW5kaXNzZSBuaXNsIGVsaXQsIHJob25jdXMgZWdldCwgZWxlbWVudHVtIGFjLCBjb25kaW1lbnR1bSBlZ2V0LCBkaWFtLiBNb3JiaSBuZWMgbWV0dXMuIEluIGF1Y3RvciBsb2JvcnRpcyBsYWN1cy4NCg0KUGhhc2VsbHVzIGdyYXZpZGEgc2VtcGVyIG5pc2kuIEFsaXF1YW0gZXJhdCB2b2x1dHBhdC4gSW4gZHVpIG1hZ25hLCBwb3N1ZXJlIGVnZXQsIHZlc3RpYnVsdW0gZXQsIHRlbXBvciBhdWN0b3IsIGp1c3RvLiBQZWxsZW50ZXNxdWUgdXQgbmVxdWUuIEluIGhhYyBoYWJpdGFzc2UgcGxhdGVhIGRpY3R1bXN0Lg0KDQpGdXNjZSBmZXJtZW50dW0uIEN1cmFiaXR1ciBhIGZlbGlzIGluIG51bmMgZnJpbmdpbGxhIHRyaXN0aXF1ZS4gRHVpcyBhcmN1IHRvcnRvciwgc3VzY2lwaXQgZWdldCwgaW1wZXJkaWV0IG5lYywgaW1wZXJkaWV0IGlhY3VsaXMsIGlwc3VtLiBJbiBjb25zZWN0ZXR1ZXIgdHVycGlzIHV0IHZlbGl0LiBOYW0gY29tbW9kbyBzdXNjaXBpdCBxdWFtLg0KDQpQaGFzZWxsdXMgZ3JhdmlkYSBzZW1wZXIgbmlzaS4gTmFtIGlwc3VtIHJpc3VzLCBydXRydW0gdml0YWUsIHZlc3RpYnVsdW0gZXUsIG1vbGVzdGllIHZlbCwgbGFjdXMuIEN1cmFiaXR1ciBhdCBsYWN1cyBhYyB2ZWxpdCBvcm5hcmUgbG9ib3J0aXMuIENyYXMgbm9uIGRvbG9yLiBOYW0gY29tbW9kbyBzdXNjaXBpdCBxdWFtLg==', 'http://dev02.ovicsoft.com/thang/kutetheme-wp/?post_type=service&#038;p=653', '', 'closed', 'a:8:{s:26:"_kt_page_service_sub_title";a:2:{i:0;s:19:"Moneyback guarantee";i:1;s:19:"Moneyback guarantee";}s:27:"_kt_about_service_sub_title";a:2:{i:0;s:19:"Moneyback guarantee";i:1;s:19:"Moneyback guarantee";}s:14:"slide_template";a:2:{i:0;s:7:"default";i:1;s:7:"default";}s:17:"_vc_post_settings";a:2:{i:0;s:30:"a:1:{s:10:"vc_grid_id";a:0:{}}";i:1;s:30:"a:1:{s:10:"vc_grid_id";a:0:{}}";}s:10:"_edit_last";a:2:{i:0;s:1:"1";i:1;s:1:"1";}s:21:"_kt_page_service_desc";a:2:{i:0;s:70:"With sites in 5 languages, we ship to over 200 countries &amp; regions";i:1;s:70:"With sites in 5 languages, we ship to over 200 countries &amp; regions";}s:10:"_edit_lock";a:1:{i:0;s:12:"1446001657:1";}s:13:"_thumbnail_id";a:2:{i:0;s:4:"2601";i:1;s:4:"2601";}}' );

kt_other_post_type(654, 'service', 0 ,'24/7 support', 'U3VzcGVuZGlzc2Ugbm9uIG5pc2wgc2l0IGFtZXQgdmVsaXQgaGVuZHJlcml0IHJ1dHJ1bS4gRG9uZWMgZWxpdCBsaWJlcm8sIHNvZGFsZXMgbmVjLCB2b2x1dHBhdCBhLCBzdXNjaXBpdCBub24sIHR1cnBpcy4gUGVsbGVudGVzcXVlIHV0IG5lcXVlLiBQcmFlc2VudCB2ZXN0aWJ1bHVtIGRhcGlidXMgbmliaC4gUGhhc2VsbHVzIG5lYyBzZW0gaW4ganVzdG8gcGVsbGVudGVzcXVlIGZhY2lsaXNpcy4NCg0KTWF1cmlzIHR1cnBpcyBudW5jLCBibGFuZGl0IGV0LCB2b2x1dHBhdCBtb2xlc3RpZSwgcG9ydGEgdXQsIGxpZ3VsYS4gTmFtIGFkaXBpc2NpbmcuIFByYWVzZW50IGNvbmd1ZSBlcmF0IGF0IG1hc3NhLiBFdGlhbSBmZXVnaWF0IGxvcmVtIG5vbiBtZXR1cy4gRHVpcyBsZW8uDQoNClV0IGEgbmlzbCBpZCBhbnRlIHRlbXB1cyBoZW5kcmVyaXQuIFByYWVzZW50IHZlbmVuYXRpcyBtZXR1cyBhdCB0b3J0b3IgcHVsdmluYXIgdmFyaXVzLiBQZWxsZW50ZXNxdWUgbGliZXJvIHRvcnRvciwgdGluY2lkdW50IGV0LCB0aW5jaWR1bnQgZWdldCwgc2VtcGVyIG5lYywgcXVhbS4gRG9uZWMgaW50ZXJkdW0sIG1ldHVzIGV0IGhlbmRyZXJpdCBhbGlxdWV0LCBkb2xvciBkaWFtIHNhZ2l0dGlzIGxpZ3VsYSwgZWdldCBlZ2VzdGFzIGxpYmVybyB0dXJwaXMgdmVsIG1pLiBDdXJhYml0dXIgdHVycGlzLg0KDQpQZWxsZW50ZXNxdWUgcG9zdWVyZS4gTmFtIGlwc3VtIHJpc3VzLCBydXRydW0gdml0YWUsIHZlc3RpYnVsdW0gZXUsIG1vbGVzdGllIHZlbCwgbGFjdXMuIFV0IGEgbmlzbCBpZCBhbnRlIHRlbXB1cyBoZW5kcmVyaXQuIFV0IHRpbmNpZHVudCB0aW5jaWR1bnQgZXJhdC4gRXRpYW0gc29sbGljaXR1ZGluLCBpcHN1bSBldSBwdWx2aW5hciBydXRydW0sIHRlbGx1cyBpcHN1bSBsYW9yZWV0IHNhcGllbiwgcXVpcyB2ZW5lbmF0aXMgYW50ZSBvZGlvIHNpdCBhbWV0IGVyb3MuDQoNCk51bGxhIG5lcXVlIGRvbG9yLCBzYWdpdHRpcyBlZ2V0LCBpYWN1bGlzIHF1aXMsIG1vbGVzdGllIG5vbiwgdmVsaXQuIFBoYXNlbGx1cyBhIGVzdC4gUGhhc2VsbHVzIGdyYXZpZGEgc2VtcGVyIG5pc2kuIFByYWVzZW50IHR1cnBpcy4gQ3JhcyBpZCBkdWku', 'http://dev02.ovicsoft.com/thang/kutetheme-wp/?post_type=service&#038;p=654', '', 'closed', 'a:8:{s:26:"_kt_page_service_sub_title";a:2:{i:0;s:20:"Online consultations";i:1;s:20:"Online consultations";}s:27:"_kt_about_service_sub_title";a:2:{i:0;s:20:"Online consultations";i:1;s:20:"Online consultations";}s:14:"slide_template";a:2:{i:0;s:7:"default";i:1;s:7:"default";}s:17:"_vc_post_settings";a:2:{i:0;s:30:"a:1:{s:10:"vc_grid_id";a:0:{}}";i:1;s:30:"a:1:{s:10:"vc_grid_id";a:0:{}}";}s:10:"_edit_last";a:2:{i:0;s:1:"1";i:1;s:1:"1";}s:21:"_kt_page_service_desc";a:2:{i:0;s:60:"Round-the-clock assistance for a smooth shopping experience.";i:1;s:60:"Round-the-clock assistance for a smooth shopping experience.";}s:10:"_edit_lock";a:1:{i:0;s:12:"1446001564:1";}s:13:"_thumbnail_id";a:2:{i:0;s:4:"2602";i:1;s:4:"2602";}}' );

kt_other_post_type(724, 'testimonial', 0 ,'Roverto & Maria', 'IllvdXIgcHJvZHVjdCBuZWVkcyB0byBpbXByb3ZlIG1vcmUuIFRvIHN1aXQgdGhlIG5lZWRzIGFuZCB1cGRhdGUgeW91ciBpbWFnZSB1cCI=', 'http://dev02.ovicsoft.com/thang/kutetheme-wp/?post_type=testimonial&#038;p=724', '', 'closed', 'a:4:{s:10:"_edit_last";a:2:{i:0;s:1:"1";i:1;s:1:"1";}s:17:"_vc_post_settings";a:2:{i:0;s:30:"a:1:{s:10:"vc_grid_id";a:0:{}}";i:1;s:30:"a:1:{s:10:"vc_grid_id";a:0:{}}";}s:14:"slide_template";a:2:{i:0;s:7:"default";i:1;s:7:"default";}s:10:"_edit_lock";a:1:{i:0;s:12:"1446019402:1";}}' );

kt_other_post_type(729, 'testimonial', 0 ,'Mary Queen', 'V2Ugd2FudCB0byBkZXNpZ24gdGhlIG1vc3QgYmVhdXRpZnVsIGZhc2hpb24gZm9yIHlvdS4gWW91ciBzdWNjZXNzIGFyZSBvdXIgaGFwcGluZXNz', 'http://dev02.ovicsoft.com/thang/kutetheme-wp/?post_type=testimonial&#038;p=729', '', 'closed', 'a:5:{s:10:"_edit_last";a:2:{i:0;s:1:"1";i:1;s:1:"1";}s:17:"_vc_post_settings";a:2:{i:0;s:30:"a:1:{s:10:"vc_grid_id";a:0:{}}";i:1;s:30:"a:1:{s:10:"vc_grid_id";a:0:{}}";}s:14:"slide_template";a:2:{i:0;s:7:"default";i:1;s:7:"default";}s:10:"_edit_lock";a:1:{i:0;s:12:"1446022178:1";}s:13:"_thumbnail_id";a:2:{i:0;s:4:"2672";i:1;s:4:"2672";}}' );

kt_other_post_type(1804, 'shop_order', 0 ,'Order &ndash; September 16, 2015 @ 01:10 AM', '', 'http://kutethemes.net/wordpress/kuteshop/option1/?post_type=shop_order&amp;p=1668', '', 'open', 'a:38:{s:17:"_vc_post_settings";a:1:{i:0;s:30:"a:1:{s:10:"vc_grid_id";a:0:{}}";}s:10:"_order_key";a:1:{i:0;s:22:"wc_order_55f8c173b116b";}s:15:"_order_currency";a:1:{i:0;s:3:"SGD";}s:19:"_prices_include_tax";a:1:{i:0;s:2:"no";}s:20:"_customer_ip_address";a:1:{i:0;s:13:"117.6.204.186";}s:20:"_customer_user_agent";a:1:{i:0;s:65:"Mozilla/5.0 (Windows NT 6.1; rv:40.0) Gecko/20100101 Firefox/40.0";}s:14:"_customer_user";a:1:{i:0;s:1:"1";}s:12:"_created_via";a:1:{i:0;s:8:"checkout";}s:14:"_order_version";a:1:{i:0;s:5:"2.4.6";}s:19:"_billing_first_name";a:1:{i:0;s:1:"h";}s:18:"_billing_last_name";a:1:{i:0;s:3:"dfg";}s:16:"_billing_company";a:1:{i:0;s:0:"";}s:14:"_billing_email";a:1:{i:0;s:20:"kutethemes@gmail.com";}s:14:"_billing_phone";a:1:{i:0;s:3:"123";}s:16:"_billing_country";a:1:{i:0;s:2:"VN";}s:18:"_billing_address_1";a:1:{i:0;s:5:"dfghj";}s:18:"_billing_address_2";a:1:{i:0;s:0:"";}s:13:"_billing_city";a:1:{i:0;s:4:"cvbn";}s:14:"_billing_state";a:1:{i:0;s:0:"";}s:17:"_billing_postcode";a:1:{i:0;s:3:"XCV";}s:20:"_shipping_first_name";a:1:{i:0;s:1:"h";}s:19:"_shipping_last_name";a:1:{i:0;s:3:"dfg";}s:17:"_shipping_company";a:1:{i:0;s:0:"";}s:17:"_shipping_country";a:1:{i:0;s:2:"VN";}s:19:"_shipping_address_1";a:1:{i:0;s:5:"dfghj";}s:19:"_shipping_address_2";a:1:{i:0;s:0:"";}s:14:"_shipping_city";a:1:{i:0;s:4:"cvbn";}s:15:"_shipping_state";a:1:{i:0;s:0:"";}s:18:"_shipping_postcode";a:1:{i:0;s:3:"XCV";}s:15:"_payment_method";a:1:{i:0;s:6:"cheque";}s:21:"_payment_method_title";a:1:{i:0;s:14:"Cheque Payment";}s:15:"_order_shipping";a:1:{i:0;s:0:"";}s:14:"_cart_discount";a:1:{i:0;s:1:"0";}s:18:"_cart_discount_tax";a:1:{i:0;s:1:"0";}s:10:"_order_tax";a:1:{i:0;s:1:"0";}s:19:"_order_shipping_tax";a:1:{i:0;s:1:"0";}s:12:"_order_total";a:1:{i:0;s:6:"137.00";}s:15:"_recorded_sales";a:1:{i:0;s:3:"yes";}}' );

kt_other_post_type(1806, 'shop_order', 0 ,'Order &ndash; September 21, 2015 @ 07:18 AM', '', 'http://kutethemes.net/wordpress/kuteshop/option1/?post_type=shop_order&amp;p=1707', '', 'open', 'a:38:{s:19:"_shipping_address_1";a:1:{i:0;s:5:"abcde";}s:17:"_shipping_company";a:1:{i:0;s:4:"Ovic";}s:17:"_shipping_country";a:1:{i:0;s:2:"VN";}s:19:"_shipping_last_name";a:1:{i:0;s:2:"Le";}s:20:"_shipping_first_name";a:1:{i:0;s:5:"Emily";}s:17:"_billing_postcode";a:1:{i:0;s:4:"0000";}s:14:"_billing_state";a:1:{i:0;s:0:"";}s:13:"_billing_city";a:1:{i:0;s:11:"Thai Nguyen";}s:18:"_billing_address_2";a:1:{i:0;s:0:"";}s:18:"_billing_address_1";a:1:{i:0;s:5:"abcde";}s:16:"_billing_country";a:1:{i:0;s:2:"VN";}s:14:"_billing_phone";a:1:{i:0;s:10:"3535425454";}s:14:"_billing_email";a:1:{i:0;s:18:"ltminh@ictu.edu.vn";}s:16:"_billing_company";a:1:{i:0;s:4:"Ovic";}s:18:"_billing_last_name";a:1:{i:0;s:2:"Le";}s:19:"_billing_first_name";a:1:{i:0;s:5:"Emily";}s:14:"_order_version";a:1:{i:0;s:5:"2.4.6";}s:12:"_created_via";a:1:{i:0;s:8:"checkout";}s:14:"_customer_user";a:1:{i:0;s:1:"2";}s:15:"_order_currency";a:1:{i:0;s:3:"SGD";}s:19:"_prices_include_tax";a:1:{i:0;s:2:"no";}s:20:"_customer_ip_address";a:1:{i:0;s:13:"117.6.204.186";}s:20:"_customer_user_agent";a:1:{i:0;s:108:"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.93 Safari/537.36";}s:15:"_recorded_sales";a:1:{i:0;s:3:"yes";}s:19:"_shipping_address_2";a:1:{i:0;s:0:"";}s:14:"_shipping_city";a:1:{i:0;s:11:"Thai Nguyen";}s:15:"_shipping_state";a:1:{i:0;s:0:"";}s:18:"_shipping_postcode";a:1:{i:0;s:4:"0000";}s:15:"_payment_method";a:1:{i:0;s:6:"cheque";}s:21:"_payment_method_title";a:1:{i:0;s:14:"Cheque Payment";}s:15:"_order_shipping";a:1:{i:0;s:0:"";}s:14:"_cart_discount";a:1:{i:0;s:1:"0";}s:18:"_cart_discount_tax";a:1:{i:0;s:1:"0";}s:10:"_order_tax";a:1:{i:0;s:1:"0";}s:19:"_order_shipping_tax";a:1:{i:0;s:1:"0";}s:12:"_order_total";a:1:{i:0;s:7:"5151.00";}s:10:"_order_key";a:1:{i:0;s:22:"wc_order_55ffaf30a9afd";}s:17:"_vc_post_settings";a:1:{i:0;s:30:"a:1:{s:10:"vc_grid_id";a:0:{}}";}}' );

kt_other_post_type(2854, 'shop_order', 0 ,'Order &ndash; September 16, 2015 @ 01:10 AM', '', 'http://kutethemes.net/wordpress/kuteshop/option1/?post_type=shop_order&amp;p=1668', '', 'open', 'a:38:{s:17:"_vc_post_settings";a:1:{i:0;s:30:"a:1:{s:10:"vc_grid_id";a:0:{}}";}s:10:"_order_key";a:1:{i:0;s:22:"wc_order_55f8c173b116b";}s:15:"_order_currency";a:1:{i:0;s:3:"SGD";}s:19:"_prices_include_tax";a:1:{i:0;s:2:"no";}s:20:"_customer_ip_address";a:1:{i:0;s:13:"117.6.204.186";}s:20:"_customer_user_agent";a:1:{i:0;s:65:"Mozilla/5.0 (Windows NT 6.1; rv:40.0) Gecko/20100101 Firefox/40.0";}s:14:"_customer_user";a:1:{i:0;s:1:"1";}s:12:"_created_via";a:1:{i:0;s:8:"checkout";}s:14:"_order_version";a:1:{i:0;s:5:"2.4.6";}s:19:"_billing_first_name";a:1:{i:0;s:1:"h";}s:18:"_billing_last_name";a:1:{i:0;s:3:"dfg";}s:16:"_billing_company";a:1:{i:0;s:0:"";}s:14:"_billing_email";a:1:{i:0;s:20:"kutethemes@gmail.com";}s:14:"_billing_phone";a:1:{i:0;s:3:"123";}s:16:"_billing_country";a:1:{i:0;s:2:"VN";}s:18:"_billing_address_1";a:1:{i:0;s:5:"dfghj";}s:18:"_billing_address_2";a:1:{i:0;s:0:"";}s:13:"_billing_city";a:1:{i:0;s:4:"cvbn";}s:14:"_billing_state";a:1:{i:0;s:0:"";}s:17:"_billing_postcode";a:1:{i:0;s:3:"XCV";}s:20:"_shipping_first_name";a:1:{i:0;s:1:"h";}s:19:"_shipping_last_name";a:1:{i:0;s:3:"dfg";}s:17:"_shipping_company";a:1:{i:0;s:0:"";}s:17:"_shipping_country";a:1:{i:0;s:2:"VN";}s:19:"_shipping_address_1";a:1:{i:0;s:5:"dfghj";}s:19:"_shipping_address_2";a:1:{i:0;s:0:"";}s:14:"_shipping_city";a:1:{i:0;s:4:"cvbn";}s:15:"_shipping_state";a:1:{i:0;s:0:"";}s:18:"_shipping_postcode";a:1:{i:0;s:3:"XCV";}s:15:"_payment_method";a:1:{i:0;s:6:"cheque";}s:21:"_payment_method_title";a:1:{i:0;s:14:"Cheque Payment";}s:15:"_order_shipping";a:1:{i:0;s:0:"";}s:14:"_cart_discount";a:1:{i:0;s:1:"0";}s:18:"_cart_discount_tax";a:1:{i:0;s:1:"0";}s:10:"_order_tax";a:1:{i:0;s:1:"0";}s:19:"_order_shipping_tax";a:1:{i:0;s:1:"0";}s:12:"_order_total";a:1:{i:0;s:6:"137.00";}s:15:"_recorded_sales";a:1:{i:0;s:3:"yes";}}' );

kt_other_post_type(2855, 'shop_order', 0 ,'Order &ndash; September 21, 2015 @ 07:18 AM', '', 'http://kutethemes.net/wordpress/kuteshop/option1/?post_type=shop_order&amp;p=1707', '', 'open', 'a:38:{s:19:"_shipping_address_1";a:1:{i:0;s:5:"abcde";}s:17:"_shipping_company";a:1:{i:0;s:4:"Ovic";}s:17:"_shipping_country";a:1:{i:0;s:2:"VN";}s:19:"_shipping_last_name";a:1:{i:0;s:2:"Le";}s:20:"_shipping_first_name";a:1:{i:0;s:5:"Emily";}s:17:"_billing_postcode";a:1:{i:0;s:4:"0000";}s:14:"_billing_state";a:1:{i:0;s:0:"";}s:13:"_billing_city";a:1:{i:0;s:11:"Thai Nguyen";}s:18:"_billing_address_2";a:1:{i:0;s:0:"";}s:18:"_billing_address_1";a:1:{i:0;s:5:"abcde";}s:16:"_billing_country";a:1:{i:0;s:2:"VN";}s:14:"_billing_phone";a:1:{i:0;s:10:"3535425454";}s:14:"_billing_email";a:1:{i:0;s:18:"ltminh@ictu.edu.vn";}s:16:"_billing_company";a:1:{i:0;s:4:"Ovic";}s:18:"_billing_last_name";a:1:{i:0;s:2:"Le";}s:19:"_billing_first_name";a:1:{i:0;s:5:"Emily";}s:14:"_order_version";a:1:{i:0;s:5:"2.4.6";}s:12:"_created_via";a:1:{i:0;s:8:"checkout";}s:14:"_customer_user";a:1:{i:0;s:1:"2";}s:15:"_order_currency";a:1:{i:0;s:3:"SGD";}s:19:"_prices_include_tax";a:1:{i:0;s:2:"no";}s:20:"_customer_ip_address";a:1:{i:0;s:13:"117.6.204.186";}s:20:"_customer_user_agent";a:1:{i:0;s:108:"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.93 Safari/537.36";}s:15:"_recorded_sales";a:1:{i:0;s:3:"yes";}s:19:"_shipping_address_2";a:1:{i:0;s:0:"";}s:14:"_shipping_city";a:1:{i:0;s:11:"Thai Nguyen";}s:15:"_shipping_state";a:1:{i:0;s:0:"";}s:18:"_shipping_postcode";a:1:{i:0;s:4:"0000";}s:15:"_payment_method";a:1:{i:0;s:6:"cheque";}s:21:"_payment_method_title";a:1:{i:0;s:14:"Cheque Payment";}s:15:"_order_shipping";a:1:{i:0;s:0:"";}s:14:"_cart_discount";a:1:{i:0;s:1:"0";}s:18:"_cart_discount_tax";a:1:{i:0;s:1:"0";}s:10:"_order_tax";a:1:{i:0;s:1:"0";}s:19:"_order_shipping_tax";a:1:{i:0;s:1:"0";}s:12:"_order_total";a:1:{i:0;s:7:"5151.00";}s:10:"_order_key";a:1:{i:0;s:22:"wc_order_55ffaf30a9afd";}s:17:"_vc_post_settings";a:1:{i:0;s:30:"a:1:{s:10:"vc_grid_id";a:0:{}}";}}' );

kt_other_post_type(2856, 'shop_order', 0 ,'Order &ndash; November 7, 2015 @ 09:16 PM', '', 'http://kutethemes.net/wordpress/kuteshop/option7/?post_type=shop_order&#038;p=2856', '', 'open', 'a:38:{s:10:"_order_key";a:1:{i:0;s:22:"wc_order_563e6a3734f3e";}s:15:"_order_currency";a:1:{i:0;s:3:"SGD";}s:19:"_prices_include_tax";a:1:{i:0;s:2:"no";}s:20:"_customer_ip_address";a:1:{i:0;s:14:"49.207.181.248";}s:20:"_customer_user_agent";a:1:{i:0;s:109:"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.80 Safari/537.36";}s:14:"_customer_user";a:1:{i:0;s:1:"2";}s:12:"_created_via";a:1:{i:0;s:8:"checkout";}s:14:"_order_version";a:1:{i:0;s:5:"2.4.8";}s:19:"_billing_first_name";a:1:{i:0;s:9:"nagendren";}s:18:"_billing_last_name";a:1:{i:0;s:7:"santosh";}s:16:"_billing_company";a:1:{i:0;s:6:"dummie";}s:14:"_billing_email";a:1:{i:0;s:22:"nagendrenk92@gmail.com";}s:14:"_billing_phone";a:1:{i:0;s:10:"9940277245";}s:16:"_billing_country";a:1:{i:0;s:2:"IN";}s:18:"_billing_address_1";a:1:{i:0;s:11:"bchgbbndfsd";}s:18:"_billing_address_2";a:1:{i:0;s:10:"ffnbndfsdf";}s:13:"_billing_city";a:1:{i:0;s:7:"chennai";}s:14:"_billing_state";a:1:{i:0;s:2:"TN";}s:17:"_billing_postcode";a:1:{i:0;s:6:"600100";}s:20:"_shipping_first_name";a:1:{i:0;s:9:"nagendren";}s:19:"_shipping_last_name";a:1:{i:0;s:7:"santosh";}s:17:"_shipping_company";a:1:{i:0;s:6:"dummie";}s:17:"_shipping_country";a:1:{i:0;s:2:"IN";}s:19:"_shipping_address_1";a:1:{i:0;s:11:"bchgbbndfsd";}s:19:"_shipping_address_2";a:1:{i:0;s:10:"ffnbndfsdf";}s:14:"_shipping_city";a:1:{i:0;s:7:"chennai";}s:15:"_shipping_state";a:1:{i:0;s:2:"TN";}s:18:"_shipping_postcode";a:1:{i:0;s:6:"600100";}s:15:"_payment_method";a:1:{i:0;s:6:"cheque";}s:21:"_payment_method_title";a:1:{i:0;s:14:"Cheque Payment";}s:15:"_order_shipping";a:1:{i:0;s:0:"";}s:14:"_cart_discount";a:1:{i:0;s:1:"0";}s:18:"_cart_discount_tax";a:1:{i:0;s:1:"0";}s:10:"_order_tax";a:1:{i:0;s:1:"0";}s:19:"_order_shipping_tax";a:1:{i:0;s:1:"0";}s:12:"_order_total";a:1:{i:0;s:5:"48.00";}s:15:"_recorded_sales";a:1:{i:0;s:3:"yes";}s:20:"_order_stock_reduced";a:1:{i:0;s:1:"1";}}' );

//Menu
$menu_id = kt_add_menu( 115, 'ASIAN', '' );

 // Menu Item
kt_add_menu_item( 2051, $menu_id, 0, 'Vietnamese Pho', 'custom', 2051, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2728, $menu_id, 0, 'Noodles', 'custom', 2728, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2729, $menu_id, 0, 'Seafood', 'custom', 2729, 'custom', '#', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 116, 'Categories', 'vertical' );

 // Menu Item
kt_add_menu_item( 2131, $menu_id, 0, 'Electronic', 'product_cat', 47, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/electronic/', '', '0', '2362' );

kt_add_menu_item( 2132, $menu_id, 0, 'Sport & Outdoors', 'product_cat', 72, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/sports/sport-outdoor/', 'enabled', '766', '2363' );

kt_add_menu_item( 2133, $menu_id, 0, 'Smartphone & Tablets', 'product_cat', 71, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/digital/smartphone-tablets/', '', '0', '2364' );

kt_add_menu_item( 2135, $menu_id, 0, 'Health & Beauty Bags', 'product_cat', 53, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/fashion/health-beauty-bags/', '', '0', '2365' );

kt_add_menu_item( 2134, $menu_id, 0, 'Shoes & Accessories', 'product_cat', 69, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/fashion/shoes-accessories/', 'enabled', '764', '2366' );

kt_add_menu_item( 2138, $menu_id, 0, 'Toys & Hobbies', 'product_cat', 80, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/toys-hobbies/', '', '0', '2367' );

kt_add_menu_item( 2136, $menu_id, 0, 'Computers & Networking', 'product_cat', 98, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/digital/computers-networking/', '', '0', '2368' );

kt_add_menu_item( 2137, $menu_id, 0, 'Jewelry & Watches', 'product_cat', 56, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/jewelry/jewelry-watches/', '', '0', '2370' );

kt_add_menu_item( 2139, $menu_id, 0, 'Flashlights & Lamps', 'product_cat', 49, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/electronic/flashlights-lamps/', '', '0', '2371' );

kt_add_menu_item( 2140, $menu_id, 0, 'Cameras & Photo', 'product_cat', 94, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/digital/cameras-photo/', '', '0', '2372' );

kt_add_menu_item( 2141, $menu_id, 0, 'Television', 'product_cat', 76, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/digital/television-2/', '', '0', '2369' );

kt_add_menu_item( 2142, $menu_id, 0, 'Fashion', 'product_cat', 48, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/fashion/', '', '0', '2371' );

kt_add_menu_item( 2143, $menu_id, 0, 'Furniture', 'product_cat', 51, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/furniture/', '', '0', '2362' );

kt_add_menu_item( 2144, $menu_id, 0, 'Health & Beauty', 'product_cat', 106, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/fashion/health-beauty/', '', '0', '2365' );

//Menu
$menu_id = kt_add_menu( 117, 'Chicken', '' );

 // Menu Item
kt_add_menu_item( 2739, $menu_id, 0, 'Italian Pizza', 'custom', 2739, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2740, $menu_id, 0, 'French Cakes', 'custom', 2740, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2741, $menu_id, 0, 'Tops', 'custom', 2741, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2742, $menu_id, 0, 'Tops', 'custom', 2742, 'custom', '#', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 118, 'Company', '' );

 // Menu Item
kt_add_menu_item( 2093, $menu_id, 0, 'About Us', 'custom', 2093, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2770, $menu_id, 0, 'Testimonials', 'custom', 2770, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2771, $menu_id, 0, 'Affiliate Program', 'custom', 2771, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2096, $menu_id, 0, 'Terms & Conditions', 'custom', 2096, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2773, $menu_id, 0, 'Contact Us', 'custom', 2773, 'custom', '#', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 119, 'Company Info - Partnerships', '' );

 // Menu Item
kt_add_menu_item( 2779, $menu_id, 0, 'Company Info - Partnerships', 'custom', 2779, 'custom', '#', '', '', '' );

kt_add_menu_item( 2103, $menu_id, 0, 'Company Info - Partnerships', 'custom', 2103, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 121, 'Digital', '' );

 // Menu Item
kt_add_menu_item( 2078, $menu_id, 0, 'Mobile', 'custom', 2078, 'custom', '#', '', '', '' );

kt_add_menu_item( 2754, $menu_id, 0, 'Mobile', 'custom', 2754, 'custom', '#', '', '', '' );

kt_add_menu_item( 2755, $menu_id, 0, 'Tablets', 'custom', 2755, 'custom', '#', '', '', '' );

kt_add_menu_item( 2079, $menu_id, 0, 'Tablets', 'custom', 2079, 'custom', '#', '', '', '' );

kt_add_menu_item( 2756, $menu_id, 0, 'Laptop', 'custom', 2756, 'custom', '#', '', '', '' );

kt_add_menu_item( 2080, $menu_id, 0, 'Laptop', 'custom', 2080, 'custom', '#', '', '', '' );

kt_add_menu_item( 2081, $menu_id, 0, 'Memory Cards', 'custom', 2081, 'custom', '#', '', '', '' );

kt_add_menu_item( 2757, $menu_id, 0, 'Memory Cards', 'custom', 2757, 'custom', '#', '', '', '' );

kt_add_menu_item( 2758, $menu_id, 0, 'Accessories', 'custom', 2758, 'custom', '#', '', '', '' );

kt_add_menu_item( 2082, $menu_id, 0, 'Accessories', 'custom', 2082, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 122, 'euro', '' );

 // Menu Item
kt_add_menu_item( 2056, $menu_id, 0, 'Greek Potatoes', 'custom', 2056, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2743, $menu_id, 0, 'Famous Spaghetti', 'custom', 2743, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2744, $menu_id, 0, 'Famous Spaghetti', 'custom', 2744, 'custom', '#', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 123, 'Fashion', '' );

 // Menu Item
kt_add_menu_item( 2156, $menu_id, 0, 'Skirts', 'custom', 2156, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2833, $menu_id, 0, 'Jackets', 'custom', 2833, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2834, $menu_id, 0, 'Tops', 'custom', 2834, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2159, $menu_id, 0, 'Scarves', 'custom', 2159, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2836, $menu_id, 0, 'Pants', 'custom', 2836, 'custom', '#', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 124, 'Fast', '' );

 // Menu Item
kt_add_menu_item( 2071, $menu_id, 0, 'Hamberger', 'custom', 2071, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2748, $menu_id, 0, 'Pizza', 'custom', 2748, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2749, $menu_id, 0, 'Noodles', 'custom', 2749, 'custom', '#', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 183, 'Footer Menu', 'custom_footer_menu' );

 // Menu Item
kt_add_menu_item( 2848, $menu_id, 0, 'About Us', 'custom', 2848, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2374, $menu_id, 0, 'Affiliates', 'custom', 2374, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2375, $menu_id, 0, 'Careers', 'custom', 2375, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2376, $menu_id, 0, 'Privacy Plocy', 'custom', 2376, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2377, $menu_id, 0, 'Terms of Use', 'custom', 2377, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2378, $menu_id, 0, 'Contact Us', 'custom', 2378, 'custom', '#', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 128, 'Kids', '' );

 // Menu Item
kt_add_menu_item( 2151, $menu_id, 0, 'Shoes', 'custom', 2151, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/fashion/', '', '0', '' );

kt_add_menu_item( 2152, $menu_id, 0, 'Clothing', 'custom', 2152, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/fashion/', '', '0', '' );

kt_add_menu_item( 2153, $menu_id, 0, 'Tops', 'custom', 2153, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/fashion/', '', '0', '' );

kt_add_menu_item( 2154, $menu_id, 0, 'Scarves', 'custom', 2154, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/fashion/', '', '0', '' );

kt_add_menu_item( 2155, $menu_id, 0, 'Accessories', 'custom', 2155, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/fashion/', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 129, 'Main menu', 'primary' );

 // Menu Item
kt_add_menu_item( 2172, $menu_id, 0, 'Home', 'page', 347, 'post_type', 'http://kutethemes.net/wordpress/kuteshop/option7/', '', '0', '' );

kt_add_menu_item( 2165, $menu_id, 2172, 'Home 1', 'custom', 2165, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option1/', '', '0', '' );

kt_add_menu_item( 2166, $menu_id, 2172, 'Home 2', 'custom', 2166, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option2/', '', '0', '' );

kt_add_menu_item( 2358, $menu_id, 2172, 'Home 3', 'custom', 2358, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option3/', '', '0', '' );

kt_add_menu_item( 2359, $menu_id, 2172, 'Home 4', 'custom', 2359, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option4/', '', '0', '' );

kt_add_menu_item( 2360, $menu_id, 2172, 'Home 5', 'custom', 2360, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option5/', '', '0', '' );

kt_add_menu_item( 2167, $menu_id, 2172, 'Home 6', 'custom', 2167, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option6/', '', '0', '' );

kt_add_menu_item( 2361, $menu_id, 2172, 'Home 7', 'custom', 2361, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option7/', '', '0', '' );

kt_add_menu_item( 2057, $menu_id, 0, 'Fashion', 'product_cat', 48, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/fashion/', 'enabled', '55', '' );

kt_add_menu_item( 2059, $menu_id, 0, 'Sports', 'product_cat', 73, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/sports/', '', '0', '' );

kt_add_menu_item( 2058, $menu_id, 0, 'Foods', 'product_cat', 50, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/foods/', 'enabled', '835', '' );

kt_add_menu_item( 2060, $menu_id, 0, 'Digital', 'product_cat', 46, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/digital/', '', '0', '' );

kt_add_menu_item( 2083, $menu_id, 2060, 'Mobile', 'custom', 2083, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/digital/mobile/', '', '0', '' );

kt_add_menu_item( 2085, $menu_id, 2060, 'Laptop', 'custom', 2085, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/digital/laptop/', '', '0', '' );

kt_add_menu_item( 2084, $menu_id, 2060, 'Camera', 'custom', 2084, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/digital/camera/', '', '0', '' );

kt_add_menu_item( 2086, $menu_id, 2060, 'Notebook', 'custom', 2086, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/digital/notebook/', '', '0', '' );

kt_add_menu_item( 2087, $menu_id, 2060, 'Computer', 'custom', 2087, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/digital/computers-networking/', '', '0', '' );

kt_add_menu_item( 2061, $menu_id, 0, 'Furniture', 'product_cat', 51, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/furniture/', '', '0', '' );

kt_add_menu_item( 2062, $menu_id, 0, 'Jewelry', 'product_cat', 55, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/jewelry/', '', '0', '' );

kt_add_menu_item( 2842, $menu_id, 0, 'Blog', 'page', 1188, 'post_type', 'http://kutethemes.net/wordpress/kuteshop/option7/sample-page-2/', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 130, 'Men&#039;s', '' );

 // Menu Item
kt_add_menu_item( 2044, $menu_id, 0, 'Jackets', 'product_cat', 108, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/fashion/mens/jackets/', '', '0', '' );

kt_add_menu_item( 2721, $menu_id, 0, 'Skirts', 'product_cat', 70, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/fashion/mens/skirts/', '', '0', '' );

kt_add_menu_item( 2722, $menu_id, 0, 'Tops', 'product_cat', 79, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/fashion/mens/tops/', '', '0', '' );

kt_add_menu_item( 2163, $menu_id, 0, 'Scarves', 'product_cat', 68, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/fashion/scarves/', '', '0', '' );

kt_add_menu_item( 2838, $menu_id, 0, 'T_Shirt', 'product_cat', 75, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/fashion/t_shirt/', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 131, 'Most Populars', '' );

 // Menu Item
kt_add_menu_item( 2787, $menu_id, 0, 'Most Populars', 'custom', 2787, 'custom', '#', '', '', '' );

kt_add_menu_item( 2111, $menu_id, 0, 'Most Populars', 'custom', 2111, 'custom', '#', '', '', '' );

kt_add_menu_item( 2788, $menu_id, 0, 'Best Sellers', 'custom', 2788, 'custom', '#', '', '', '' );

kt_add_menu_item( 2112, $menu_id, 0, 'Best Sellers', 'custom', 2112, 'custom', '#', '', '', '' );

kt_add_menu_item( 2789, $menu_id, 0, 'New Arrivals', 'custom', 2789, 'custom', '#', '', '', '' );

kt_add_menu_item( 2113, $menu_id, 0, 'New Arrivals', 'custom', 2113, 'custom', '#', '', '', '' );

kt_add_menu_item( 2790, $menu_id, 0, 'Special Products', 'custom', 2790, 'custom', '#', '', '', '' );

kt_add_menu_item( 2114, $menu_id, 0, 'Special Products', 'custom', 2114, 'custom', '#', '', '', '' );

kt_add_menu_item( 2791, $menu_id, 0, 'Manufacturers', 'custom', 2791, 'custom', '#', '', '', '' );

kt_add_menu_item( 2115, $menu_id, 0, 'Manufacturers', 'custom', 2115, 'custom', '#', '', '', '' );

kt_add_menu_item( 2792, $menu_id, 0, 'Our Stores', 'custom', 2792, 'custom', '#', '', '', '' );

kt_add_menu_item( 2116, $menu_id, 0, 'Our Stores', 'custom', 2116, 'custom', '#', '', '', '' );

kt_add_menu_item( 2793, $menu_id, 0, 'Shipping', 'custom', 2793, 'custom', '#', '', '', '' );

kt_add_menu_item( 2117, $menu_id, 0, 'Shipping', 'custom', 2117, 'custom', '#', '', '', '' );

kt_add_menu_item( 2794, $menu_id, 0, 'Payments', 'custom', 2794, 'custom', '#', '', '', '' );

kt_add_menu_item( 2118, $menu_id, 0, 'Payments', 'custom', 2118, 'custom', '#', '', '', '' );

kt_add_menu_item( 2119, $menu_id, 0, 'Payments', 'custom', 2119, 'custom', '#', '', '', '' );

kt_add_menu_item( 2795, $menu_id, 0, 'Payments', 'custom', 2795, 'custom', '#', '', '', '' );

kt_add_menu_item( 2796, $menu_id, 0, 'Refunds', 'custom', 2796, 'custom', '#', '', '', '' );

kt_add_menu_item( 2120, $menu_id, 0, 'Refunds', 'custom', 2120, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 132, 'My account', '' );

 // Menu Item
kt_add_menu_item( 2774, $menu_id, 0, 'My Order', 'custom', 2774, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2775, $menu_id, 0, 'My Wishlist', 'custom', 2775, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2776, $menu_id, 0, 'My Credit Slip', 'custom', 2776, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2101, $menu_id, 0, 'My Addresses', 'custom', 2101, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2778, $menu_id, 0, 'My Personal In', 'custom', 2778, 'custom', '#', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 135, 'OnlineShop', '' );

 // Menu Item
kt_add_menu_item( 2780, $menu_id, 0, 'Online Shopping', 'custom', 2780, 'custom', '#', '', '', '' );

kt_add_menu_item( 2104, $menu_id, 0, 'Online Shopping', 'custom', 2104, 'custom', '#', '', '', '' );

kt_add_menu_item( 2781, $menu_id, 0, 'Promotions', 'custom', 2781, 'custom', '#', '', '', '' );

kt_add_menu_item( 2105, $menu_id, 0, 'Promotions', 'custom', 2105, 'custom', '#', '', '', '' );

kt_add_menu_item( 2782, $menu_id, 0, 'My Orders', 'custom', 2782, 'custom', '#', '', '', '' );

kt_add_menu_item( 2106, $menu_id, 0, 'My Orders', 'custom', 2106, 'custom', '#', '', '', '' );

kt_add_menu_item( 2783, $menu_id, 0, 'Help', 'custom', 2783, 'custom', '#', '', '', '' );

kt_add_menu_item( 2107, $menu_id, 0, 'Help', 'custom', 2107, 'custom', '#', '', '', '' );

kt_add_menu_item( 2108, $menu_id, 0, 'Site Map', 'custom', 2108, 'custom', '#', '', '', '' );

kt_add_menu_item( 2784, $menu_id, 0, 'Site Map', 'custom', 2784, 'custom', '#', '', '', '' );

kt_add_menu_item( 2785, $menu_id, 0, 'Customer Service', 'custom', 2785, 'custom', '#', '', '', '' );

kt_add_menu_item( 2109, $menu_id, 0, 'Customer Service', 'custom', 2109, 'custom', '#', '', '', '' );

kt_add_menu_item( 2786, $menu_id, 0, 'Support', 'custom', 2786, 'custom', '#', '', '', '' );

kt_add_menu_item( 2110, $menu_id, 0, 'Support', 'custom', 2110, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 137, 'Sandwich', '' );

 // Menu Item
kt_add_menu_item( 2750, $menu_id, 0, 'Salad', 'custom', 2750, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2751, $menu_id, 0, 'Paste', 'custom', 2751, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2752, $menu_id, 0, 'Tops', 'custom', 2752, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2753, $menu_id, 0, 'Tops', 'custom', 2753, 'custom', '#', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 138, 'SAUSAGES', '' );

 // Menu Item
kt_add_menu_item( 2730, $menu_id, 0, 'Meat Dishes', 'custom', 2730, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2731, $menu_id, 0, 'Desserts', 'custom', 2731, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2745, $menu_id, 0, 'Tops', 'custom', 2745, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2746, $menu_id, 0, 'Tops', 'custom', 2746, 'custom', '#', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 140, 'Sports', '' );

 // Menu Item
kt_add_menu_item( 2145, $menu_id, 0, 'Tennis', 'custom', 2145, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/sports/', '', '0', '' );

kt_add_menu_item( 2146, $menu_id, 0, 'Coats & Jackets', 'custom', 2146, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/sports/', '', '0', '' );

kt_add_menu_item( 2147, $menu_id, 0, 'Blouses & Shirts', 'custom', 2147, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/sports/', '', '0', '' );

kt_add_menu_item( 2148, $menu_id, 0, 'Tops & Tees', 'custom', 2148, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/sports/', '', '0', '' );

kt_add_menu_item( 2149, $menu_id, 0, 'Hoodies & Sweatshirts', 'custom', 2149, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/sports/', '', '0', '' );

kt_add_menu_item( 2150, $menu_id, 0, 'Intimates', 'custom', 2150, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/sports/', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 141, 'Support', '' );

 // Menu Item
kt_add_menu_item( 2764, $menu_id, 0, 'About us', 'custom', 2764, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2765, $menu_id, 0, 'Testimonials', 'custom', 2765, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2090, $menu_id, 0, 'Affiliate Program', 'custom', 2090, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2767, $menu_id, 0, 'Terms & Conditions', 'custom', 2767, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2092, $menu_id, 0, 'Contact Us', 'custom', 2092, 'custom', '#', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 142, 'Terms &amp; Conditions', '' );

 // Menu Item
kt_add_menu_item( 2797, $menu_id, 0, 'Terms & Conditions', 'custom', 2797, 'custom', '#', '', '', '' );

kt_add_menu_item( 2121, $menu_id, 0, 'Terms & Conditions', 'custom', 2121, 'custom', '#', '', '', '' );

kt_add_menu_item( 2798, $menu_id, 0, 'Policy', 'custom', 2798, 'custom', '#', '', '', '' );

kt_add_menu_item( 2122, $menu_id, 0, 'Policy', 'custom', 2122, 'custom', '#', '', '', '' );

kt_add_menu_item( 2799, $menu_id, 0, 'Policy', 'custom', 2799, 'custom', '#', '', '', '' );

kt_add_menu_item( 2123, $menu_id, 0, 'Policy', 'custom', 2123, 'custom', '#', '', '', '' );

kt_add_menu_item( 2800, $menu_id, 0, 'Shipping', 'custom', 2800, 'custom', '#', '', '', '' );

kt_add_menu_item( 2124, $menu_id, 0, 'Shipping', 'custom', 2124, 'custom', '#', '', '', '' );

kt_add_menu_item( 2801, $menu_id, 0, 'Payments', 'custom', 2801, 'custom', '#', '', '', '' );

kt_add_menu_item( 2125, $menu_id, 0, 'Payments', 'custom', 2125, 'custom', '#', '', '', '' );

kt_add_menu_item( 2802, $menu_id, 0, 'Returns', 'custom', 2802, 'custom', '#', '', '', '' );

kt_add_menu_item( 2126, $menu_id, 0, 'Returns', 'custom', 2126, 'custom', '#', '', '', '' );

kt_add_menu_item( 2803, $menu_id, 0, 'Refunds', 'custom', 2803, 'custom', '#', '', '', '' );

kt_add_menu_item( 2127, $menu_id, 0, 'Refunds', 'custom', 2127, 'custom', '#', '', '', '' );

kt_add_menu_item( 2804, $menu_id, 0, 'Warrantee', 'custom', 2804, 'custom', '#', '', '', '' );

kt_add_menu_item( 2128, $menu_id, 0, 'Warrantee', 'custom', 2128, 'custom', '#', '', '', '' );

kt_add_menu_item( 2129, $menu_id, 0, 'FAQ', 'custom', 2129, 'custom', '#', '', '', '' );

kt_add_menu_item( 2805, $menu_id, 0, 'FAQ', 'custom', 2805, 'custom', '#', '', '', '' );

kt_add_menu_item( 2806, $menu_id, 0, 'Contact', 'custom', 2806, 'custom', '#', '', '', '' );

kt_add_menu_item( 2130, $menu_id, 0, 'Contact', 'custom', 2130, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 248, 'Topbar menu left', 'topbar_menuleft' );

 // Menu Item
kt_add_menu_item( 2857, $menu_id, 0, '<i class=\"fa fa-phone\"></i> +00 123 456 789', 'custom', 2857, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2858, $menu_id, 0, '<i class=\"fa fa-envelope\"></i> Contact us today !', 'custom', 2858, 'custom', '#', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 249, 'Topbar menu right', 'topbar_menuright' );

 // Menu Item
kt_add_menu_item( 2859, $menu_id, 0, 'Support', 'page', 371, 'post_type', 'http://kutethemes.net/wordpress/kuteshop/option7/support/', '', '0', '' );

kt_add_menu_item( 2860, $menu_id, 0, 'Services', 'page', 369, 'post_type', 'http://kutethemes.net/wordpress/kuteshop/option7/services/', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 143, 'Trending', '' );

 // Menu Item
kt_add_menu_item( 2047, $menu_id, 0, 'Men\'s Clothing', 'custom', 2047, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/fashion/', '', '0', '' );

kt_add_menu_item( 2048, $menu_id, 0, 'Kid\'s Clothing', 'custom', 2048, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/fashion/', '', '0', '' );

kt_add_menu_item( 2049, $menu_id, 0, 'Women\'s Clothing', 'custom', 2049, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/fashion/', '', '0', '' );

kt_add_menu_item( 2050, $menu_id, 0, 'Accessories', 'custom', 2050, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option7/product-category/fashion/', '', '0', '' );

