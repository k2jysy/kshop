<?php

kt_download_media(877, 'trending', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/trending.png');

kt_download_media(878, 'banner-topmenu', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/banner-topmenu.jpg');

kt_download_media(880, 'banner-megamenu', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/banner-megamenu.jpg');

kt_download_media(881, 'payment-logo', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/payment-logo.png');

kt_download_media(882, 'bg14.png', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/revslider/kute-opt11/bg14.png');

kt_download_media(906, '59', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/59.jpg');
