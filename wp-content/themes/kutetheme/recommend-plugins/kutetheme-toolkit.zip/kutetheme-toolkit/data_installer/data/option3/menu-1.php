<?php
//Menu
$menu_id = kt_add_menu( 157, 'ASIAN', '' );

 // Menu Item
kt_add_menu_item( 1875, $menu_id, 0, 'Vietnamese Pho', 'custom', 1875, 'custom', '#', '', '', '' );

kt_add_menu_item( 1884, $menu_id, 0, 'Noodles', 'custom', 1884, 'custom', '#', '', '', '' );

kt_add_menu_item( 1885, $menu_id, 0, 'Seafood', 'custom', 1885, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 158, 'Categories', 'vertical' );

 // Menu Item
kt_add_menu_item( 1963, $menu_id, 0, 'Source', 'product_cat', 89, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/source/', '', '0', '2282' );

kt_add_menu_item( 1964, $menu_id, 0, 'Sport & Outdoors', 'product_cat', 114, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/sport-outdoor/', 'enabled', '766', '2283' );

kt_add_menu_item( 1965, $menu_id, 0, 'Smartphone & Tablets', 'product_cat', 113, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/digital/smartphone-tablets/', '', '0', '2284' );

kt_add_menu_item( 1967, $menu_id, 0, 'Health & Beauty Bags', 'product_cat', 95, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/fashion/health-beauty-bags/', '', '0', '2285' );

kt_add_menu_item( 1966, $menu_id, 0, 'Shoes & Accessories', 'product_cat', 111, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/fashion/shoes-accessories/', 'enabled', '764', '2286' );

kt_add_menu_item( 1970, $menu_id, 0, 'Toys & Hobbies', 'product_cat', 122, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/toys-hobbies/', '', '0', '2287' );

kt_add_menu_item( 1968, $menu_id, 0, 'Computers & Networking', 'product_cat', 140, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/digital/computers-networking/', '', '0', '2288' );

kt_add_menu_item( 1972, $menu_id, 0, 'Cameras & Photo', 'product_cat', 136, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/digital/cameras-photo/', '', '0', '2291' );

kt_add_menu_item( 1973, $menu_id, 0, 'Television', 'product_cat', 118, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/digital/television-2/', '', '0', '2292' );

kt_add_menu_item( 1974, $menu_id, 0, 'Fashion', 'product_cat', 90, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/fashion/', '', '0', '2290' );

kt_add_menu_item( 1975, $menu_id, 0, 'Furniture', 'product_cat', 93, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/furniture/', '', '0', '2291' );

kt_add_menu_item( 2472, $menu_id, 0, 'Television', 'product_cat', 118, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/digital/television-2/', '', '0', '2474' );

kt_add_menu_item( 2473, $menu_id, 0, 'Jewelry', 'product_cat', 97, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/jewelry/', '', '0', '2289' );

//Menu
$menu_id = kt_add_menu( 159, 'Chicken', '' );

 // Menu Item
kt_add_menu_item( 1895, $menu_id, 0, 'Italian Pizza', 'custom', 1895, 'custom', '#', '', '', '' );

kt_add_menu_item( 1896, $menu_id, 0, 'French Cakes', 'custom', 1896, 'custom', '#', '', '', '' );

kt_add_menu_item( 1897, $menu_id, 0, 'Tops', 'custom', 1897, 'custom', '#', '', '', '' );

kt_add_menu_item( 1898, $menu_id, 0, 'Tops', 'custom', 1898, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 160, 'Company', '' );

 // Menu Item
kt_add_menu_item( 1925, $menu_id, 0, 'About Us', 'custom', 1925, 'custom', '#', '', '', '' );

kt_add_menu_item( 1926, $menu_id, 0, 'Testimonials', 'custom', 1926, 'custom', '#', '', '', '' );

kt_add_menu_item( 1927, $menu_id, 0, 'Affiliate Program', 'custom', 1927, 'custom', '#', '', '', '' );

kt_add_menu_item( 1928, $menu_id, 0, 'Terms & Conditions', 'custom', 1928, 'custom', '#', '', '', '' );

kt_add_menu_item( 1929, $menu_id, 0, 'Contact Us', 'custom', 1929, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 161, 'Company Info - Partnerships', '' );

 // Menu Item
kt_add_menu_item( 1935, $menu_id, 0, 'Company Info - Partnerships', 'custom', 1935, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 202, 'Custom Footer', 'custom_footer_menu' );

 // Menu Item
kt_add_menu_item( 2333, $menu_id, 0, 'About us', 'custom', 2333, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2334, $menu_id, 0, 'Affiliates', 'custom', 2334, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2335, $menu_id, 0, 'Careers', 'custom', 2335, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2336, $menu_id, 0, 'Privacy Policy', 'custom', 2336, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2337, $menu_id, 0, 'Terms of Use', 'custom', 2337, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2338, $menu_id, 0, 'Contact Us', 'custom', 2338, 'custom', '#', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 200, 'Custom Header', 'custom_header_menu' );

 // Menu Item
kt_add_menu_item( 2277, $menu_id, 0, 'Promotion', 'custom', 2277, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2278, $menu_id, 0, 'Payment', 'custom', 2278, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2279, $menu_id, 0, 'Shipping', 'custom', 2279, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2280, $menu_id, 0, 'Return', 'custom', 2280, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2281, $menu_id, 0, 'Call us: +1222 666 888', 'custom', 2281, 'custom', '#', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 163, 'Digital', '' );

 // Menu Item
kt_add_menu_item( 1910, $menu_id, 0, 'Mobile', 'custom', 1910, 'custom', '#', '', '', '' );

kt_add_menu_item( 1911, $menu_id, 0, 'Tablets', 'custom', 1911, 'custom', '#', '', '', '' );

kt_add_menu_item( 1912, $menu_id, 0, 'Laptop', 'custom', 1912, 'custom', '#', '', '', '' );

kt_add_menu_item( 1913, $menu_id, 0, 'Memory Cards', 'custom', 1913, 'custom', '#', '', '', '' );

kt_add_menu_item( 1914, $menu_id, 0, 'Accessories', 'custom', 1914, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 164, 'euro', '' );

 // Menu Item
kt_add_menu_item( 1888, $menu_id, 0, 'Greek Potatoes', 'custom', 1888, 'custom', '#', '', '', '' );

kt_add_menu_item( 1899, $menu_id, 0, 'Famous Spaghetti', 'custom', 1899, 'custom', '#', '', '', '' );

kt_add_menu_item( 1900, $menu_id, 0, 'Famous Spaghetti', 'custom', 1900, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 165, 'Fashion', '' );

 // Menu Item
kt_add_menu_item( 1988, $menu_id, 0, 'Skirts', 'custom', 1988, 'custom', '#', '', '', '' );

kt_add_menu_item( 1989, $menu_id, 0, 'Jackets', 'custom', 1989, 'custom', '#', '', '', '' );

kt_add_menu_item( 1990, $menu_id, 0, 'Tops', 'custom', 1990, 'custom', '#', '', '', '' );

kt_add_menu_item( 1991, $menu_id, 0, 'Scarves', 'custom', 1991, 'custom', '#', '', '', '' );

kt_add_menu_item( 1992, $menu_id, 0, 'Pants', 'custom', 1992, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 166, 'Fast', '' );

 // Menu Item
kt_add_menu_item( 1903, $menu_id, 0, 'Hamberger', 'custom', 1903, 'custom', '#', '', '', '' );

kt_add_menu_item( 1904, $menu_id, 0, 'Pizza', 'custom', 1904, 'custom', '#', '', '', '' );

kt_add_menu_item( 1905, $menu_id, 0, 'Noodles', 'custom', 1905, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 170, 'Kids', '' );

 // Menu Item
kt_add_menu_item( 1983, $menu_id, 0, 'Shoes', 'custom', 1983, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/fashion/', '', '0', '' );

kt_add_menu_item( 1984, $menu_id, 0, 'Clothing', 'custom', 1984, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/fashion/', '', '0', '' );

kt_add_menu_item( 1985, $menu_id, 0, 'Tops', 'custom', 1985, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/fashion/', '', '0', '' );

kt_add_menu_item( 1986, $menu_id, 0, 'Scarves', 'custom', 1986, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/fashion/', '', '0', '' );

kt_add_menu_item( 1987, $menu_id, 0, 'Accessories', 'custom', 1987, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/fashion/', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 171, 'Main menu', 'primary' );

 // Menu Item
kt_add_menu_item( 1994, $menu_id, 0, 'Home', 'page', 347, 'post_type', 'http://kutethemes.net/wordpress/kuteshop/option3/', '', '0', '' );

kt_add_menu_item( 1997, $menu_id, 1994, 'Home 1', 'custom', 1997, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option1/', '', '0', '' );

kt_add_menu_item( 1998, $menu_id, 1994, 'Home 2', 'custom', 1998, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option2/', '', '0', '' );

kt_add_menu_item( 1999, $menu_id, 1994, 'Home 6', 'custom', 1999, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option6/', '', '0', '' );

kt_add_menu_item( 1889, $menu_id, 0, 'Fashion', 'product_cat', 90, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/fashion/', 'enabled', '55', '' );

kt_add_menu_item( 1891, $menu_id, 0, 'Sports', 'product_cat', 115, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/sport-outdoor/sports/', '', '0', '' );

kt_add_menu_item( 1890, $menu_id, 0, 'Foods', 'product_cat', 92, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/foods/', 'enabled', '835', '' );

kt_add_menu_item( 1892, $menu_id, 0, 'Digital', 'product_cat', 88, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/digital/', '', '0', '' );

kt_add_menu_item( 1915, $menu_id, 1892, 'Mobile', 'custom', 1915, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/digital/mobile/', '', '0', '' );

kt_add_menu_item( 1916, $menu_id, 1892, 'Tablets', 'custom', 1916, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/digital/', '', '0', '' );

kt_add_menu_item( 1917, $menu_id, 1892, 'Laptop', 'custom', 1917, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/digital/laptop/', '', '0', '' );

kt_add_menu_item( 1918, $menu_id, 1892, 'Notebook', 'custom', 1918, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/digital/notebook/', '', '0', '' );

kt_add_menu_item( 1919, $menu_id, 1892, 'Accessories', 'custom', 1919, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/digital/', '', '0', '' );

kt_add_menu_item( 1893, $menu_id, 0, 'Furniture', 'product_cat', 93, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/furniture/', '', '0', '' );

kt_add_menu_item( 1894, $menu_id, 0, 'Jewelry', 'product_cat', 97, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/jewelry/', '', '0', '' );

kt_add_menu_item( 1993, $menu_id, 0, 'Blog', 'page', 1188, 'post_type', 'http://kutethemes.net/wordpress/kuteshop/option3/sample-page-2/', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 172, 'Men&#039;s', '' );

 // Menu Item
kt_add_menu_item( 1869, $menu_id, 0, 'Skirts', 'product_cat', 112, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/fashion/mens/skirts/', '', '0', '' );

kt_add_menu_item( 1870, $menu_id, 0, 'Tops', 'product_cat', 121, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/fashion/mens/tops/', '', '0', '' );

kt_add_menu_item( 1995, $menu_id, 0, 'Scarves', 'product_cat', 110, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/fashion/scarves/', '', '0', '' );

kt_add_menu_item( 1996, $menu_id, 0, 'T_Shirt', 'product_cat', 117, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/fashion/t_shirt/', '', '0', '' );

kt_add_menu_item( 2397, $menu_id, 0, 'Jackets', 'custom', 2397, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/fashion/', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 173, 'Most Populars', '' );

 // Menu Item
kt_add_menu_item( 1943, $menu_id, 0, 'Most Populars', 'custom', 1943, 'custom', '#', '', '', '' );

kt_add_menu_item( 1944, $menu_id, 0, 'Best Sellers', 'custom', 1944, 'custom', '#', '', '', '' );

kt_add_menu_item( 1945, $menu_id, 0, 'New Arrivals', 'custom', 1945, 'custom', '#', '', '', '' );

kt_add_menu_item( 1946, $menu_id, 0, 'Special Products', 'custom', 1946, 'custom', '#', '', '', '' );

kt_add_menu_item( 1947, $menu_id, 0, 'Manufacturers', 'custom', 1947, 'custom', '#', '', '', '' );

kt_add_menu_item( 1948, $menu_id, 0, 'Our Stores', 'custom', 1948, 'custom', '#', '', '', '' );

kt_add_menu_item( 1949, $menu_id, 0, 'Shipping', 'custom', 1949, 'custom', '#', '', '', '' );

kt_add_menu_item( 1950, $menu_id, 0, 'Payments', 'custom', 1950, 'custom', '#', '', '', '' );

kt_add_menu_item( 1951, $menu_id, 0, 'Payments', 'custom', 1951, 'custom', '#', '', '', '' );

kt_add_menu_item( 1952, $menu_id, 0, 'Refunds', 'custom', 1952, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 174, 'My account', '' );

 // Menu Item
kt_add_menu_item( 1930, $menu_id, 0, 'My Order', 'custom', 1930, 'custom', '#', '', '', '' );

kt_add_menu_item( 1931, $menu_id, 0, 'My Wishlist', 'custom', 1931, 'custom', '#', '', '', '' );

kt_add_menu_item( 1932, $menu_id, 0, 'My Credit Slip', 'custom', 1932, 'custom', '#', '', '', '' );

kt_add_menu_item( 1933, $menu_id, 0, 'My Addresses', 'custom', 1933, 'custom', '#', '', '', '' );

kt_add_menu_item( 1934, $menu_id, 0, 'My Personal In', 'custom', 1934, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 177, 'OnlineShop', '' );

 // Menu Item
kt_add_menu_item( 1936, $menu_id, 0, 'Online Shopping', 'custom', 1936, 'custom', '#', '', '', '' );

kt_add_menu_item( 1937, $menu_id, 0, 'Promotions', 'custom', 1937, 'custom', '#', '', '', '' );

kt_add_menu_item( 1938, $menu_id, 0, 'My Orders', 'custom', 1938, 'custom', '#', '', '', '' );

kt_add_menu_item( 1939, $menu_id, 0, 'Help', 'custom', 1939, 'custom', '#', '', '', '' );

kt_add_menu_item( 1940, $menu_id, 0, 'Site Map', 'custom', 1940, 'custom', '#', '', '', '' );

kt_add_menu_item( 1941, $menu_id, 0, 'Customer Service', 'custom', 1941, 'custom', '#', '', '', '' );

kt_add_menu_item( 1942, $menu_id, 0, 'Support', 'custom', 1942, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 179, 'Sandwich', '' );

 // Menu Item
kt_add_menu_item( 1906, $menu_id, 0, 'Salad', 'custom', 1906, 'custom', '#', '', '', '' );

kt_add_menu_item( 1907, $menu_id, 0, 'Paste', 'custom', 1907, 'custom', '#', '', '', '' );

kt_add_menu_item( 1908, $menu_id, 0, 'Tops', 'custom', 1908, 'custom', '#', '', '', '' );

kt_add_menu_item( 1909, $menu_id, 0, 'Tops', 'custom', 1909, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 180, 'SAUSAGES', '' );

 // Menu Item
kt_add_menu_item( 1886, $menu_id, 0, 'Meat Dishes', 'custom', 1886, 'custom', '#', '', '', '' );

kt_add_menu_item( 1887, $menu_id, 0, 'Desserts', 'custom', 1887, 'custom', '#', '', '', '' );

kt_add_menu_item( 1901, $menu_id, 0, 'Tops', 'custom', 1901, 'custom', '#', '', '', '' );

kt_add_menu_item( 1902, $menu_id, 0, 'Tops', 'custom', 1902, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 182, 'Sports', '' );

 // Menu Item
kt_add_menu_item( 1977, $menu_id, 0, 'Tennis', 'custom', 1977, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/sport-outdoor/sports/', '', '0', '' );

kt_add_menu_item( 1978, $menu_id, 0, 'Coats & Jackets', 'custom', 1978, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/sport-outdoor/sports/', '', '0', '' );

kt_add_menu_item( 1979, $menu_id, 0, 'Blouses & Shirts', 'custom', 1979, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/sport-outdoor/sports/', '', '0', '' );

kt_add_menu_item( 1980, $menu_id, 0, 'Tops & Tees', 'custom', 1980, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/sport-outdoor/sports/', '', '0', '' );

kt_add_menu_item( 1981, $menu_id, 0, 'Hoodies & Sweatshirts', 'custom', 1981, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/sport-outdoor/sports/', '', '0', '' );

kt_add_menu_item( 1982, $menu_id, 0, 'Intimates', 'custom', 1982, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/sport-outdoor/sports/', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 183, 'Support', '' );

 // Menu Item
kt_add_menu_item( 1920, $menu_id, 0, 'About us', 'custom', 1920, 'custom', '#', '', '', '' );

kt_add_menu_item( 1921, $menu_id, 0, 'Testimonials', 'custom', 1921, 'custom', '#', '', '', '' );

kt_add_menu_item( 1922, $menu_id, 0, 'Affiliate Program', 'custom', 1922, 'custom', '#', '', '', '' );

kt_add_menu_item( 1923, $menu_id, 0, 'Terms & Conditions', 'custom', 1923, 'custom', '#', '', '', '' );

kt_add_menu_item( 1924, $menu_id, 0, 'Contact Us', 'custom', 1924, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 184, 'Terms &amp; Conditions', '' );

 // Menu Item
kt_add_menu_item( 1953, $menu_id, 0, 'Terms & Conditions', 'custom', 1953, 'custom', '#', '', '', '' );

kt_add_menu_item( 1954, $menu_id, 0, 'Policy', 'custom', 1954, 'custom', '#', '', '', '' );

kt_add_menu_item( 1955, $menu_id, 0, 'Policy', 'custom', 1955, 'custom', '#', '', '', '' );

kt_add_menu_item( 1956, $menu_id, 0, 'Shipping', 'custom', 1956, 'custom', '#', '', '', '' );

kt_add_menu_item( 1957, $menu_id, 0, 'Payments', 'custom', 1957, 'custom', '#', '', '', '' );

kt_add_menu_item( 1958, $menu_id, 0, 'Returns', 'custom', 1958, 'custom', '#', '', '', '' );

kt_add_menu_item( 1959, $menu_id, 0, 'Refunds', 'custom', 1959, 'custom', '#', '', '', '' );

kt_add_menu_item( 1960, $menu_id, 0, 'Warrantee', 'custom', 1960, 'custom', '#', '', '', '' );

kt_add_menu_item( 1961, $menu_id, 0, 'FAQ', 'custom', 1961, 'custom', '#', '', '', '' );

kt_add_menu_item( 1962, $menu_id, 0, 'Contact', 'custom', 1962, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 206, 'Topbar menu left', 'topbar_menuleft' );

 // Menu Item
kt_add_menu_item( 2466, $menu_id, 0, '<i class=\"fa fa-phone\"></i> +00 123 456 789', 'custom', 2466, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2467, $menu_id, 0, '<i class=\"fa fa-envelope\"></i> Contact us today !', 'custom', 2467, 'custom', '#', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 207, 'Topbar menu right', 'topbar_menuright' );

 // Menu Item
kt_add_menu_item( 2468, $menu_id, 0, 'Support', 'page', 371, 'post_type', 'http://kutethemes.net/wordpress/kuteshop/option3/support/', '', '0', '' );

kt_add_menu_item( 2469, $menu_id, 0, 'Services', 'page', 369, 'post_type', 'http://kutethemes.net/wordpress/kuteshop/option3/services/', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 185, 'Trending', '' );

 // Menu Item
kt_add_menu_item( 1871, $menu_id, 0, 'Men\'s Clothing', 'custom', 1871, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/fashion/', '', '0', '' );

kt_add_menu_item( 1872, $menu_id, 0, 'Kid\'s Clothing', 'custom', 1872, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/fashion/', '', '0', '' );

kt_add_menu_item( 1873, $menu_id, 0, 'Women\'s Clothing', 'custom', 1873, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/fashion/', '', '0', '' );

kt_add_menu_item( 1874, $menu_id, 0, 'Accessories', 'custom', 1874, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option3/product-category/fashion/', '', '0', '' );
