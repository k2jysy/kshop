<?php
//Menu
$menu_id = kt_add_menu( 183, 'Support', '' );

 // Menu Item
kt_add_menu_item( 1920, $menu_id, 0, 'About us', 'custom', 1920, 'custom', '#', '', '', '' );

kt_add_menu_item( 1921, $menu_id, 0, 'Testimonials', 'custom', 1921, 'custom', '#', '', '', '' );

kt_add_menu_item( 1922, $menu_id, 0, 'Affiliate Program', 'custom', 1922, 'custom', '#', '', '', '' );

kt_add_menu_item( 1923, $menu_id, 0, 'Terms & Conditions', 'custom', 1923, 'custom', '#', '', '', '' );

kt_add_menu_item( 1924, $menu_id, 0, 'Contact Us', 'custom', 1924, 'custom', '#', '', '', '' );
