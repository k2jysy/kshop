<?php
kt_download_media(2653, 'mobile.png', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/revslider/kute-opt7/mobile.png');

kt_download_media(2654, 'now.png', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/revslider/kute-opt7/now.png');

kt_download_media(2655, 'spring.png', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/revslider/kute-opt7/spring.png');

kt_download_media(2656, 'category-slide', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/10/category-slide.jpg');

kt_download_media(2664, 'banner-topmenu', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/10/banner-topmenu.jpg');

kt_download_media(2666, 'banner-megamenu', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/10/banner-megamenu.jpg');
