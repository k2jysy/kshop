<?php
kt_download_media(2263, 'p62', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/p62.jpg');

kt_download_media(2264, 'p65', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/p65.jpg');

kt_download_media(2265, 'p66', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/p66.jpg');

kt_download_media(2267, 'p70', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/p70.jpg');

kt_download_media(2268, 'p10', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/p10.jpg');
