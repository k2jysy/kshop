<?php
kt_download_media(2601, 's1', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/s1.png');

kt_download_media(2602, 's2', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/s2.png');

kt_download_media(2603, 's3', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/s3.png');

kt_download_media(2604, 's4', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/s4.png');

kt_download_media(2611, 'blog1', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/blog1.jpg');

kt_download_media(2612, 'blog6', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/blog6.jpg');
