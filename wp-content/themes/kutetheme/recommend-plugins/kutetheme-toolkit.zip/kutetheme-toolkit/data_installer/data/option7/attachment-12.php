<?php
kt_download_media(2380, 'b3', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/b3.jpg');

kt_download_media(2382, 'b4', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/b4.jpg');

kt_download_media(2385, 'b5', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/b5.jpg');

kt_download_media(2386, 'b6', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/b6.jpg');

kt_download_media(2387, 'b7', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/b7.jpg');

kt_download_media(2388, 'i6', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/i6.png');
