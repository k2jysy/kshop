<?php
kt_download_media(1838, 'banner-botom1', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/banner-botom11.jpg');

kt_download_media(1863, 'trademark-dhl', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/10/trademark-dhl.jpg');

kt_download_media(1864, 'trademark-ems', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/10/trademark-ems.jpg');

kt_download_media(1865, 'trademark-fe', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/10/trademark-fe.jpg');

kt_download_media(1866, 'trademark-mc', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/10/trademark-mc.jpg');

kt_download_media(1867, 'trademark-qiwi', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/10/trademark-qiwi.jpg');
