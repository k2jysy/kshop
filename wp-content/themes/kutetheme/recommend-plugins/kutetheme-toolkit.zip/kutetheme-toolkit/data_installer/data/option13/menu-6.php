<?php
//Menu
$menu_id = kt_add_menu( 223, 'CUSTOM SERVICES', '' );

 // Menu Item
kt_add_menu_item( 2186, $menu_id, 0, 'About us', 'custom', 2186, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2187, $menu_id, 0, 'Testimonials', 'custom', 2187, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2188, $menu_id, 0, 'Affiliate Program', 'custom', 2188, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2189, $menu_id, 0, 'Terms & Conditions', 'custom', 2189, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2190, $menu_id, 0, 'Contact Us', 'custom', 2190, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2192, $menu_id, 0, 'Customer Service', 'custom', 2192, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2193, $menu_id, 0, 'Consultant', 'custom', 2193, 'custom', '#', '', '0', '' );

