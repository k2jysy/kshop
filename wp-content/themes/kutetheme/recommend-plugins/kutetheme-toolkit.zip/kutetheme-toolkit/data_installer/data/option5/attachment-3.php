<?php
kt_download_media(1284, 'Z3', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/Z31.jpg');

kt_download_media(1285, 'Z4', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/Z4.jpg');

kt_download_media(1286, 'S1', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/S12.jpg');

kt_download_media(1287, 'K2', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/K21.jpg');

kt_download_media(1297, 'K1', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/K11.jpg');
