<?php
kt_download_media(2060, 'ads12', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/ads12.jpg');

kt_download_media(2061, 'ads13', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/ads13.jpg');

kt_download_media(2062, 'ads14', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/ads14.jpg');

kt_download_media(2063, 'ads15', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/ads15.jpg');

kt_download_media(2064, 'f1', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/f1.jpg');
