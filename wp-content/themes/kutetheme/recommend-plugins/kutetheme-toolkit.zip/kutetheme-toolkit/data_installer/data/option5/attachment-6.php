<?php
kt_download_media(1471, 'fashion', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/fashion.jpg');

kt_download_media(1473, 'sport', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/sport.jpg');

kt_download_media(1474, 'electronic', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/electronic.jpg');

kt_download_media(1475, 'cat-br1', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/cat-br1.png');

kt_download_media(1476, 'cat-br2', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/cat-br2.png');
