<?php
kt_download_media(2021, 'testimonials1', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/testimonials1.jpg');

kt_download_media(2022, 'testimonials2', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/testimonials2.jpg');

kt_download_media(2023, 'testimonials3', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/testimonials3.jpg');

kt_download_media(2025, 'testimonials', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/testimonials.jpg');
