<?php
kt_download_media(118, '34 - Copy', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/34-Copy.jpg');

kt_download_media(119, '34', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/34.jpg');

kt_download_media(120, '36', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/36.jpg');

kt_download_media(123, '8 - Copy', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/8-Copy1.jpg');

kt_download_media(124, '43', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/43.jpg');

kt_download_media(125, '51', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/51.jpg');
