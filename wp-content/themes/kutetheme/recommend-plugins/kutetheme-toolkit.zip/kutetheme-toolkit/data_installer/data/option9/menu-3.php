<?php
//Menu
$menu_id = kt_add_menu( 55, 'footer kuteshop', '' );

 // Menu Item
kt_add_menu_item( 930, $menu_id, 0, 'About us', 'custom', 930, 'custom', '#', '', '', '' );

kt_add_menu_item( 931, $menu_id, 0, 'Customer Service', 'custom', 931, 'custom', '#', '', '', '' );

kt_add_menu_item( 932, $menu_id, 0, 'New Collection', 'custom', 932, 'custom', '#', '', '', '' );

kt_add_menu_item( 933, $menu_id, 0, 'Manufacturers', 'custom', 933, 'custom', '#', '', '', '' );

kt_add_menu_item( 934, $menu_id, 0, 'Privacy policy', 'custom', 934, 'custom', '#', '', '', '' );

kt_add_menu_item( 935, $menu_id, 0, 'Terms & condition', 'custom', 935, 'custom', '#', '', '', '' );

kt_add_menu_item( 936, $menu_id, 0, 'Blog', 'custom', 936, 'custom', '#', '', '', '' );
