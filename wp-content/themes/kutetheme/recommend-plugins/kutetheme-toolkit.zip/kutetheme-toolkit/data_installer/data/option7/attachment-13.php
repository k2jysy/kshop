<?php
kt_download_media(2389, 'b8', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/b8.jpg');

kt_download_media(2390, 'i5', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/i5.png');

kt_download_media(2391, 'i4', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/i4.png');

kt_download_media(2392, 'i3', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/i3.png');

kt_download_media(2393, 'i2', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/i2.png');

kt_download_media(2394, 'i1', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/i1.png');
