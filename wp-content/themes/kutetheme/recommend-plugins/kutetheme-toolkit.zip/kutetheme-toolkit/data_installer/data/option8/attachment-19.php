<?php
kt_download_media(2135, 'men', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/11/men.png');

kt_download_media(2136, 'trending', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/11/trending.png');

kt_download_media(2137, 'women', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/11/women.png');

kt_download_media(2138, 'kid', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/11/kid.png');
