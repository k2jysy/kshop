<?php
kt_download_media(2176, 'size-chart', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/size-chart.jpg');

kt_download_media(2238, '2', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/2.jpg');

kt_download_media(2239, '2', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/21.jpg');
