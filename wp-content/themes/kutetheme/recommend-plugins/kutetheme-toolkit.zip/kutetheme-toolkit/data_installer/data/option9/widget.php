<?php
// Widgets
kt_add_widget( 'search', 'sidebar-primary', '2', 'YToxOntzOjU6InRpdGxlIjtzOjA6IiI7fQ==', '2' );

kt_add_widget( 'recent-posts', 'sidebar-primary', '2', 'YToyOntzOjU6InRpdGxlIjtzOjA6IiI7czo2OiJudW1iZXIiO2k6NTt9', '2' );

kt_add_widget( 'recent-comments', 'sidebar-primary', '2', 'YToyOntzOjU6InRpdGxlIjtzOjA6IiI7czo2OiJudW1iZXIiO2k6NTt9', '2' );

kt_add_widget( 'archives', 'sidebar-primary', '2', 'YTozOntzOjU6InRpdGxlIjtzOjA6IiI7czo1OiJjb3VudCI7aTowO3M6ODoiZHJvcGRvd24iO2k6MDt9', '2' );

kt_add_widget( 'categories', 'sidebar-primary', '2', 'YTo0OntzOjU6InRpdGxlIjtzOjA6IiI7czo1OiJjb3VudCI7aTowO3M6MTI6ImhpZXJhcmNoaWNhbCI7aTowO3M6ODoiZHJvcGRvd24iO2k6MDt9', '2' );

kt_add_widget( 'meta', 'sidebar-primary', '2', 'YToxOntzOjU6InRpdGxlIjtzOjA6IiI7fQ==', '2' );

kt_add_widget( 'woocommerce_product_categories', 'sidebar-shop', '1', 'YTo2OntzOjU6InRpdGxlIjtzOjEzOiJQUk9EVUNUIFRZUEVTIjtzOjc6Im9yZGVyYnkiO3M6NToib3JkZXIiO3M6ODoiZHJvcGRvd24iO2k6MDtzOjU6ImNvdW50IjtzOjE6IjEiO3M6MTI6ImhpZXJhcmNoaWNhbCI7aTowO3M6MTg6InNob3dfY2hpbGRyZW5fb25seSI7aTowO30=', '1' );

kt_add_widget( 'woocommerce_price_filter', 'sidebar-shop', '1', 'YToxOntzOjU6InRpdGxlIjtzOjE1OiJGaWx0ZXIgYnkgcHJpY2UiO30=', '1' );

kt_add_widget( 'woocommerce_layered_nav', 'sidebar-shop', '1', 'YTo0OntzOjU6InRpdGxlIjtzOjE1OiJGaWx0ZXIgYnkgQ29sb3IiO3M6MTI6ImRpc3BsYXlfdHlwZSI7czo0OiJsaXN0IjtzOjEwOiJxdWVyeV90eXBlIjtzOjM6ImFuZCI7czo5OiJhdHRyaWJ1dGUiO3M6NToiY29sb3IiO30=', '1' );

kt_add_widget( 'woocommerce_product_tag_cloud', 'sidebar-shop', '1', 'YToxOntzOjU6InRpdGxlIjtzOjEyOiJQcm9kdWN0IFRhZ3MiO30=', '1' );

kt_add_widget( 'widget_kt_product_special', 'sidebar-shop', '1', 'YTo0OntzOjU6InRpdGxlIjtzOjE2OiJTUEVDSUFMIFBST0RVQ1RTIjtzOjc6Im9yZGVyYnkiO3M6NDoiZGF0ZSI7czo1OiJvcmRlciI7czo0OiJkZXNjIjtzOjE0OiJwb3N0c19wZXJfcGFnZSI7aTozO30=', '1' );

kt_add_widget( 'widget_kt_testimonial', 'sidebar-shop', '1', 'YTo3OntzOjU6InRpdGxlIjtzOjEyOiJURVNUSU1PTklBTFMiO3M6ODoiYXV0b3BsYXkiO3M6Mjoib24iO3M6NDoibG9vcCI7czoyOiJvbiI7czoxMDoic2xpZGVzcGVlZCI7aToyNTA7czo2OiJudW1iZXIiO2k6MztzOjc6Im9yZGVyYnkiO3M6NDoiZGF0ZSI7czo1OiJvcmRlciI7czo0OiJkZXNjIjt9', '1' );

kt_add_widget( 'nav_menu', 'footer-menu-1', '1', 'YToyOntzOjU6InRpdGxlIjtzOjg6IktVVEVTSE9QIjtzOjg6Im5hdl9tZW51IjtpOjU1O30=', '1' );

kt_add_widget( 'nav_menu', 'footer-menu-2', '2', 'YToyOntzOjU6InRpdGxlIjtzOjg6IlBST0RVQ1RTIjtzOjg6Im5hdl9tZW51IjtpOjU2O30=', '2' );

kt_add_widget( 'nav_menu', 'footer-menu-3', '3', 'YToyOntzOjU6InRpdGxlIjtzOjE2OiJDVVNUT01FUiBTRVJWSUNFIjtzOjg6Im5hdl9tZW51IjtpOjU0O30=', '3' );

kt_add_widget( 'widget_kt_social', 'footer-menu-4', '1', 'YToxOntzOjY6Ind0aXRsZSI7czoyMDoiTEVUJiMwMzk7UyBTT0NJQUxJWkUiO30=', '1' );

kt_add_widget( 'widget_kt_mailchimp', 'footer-menu-4', '1', 'YToxMTp7czo1OiJ0aXRsZSI7czoyMjoiU0lHTiBVUCBGT1IgTkVXU0xFVFRFUiI7czo0OiJsaXN0IjtzOjA6IiI7czo2OiJvcHRfaW4iO3M6MzoieWVzIjtzOjExOiJ0ZXh0X2JlZm9yZSI7czowOiIiO3M6MTA6InRleHRfYWZ0ZXIiO3M6MDoiIjtzOjc6ImNvbnRlbnQiO3M6ODc6IlN1Y2Nlc3MhICBDaGVjayB5b3VyIGluYm94IG9yIHNwYW0gZm9sZGVyIGZvciBhIG1lc3NhZ2UgY29udGFpbmluZyBhIGNvbmZpcm1hdGlvbiBsaW5rLiI7czo2OiJsYXlvdXQiO3M6Mzoib25lIjtzOjE0OiJoZWlnaHRfZGVza3RvcCI7aTowO3M6MTM6ImhlaWdodF90YWJsZXQiO2k6MDtzOjEzOiJoZWlnaHRfbW9iaWxlIjtpOjA7czozOiJjc3MiO3M6MDoiIjt9', '1' );