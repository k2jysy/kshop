<?php
kt_download_media(242, 'fashion.png', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/revslider/kute-opt11/fashion.png');

kt_download_media(243, 'looksport.png', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/revslider/kute-opt11/looksport.png');

kt_download_media(244, '2015.png', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/revslider/kute-opt11/2015.png');

kt_download_media(245, 'bg24.png', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/revslider/kute-opt11/bg24.png');

kt_download_media(836, 'band1', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/band1.png');

kt_download_media(837, 'band2', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/band2.png');
