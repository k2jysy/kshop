<?php
kt_download_media(2252, 'btn.png', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/revslider/kute-opt5/btn.png');

kt_download_media(2253, 'bg22.png', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/revslider/kute-opt5/bg22.png');

kt_download_media(2254, 'bg111.png', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/revslider/kute-opt5/bg111.png');

kt_download_media(2255, 'p44', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/10/p44.jpg');

kt_download_media(2256, 'ld4', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/10/ld4.jpg');
