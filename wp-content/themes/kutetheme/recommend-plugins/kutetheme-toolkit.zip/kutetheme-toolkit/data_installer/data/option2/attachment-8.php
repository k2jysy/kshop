<?php
kt_download_media(2065, '11.png', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/revslider/slider2/11.png');

kt_download_media(2066, '2.21.png', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/revslider/slider2/2.21.png');

kt_download_media(2067, '32.png', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/revslider/slider2/32.png');

kt_download_media(2068, 'line3.png', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/revslider/slider2/line3.png');

kt_download_media(2069, 'ld6', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/10/ld6.jpg');

kt_download_media(2070, 'ld8', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/10/ld8.jpg');
