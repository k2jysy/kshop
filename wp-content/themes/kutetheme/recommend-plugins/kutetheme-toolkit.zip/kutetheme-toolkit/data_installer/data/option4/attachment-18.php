<?php
kt_download_media(2419, 'smartphone', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/10/smartphone.png');

kt_download_media(2420, 'healthy', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/10/healthy.png');

kt_download_media(2421, 'shoes&acc', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/10/shoesacc.png');

kt_download_media(2422, 'toys', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/10/toys.png');

kt_download_media(2423, 'Com&net', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/10/Comnet.png');

kt_download_media(2424, 'Jewelry', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/10/Jewelry.png');

kt_download_media(2425, 'Flashlights', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/10/Flashlights.png');

kt_download_media(2426, 'television', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/10/television.png');
