<?php
kt_download_media(2079, 'p82', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/10/p82.jpg');

kt_download_media(2080, 'p85', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/10/p85.jpg');

kt_download_media(2081, 'p8', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/10/p8.jpg');

kt_download_media(2082, 'ld1', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/10/ld1.jpg');

kt_download_media(2083, 'ld2', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/10/ld2.jpg');

kt_download_media(2084, 'ld3', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/10/ld3.jpg');
