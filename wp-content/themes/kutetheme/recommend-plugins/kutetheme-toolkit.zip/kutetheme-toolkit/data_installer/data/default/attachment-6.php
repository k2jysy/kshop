<?php
kt_download_media(2013, '30', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/30.jpg');

kt_download_media(2014, '31', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/31.jpg');

kt_download_media(2015, '32', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/32.png');

kt_download_media(2016, 'i 9', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/i-9.jpg');

kt_download_media(2018, '10', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/10.jpg');

kt_download_media(2019, '11', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/11.jpg');
