<?php
kt_download_media(220, 's1', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/s11.png');

kt_download_media(221, 's2', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/s21.png');

kt_download_media(222, 's3', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/s31.png');

kt_download_media(836, 'band1', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/band1.png');

kt_download_media(837, 'band2', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/band2.png');
