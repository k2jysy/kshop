<?php
kt_download_media(1249, 'F1', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/F12.jpg');

kt_download_media(1261, 'L1', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/L12.jpg');

kt_download_media(1262, 'U2', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/U22.jpg');

kt_download_media(1263, 'U4', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/U4.jpg');

kt_download_media(1274, 'U1', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/U1.jpg');

kt_download_media(1283, 'Z1', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/Z11.jpg');
