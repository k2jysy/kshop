<?php
kt_download_media(1327, 'R5', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/R5.jpg');

kt_download_media(1468, 'logo-footer', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/09/logo-footer.png');

kt_download_media(1471, 'fashion', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/fashion.jpg');

kt_download_media(1473, 'sport', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/sport.jpg');

kt_download_media(1474, 'electronic', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/electronic.jpg');

kt_download_media(1475, 'cat-br1', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/cat-br1.png');
