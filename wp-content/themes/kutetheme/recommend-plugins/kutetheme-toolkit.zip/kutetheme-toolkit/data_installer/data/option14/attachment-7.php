<?php
kt_download_media(2042, 'testimonial1', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/08/testimonial1.png');

kt_download_media(2043, 'testimonial2', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/08/testimonial2.png');

kt_download_media(2044, 'testimonial3', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/08/testimonial3.png');
