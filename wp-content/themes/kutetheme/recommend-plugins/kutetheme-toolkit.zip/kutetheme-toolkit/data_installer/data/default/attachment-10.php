<?php
kt_download_media(2039, '69', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/69.jpg');

kt_download_media(2040, 'Com&net', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/12/Comnet.png');

kt_download_media(2041, 'electronic', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/12/electronic.png');

kt_download_media(2042, 'Flashlights', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/12/Flashlights.png');

kt_download_media(2043, 'healthy', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/12/healthy.png');
