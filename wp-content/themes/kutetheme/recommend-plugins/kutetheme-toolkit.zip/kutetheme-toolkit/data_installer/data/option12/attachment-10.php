<?php
kt_download_media(2110, '2', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/11/2.png');

kt_download_media(2111, '3', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/11/3.png');

kt_download_media(2112, 'band1', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/11/band1.png');

kt_download_media(2113, 'band2', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/11/band2.png');

kt_download_media(2114, 'band3', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/11/band3.png');
