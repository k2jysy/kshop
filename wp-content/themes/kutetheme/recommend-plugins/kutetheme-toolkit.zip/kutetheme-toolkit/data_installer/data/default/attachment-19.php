<?php

kt_download_media(2087, 'trending', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/12/trending.png');

kt_download_media(2090, 'banner-megamenu', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/12/banner-megamenu.jpg');

kt_download_media(2102, 'blog1', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/blog1.jpg');

kt_download_media(2104, 'blog6', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/blog6.jpg');

kt_download_media(2106, 'blog8', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/blog8.jpg');
