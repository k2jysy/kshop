<?php
kt_download_media(2055, '18', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/181.jpg');

kt_download_media(2056, '35', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/35.jpg');

kt_download_media(2060, 'b3', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/b3.jpg');

kt_download_media(2062, 'b1', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/b1.jpg');

kt_download_media(2063, 'b2', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/b2.jpg');

kt_download_media(2064, 'b4', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/b4.jpg');

kt_download_media(2065, 'b5', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/b5.jpg');
