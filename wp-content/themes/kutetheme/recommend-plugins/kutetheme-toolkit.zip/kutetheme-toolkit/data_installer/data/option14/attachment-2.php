<?php
kt_download_media(2021, '68', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/08/68.jpg');

kt_download_media(2022, '69', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/08/69.jpg');

kt_download_media(2023, '70', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/08/70.jpg');

