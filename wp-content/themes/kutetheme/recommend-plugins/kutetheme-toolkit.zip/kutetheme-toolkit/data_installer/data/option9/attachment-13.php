<?php
kt_download_media(848, 'banner6', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/banner6.jpg');

kt_download_media(849, 'banner7', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/banner7.jpg');

kt_download_media(850, 'banner8', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/banner8.jpg');

kt_download_media(851, 'banner9', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/banner9.jpg');

kt_download_media(852, 'banner10', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/banner10.jpg');
