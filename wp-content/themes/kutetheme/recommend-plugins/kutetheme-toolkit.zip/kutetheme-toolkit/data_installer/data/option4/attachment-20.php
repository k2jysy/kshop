<?php
kt_download_media(2469, 'banner', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/banner.jpg');

kt_download_media(2470, 'banner2', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/banner22.jpg');

kt_download_media(2497, '40', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/10/40.jpg');

kt_download_media(2498, 'i 20', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/10/i-20.jpg');

kt_download_media(2499, 'i 28', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/10/i-28.jpg');

kt_download_media(2500, 'i 29', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/10/i-29.jpg');

kt_download_media(2523, 'category-slide', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/10/category-slide.jpg');

kt_download_media(2524, 'slide-cart2', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/10/slide-cart2.jpg');

