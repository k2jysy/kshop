<?php
kt_download_media(2040, '31', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/31.jpg');

kt_download_media(2047, 'testimonial1', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/testimonial1.png');

kt_download_media(2048, 'testimonial2', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/testimonial2.png');

kt_download_media(2049, 'testimonial3', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/testimonial3.png');
