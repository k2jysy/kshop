<?php
kt_download_media(2055, 'l4', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/11/l4.jpg');

kt_download_media(2056, 'l5', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/11/l5.jpg');

kt_download_media(2057, 'l6', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/11/l6.jpg');

kt_download_media(2059, '416sirti-cut-out-elbiseli155', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/416sirti-cut-out-elbiseli155.jpg');
