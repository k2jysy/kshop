<?php
// Attachment
kt_download_media(26, '12', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/12.png');

kt_download_media(27, '13', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/13.png');

kt_download_media(28, '14', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/14.png');

kt_download_media(29, '15', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/15.png');

kt_download_media(30, '16', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/16.png');

kt_download_media(31, '17', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/17.png');

kt_download_media(32, '18', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/18.png');

kt_download_media(33, '19', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/19.png');

kt_download_media(34, '20', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/20.png');

kt_download_media(35, '21', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/21.png');

kt_download_media(36, '22', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/22.png');

kt_download_media(37, 'cart-icon4', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/cart-icon4.jpg');

kt_download_media(38, '1', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/1.png');

kt_download_media(39, '2', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/2.png');

kt_download_media(40, '3', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/3.png');

kt_download_media(41, '4', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/4.png');

kt_download_media(42, '5', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/5.png');

kt_download_media(43, '6', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/6.png');

kt_download_media(44, '7', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/7.png');

kt_download_media(45, '8', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/8.png');

kt_download_media(46, '9', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/9.png');

kt_download_media(47, '10', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/10.png');

kt_download_media(48, '11', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/11.png');

kt_download_media(49, '12', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/121.png');

kt_download_media(50, '13', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/131.png');

kt_download_media(51, '14', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/141.png');

kt_download_media(52, '15', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/151.png');

kt_download_media(53, '16', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/161.png');

kt_download_media(54, '17', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/171.png');

kt_download_media(55, '18', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/181.png');

kt_download_media(56, '19', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/191.png');

kt_download_media(57, '20', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/201.png');
