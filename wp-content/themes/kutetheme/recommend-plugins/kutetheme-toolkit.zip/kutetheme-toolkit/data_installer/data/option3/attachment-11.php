<?php
kt_download_media(2075, '62', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/62.jpg');

kt_download_media(2076, '66', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/66.jpg');

kt_download_media(2077, '67', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/67.jpg');

kt_download_media(2079, '28', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/28.png');

kt_download_media(2080, '29', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/29.png');

kt_download_media(2081, '30', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/30.jpg');

kt_download_media(2082, '31', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/31.jpg');

kt_download_media(2083, '32', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/32.png');
