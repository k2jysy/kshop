<?php
kt_download_media(2149, 'brand6', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/12/brand6.jpg');

kt_download_media(2150, 'brand7', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/12/brand7.jpg');

kt_download_media(2162, 'bg-block-newsletter', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/08/bg-block-newsletter.jpg');
