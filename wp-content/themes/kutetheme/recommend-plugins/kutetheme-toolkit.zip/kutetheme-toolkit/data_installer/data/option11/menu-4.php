<?php
//Menu
$menu_id = kt_add_menu( 46, 'Fashion', '' );

 // Menu Item
kt_add_menu_item( 175, $menu_id, 0, 'Jackets', 'custom', 175, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option11/product-category/fashion/', '', '', '' );

kt_add_menu_item( 176, $menu_id, 0, 'Skirt', 'custom', 176, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option11/product-category/fashion/', '', '', '' );

kt_add_menu_item( 177, $menu_id, 0, 'Casual', 'custom', 177, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option11/product-category/fashion/', '', '', '' );

kt_add_menu_item( 178, $menu_id, 0, 'Tops', 'custom', 178, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option11/product-category/fashion/', '', '', '' );

kt_add_menu_item( 179, $menu_id, 0, 'Scarves', 'custom', 179, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option11/product-category/fashion/', '', '', '' );

kt_add_menu_item( 180, $menu_id, 0, 'T- Shirts', 'custom', 180, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option11/product-category/fashion/', '', '', '' );
