<?php
// Custom term
kt_add_category( 20, 'actual', 'actual', 'product_tag', '0', 'Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Vivamus magna justo, lacinia eget consectetur sed' );

kt_add_category( 21, 'beauty', 'beauty', 'product_tag', '0', 'Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Vivamus magna justo, lacinia eget consectetur sed Proin eget tortor risus. Cras ultricies ligula sed magna dictum porta. Nulla porttitor accumsan tincidunt.' );

kt_add_category( 43, 'Black', 'black', 'pa_color', '0', '' );

kt_add_category( 40, 'Blue', 'blue', 'pa_color', '0', '' );

kt_add_brand( 55, 'Brand 2', 'brand-2', 'product_brand', '0', '', '842' );

kt_add_brand( 56, 'Brand 3', 'brand-3', 'product_brand', '0', '', '841' );

kt_add_brand( 57, 'Brand 4', 'brand-4', 'product_brand', '0', '', '840' );

kt_add_brand( 58, 'Brand 5', 'brand-5', 'product_brand', '0', '', '839' );

kt_add_brand( 59, 'Brand 6', 'brand-6', 'product_brand', '0', '', '838' );

kt_add_brand( 60, 'Brand 7', 'brand-7', 'product_brand', '0', '', '837' );

kt_add_category( 22, 'charming', 'charming', 'product_tag', '0', 'Nulla quis lorem ut libero malesuada feugiat. Donec sollicitudin molestie malesuada. Mauris blandit aliquet elit,' );

kt_add_category( 23, 'colorful', 'colorful', 'product_tag', '0', 'Nulla quis lorem ut libero malesuada feugiat. Donec sollicitudin molestie malesuada. Mauris blandit aliquet elit,' );

kt_add_category( 44, 'comfor', 'comfor', 'product_tag', '0', '' );

kt_add_category( 24, 'comfort', 'comfort', 'product_tag', '0', 'Nulla quis lorem ut libero malesuada feugiat. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus.' );

kt_add_category( 5, 'external', 'external', 'product_type', '0', '' );

kt_add_brand( 54, 'Git', 'git', 'product_brand', '0', '', '836' );

kt_add_category( 41, 'Grey', 'grey', 'pa_color', '0', '' );

kt_add_category( 3, 'grouped', 'grouped', 'product_type', '0', '' );

kt_add_category( 25, 'long', 'long', 'product_tag', '0', 'Nulla quis lorem ut libero malesuada feugiat. Donec sollicitudin molestie malesuada. Mauris blandit aliquet elit,' );

kt_add_category( 26, 'modern', 'modern', 'product_tag', '0', 'Quisque velit nisi, pretium ut lacinia in, elementum id enim. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus' );

kt_add_category( 45, 'morden', 'morden', 'product_tag', '0', '' );

kt_add_category( 27, 'moving', 'moving', 'product_tag', '0', 'Nulla quis lorem ut libero malesuada feugiat. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus.' );

kt_add_category( 28, 'new', 'new', 'product_tag', '0', 'Nulla quis lorem ut libero malesuada feugiat. Donec sollicitudin molestie malesuada. Mauris blandit aliquet elit,' );

kt_add_category( 42, 'Pink', 'pink', 'pa_color', '0', '' );

kt_add_category( 29, 'playing', 'playing', 'product_tag', '0', 'Nulla quis lorem ut libero malesuada feugiat. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus.' );

kt_add_category( 39, 'Red', 'red', 'pa_color', '0', '' );

kt_add_category( 30, 'ruby', 'ruby', 'product_tag', '0', 'Nulla quis lorem ut libero malesuada feugiat. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus.' );

kt_add_category( 31, 'sexy', 'sexy', 'product_tag', '0', 'Nulla quis lorem ut libero malesuada feugiat. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus.' );

kt_add_category( 32, 'short', 'short', 'product_tag', '0', 'Nulla quis lorem ut libero malesuada feugiat. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus.' );

kt_add_category( 2, 'simple', 'simple', 'product_type', '0', '' );

kt_add_category( 33, 'style', 'style', 'product_tag', '0', 'Nulla quis lorem ut libero malesuada feugiat. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus.' );

kt_add_category( 4, 'variable', 'variable', 'product_type', '0', '' );

kt_add_product_cat( 9, 'Digital', 'digital', 'product_cat', '0', '', '0' );

kt_add_product_cat( 6, 'Fashion', 'fashion', 'product_cat', '0', '', '0' );

kt_add_product_cat( 7, 'Foods', 'foods', 'product_cat', '0', '', '0' );

kt_add_product_cat( 10, 'Furniture', 'furniture', 'product_cat', '0', '', '0' );

kt_add_product_cat( 11, 'Jewelry', 'jewelry', 'product_cat', '0', '', '0' );

kt_add_product_cat( 14, 'Laptop', 'laptop', 'product_cat', '9', '', '0' );

kt_add_product_cat( 12, 'Mobile', 'mobile', 'product_cat', '9', '', '0' );

kt_add_product_cat( 13, 'Notebook', 'notebook', 'product_cat', '9', '', '0' );

kt_add_product_cat( 51, 'Sport shirt', 'sport-shirt', 'product_cat', '0', '
Nullam aliquet vestibulum augue non varius. Cras nec congue elitos. Duis tristique del ante nec aliquam. Praesent urna tellus laoreet.
                    ', '855' );

kt_add_product_cat( 53, 'Sport shoes', 'sport-shoes', 'product_cat', '0', 'Nullam aliquet vestibulum augue non varius. Cras nec congue elitos. Duis tristique del ante nec aliquam. Praesent urna tellus laoreet.
                    ', '857' );

kt_add_product_cat( 52, 'Sport Trouser', 'sport-trouser', 'product_cat', '0', 'Nullam aliquet vestibulum augue non varius. Cras nec congue elitos. Duis tristique del ante nec aliquam. Praesent urna tellus laoreet.
                    ', '856' );

kt_add_product_cat( 8, 'Sports', 'sports', 'product_cat', '0', '', '0' );

kt_add_product_cat( 15, 'Television', 'television', 'product_cat', '9', '', '0' );

kt_add_product_cat( 16, 'Accessories', 'accessories', 'product_cat', '9', '', '0' );
