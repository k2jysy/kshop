<?php
 // Widgets
kt_add_widget( 'search', 'sidebar-primary', '2', 'YToxOntzOjU6InRpdGxlIjtzOjA6IiI7fQ==', '2' );

kt_add_widget( 'recent-posts', 'sidebar-primary', '2', 'YToyOntzOjU6InRpdGxlIjtzOjA6IiI7czo2OiJudW1iZXIiO2k6NTt9', '2' );

kt_add_widget( 'recent-comments', 'sidebar-primary', '2', 'YToyOntzOjU6InRpdGxlIjtzOjA6IiI7czo2OiJudW1iZXIiO2k6NTt9', '2' );

kt_add_widget( 'kt_image', 'sidebar-primary', '3', 'YTo0OntzOjQ6ImxpbmsiO3M6MDoiIjtzOjY6InRhcmdldCI7czo1OiJfc2VsZiI7czo0OiJzaXplIjtzOjA6IiI7czoxMDoiYXR0YWNobWVudCI7aToyMTUwO30=', '3' );

kt_add_widget( 'categories', 'sidebar-primary', '2', 'YTo0OntzOjU6InRpdGxlIjtzOjA6IiI7czo1OiJjb3VudCI7aTowO3M6MTI6ImhpZXJhcmNoaWNhbCI7aTowO3M6ODoiZHJvcGRvd24iO2k6MDt9', '2' );

kt_add_widget( 'tag_cloud', 'sidebar-primary', '3', 'YToyOntzOjU6InRpdGxlIjtzOjQ6IlRBR1MiO3M6ODoidGF4b25vbXkiO3M6ODoicG9zdF90YWciO30=', '3' );

kt_add_widget( 'kt_image', 'sidebar-primary', '2', 'YTo0OntzOjQ6ImxpbmsiO3M6MDoiIjtzOjY6InRhcmdldCI7czo1OiJfc2VsZiI7czo0OiJzaXplIjtzOjA6IiI7czoxMDoiYXR0YWNobWVudCI7aToyMTQ5O30=', '2' );

kt_add_widget( 'woocommerce_product_categories', 'sidebar-shop', '2', 'YTo2OntzOjU6InRpdGxlIjtzOjE4OiJQcm9kdWN0IENhdGVnb3JpZXMiO3M6Nzoib3JkZXJieSI7czo0OiJuYW1lIjtzOjg6ImRyb3Bkb3duIjtpOjA7czo1OiJjb3VudCI7aTowO3M6MTI6ImhpZXJhcmNoaWNhbCI7czoxOiIxIjtzOjE4OiJzaG93X2NoaWxkcmVuX29ubHkiO3M6MToiMSI7fQ==', '2' );

kt_add_widget( 'woocommerce_layered_nav_filters', 'sidebar-shop', '3', 'YToxOntzOjU6InRpdGxlIjtzOjE0OiJBY3RpdmUgRmlsdGVycyI7fQ==', '3' );

kt_add_widget( 'woocommerce_price_filter', 'sidebar-shop', '2', 'YToxOntzOjU6InRpdGxlIjtzOjE1OiJGaWx0ZXIgYnkgcHJpY2UiO30=', '2' );

kt_add_widget( 'woocommerce_layered_nav_filters', 'sidebar-shop', '2', 'YToxOntzOjU6InRpdGxlIjtzOjE0OiJBY3RpdmUgRmlsdGVycyI7fQ==', '2' );

kt_add_widget( 'woocommerce_layered_nav', 'sidebar-shop', '2', 'YTo0OntzOjU6InRpdGxlIjtzOjk6IkZpbHRlciBieSI7czo5OiJhdHRyaWJ1dGUiO3M6NToiY29sb3IiO3M6MTI6ImRpc3BsYXlfdHlwZSI7czo0OiJsaXN0IjtzOjEwOiJxdWVyeV90eXBlIjtzOjM6ImFuZCI7fQ==', '2' );

kt_add_widget( 'woocommerce_layered_nav', 'sidebar-shop', '3', 'YTo0OntzOjU6InRpdGxlIjtzOjk6IkZpbHRlciBieSI7czo5OiJhdHRyaWJ1dGUiO3M6NDoic2l6ZSI7czoxMjoiZGlzcGxheV90eXBlIjtzOjQ6Imxpc3QiO3M6MTA6InF1ZXJ5X3R5cGUiO3M6MzoiYW5kIjt9', '3' );

kt_add_widget( 'woocommerce_product_tag_cloud', 'sidebar-shop', '2', 'YToxOntzOjU6InRpdGxlIjtzOjEyOiJQcm9kdWN0IFRhZ3MiO30=', '2' );

kt_add_widget( 'widget_kt_product_special', 'sidebar-shop', '2', 'YTo0OntzOjU6InRpdGxlIjtzOjE2OiJTUEVDSUFMIFBST0RVQ1RTIjtzOjc6Im9yZGVyYnkiO3M6NDoiZGF0ZSI7czo1OiJvcmRlciI7czo0OiJkZXNjIjtzOjE0OiJwb3N0c19wZXJfcGFnZSI7aTozO30=', '2' );

kt_add_widget( 'widget_kt_testimonial', 'sidebar-shop', '2', 'YTo3OntzOjU6InRpdGxlIjtzOjEyOiJURVNUSU1PTklBTFMiO3M6ODoiYXV0b3BsYXkiO3M6Mjoib24iO3M6NDoibG9vcCI7czoyOiJvbiI7czoxMDoic2xpZGVzcGVlZCI7aToyNTA7czo2OiJudW1iZXIiO2k6MztzOjc6Im9yZGVyYnkiO3M6NDoiZGF0ZSI7czo1OiJvcmRlciI7czo0OiJkZXNjIjt9', '2' );

kt_add_widget( 'nav_menu', 'footer-menu-1', '2', 'YToyOntzOjU6InRpdGxlIjtzOjg6IktVVEVTSE9QIjtzOjg6Im5hdl9tZW51IjtpOjE2MDt9', '2' );

kt_add_widget( 'nav_menu', 'footer-menu-2', '3', 'YToyOntzOjU6InRpdGxlIjtzOjg6IlBST0RVQ1RTIjtzOjg6Im5hdl9tZW51IjtpOjIyMjt9', '3' );

kt_add_widget( 'nav_menu', 'footer-menu-3', '4', 'YToyOntzOjU6InRpdGxlIjtzOjE1OiJDVVNUT00gU0VSVklDRVMiO3M6ODoibmF2X21lbnUiO2k6MjIzO30=', '4' );

kt_add_widget( 'widget_kt_social', 'footer-menu-4', '2', 'YToxOntzOjY6Ind0aXRsZSI7czoyMToiIExFVCYjMDM5O1MgU09DSUFMSVpFIjt9', '2' );

kt_add_widget( 'widget_kt_mailchimp', 'footer-menu-4', '2', 'YToxMTp7czo1OiJ0aXRsZSI7czoyMjoiU0lHTiBVUCBGT1IgTkVXU0xFVFRFUiI7czo0OiJsaXN0IjtzOjA6IiI7czo2OiJvcHRfaW4iO3M6Mjoibm8iO3M6MTE6InRleHRfYmVmb3JlIjtzOjA6IiI7czoxMDoidGV4dF9hZnRlciI7czowOiIiO3M6NzoiY29udGVudCI7czo4NzoiU3VjY2VzcyEgIENoZWNrIHlvdXIgaW5ib3ggb3Igc3BhbSBmb2xkZXIgZm9yIGEgbWVzc2FnZSBjb250YWluaW5nIGEgY29uZmlybWF0aW9uIGxpbmsuIjtzOjY6ImxheW91dCI7czozOiJvbmUiO3M6MTQ6ImhlaWdodF9kZXNrdG9wIjtpOjA7czoxMzoiaGVpZ2h0X3RhYmxldCI7aTowO3M6MTM6ImhlaWdodF9tb2JpbGUiO2k6MDtzOjM6ImNzcyI7czowOiIiO30=', '2' );

kt_add_widget( 'nav_menu', 'footer-menu-bottom', '5', 'YToyOntzOjU6InRpdGxlIjtzOjI5OiJDb21wYW55IEluZm8g4oCTIFBhcnRuZXJzaGlwcyI7czo4OiJuYXZfbWVudSI7aToxNzM7fQ==', '5' );

