<?php
kt_download_media(2126, '11', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/11/11.png');

kt_download_media(2127, '7', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/11/71.png');

kt_download_media(2130, 'men', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/11/men.png');

kt_download_media(2132, 'women', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/11/women.png');

kt_download_media(2133, 'kid', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/11/kid.png');

kt_download_media(2135, 'trending', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/11/trending.png');
