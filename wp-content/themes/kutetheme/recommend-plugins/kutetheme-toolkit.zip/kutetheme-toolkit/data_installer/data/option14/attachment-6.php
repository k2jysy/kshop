<?php
kt_download_media(2033, '80', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/08/80.jpg');

kt_download_media(2034, '81', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/08/81.jpg');

kt_download_media(2035, '82', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/08/82.jpg');
