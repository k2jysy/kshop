<?php
kt_download_media(2061, 'i 3', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/10/i-3.jpg');

kt_download_media(2063, 'i 13', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/10/i-13.jpg');

kt_download_media(2064, 'i 14', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/10/i-14.jpg');

kt_download_media(2090, 'i 5', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/10/i-5.jpg');

kt_download_media(2091, 'i 1', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/10/i-1.jpg');
