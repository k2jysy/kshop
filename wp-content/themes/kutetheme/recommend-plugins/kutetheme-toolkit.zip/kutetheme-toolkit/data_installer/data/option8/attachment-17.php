<?php
kt_download_media(2109, '308siyah-dantelli-sirt-dekolteli-balik-elbise5871', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/11/308siyah-dantelli-sirt-dekolteli-balik-elbise5871.jpg');

kt_download_media(2110, 'blog6', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/blog6.jpg');

kt_download_media(2111, 'blog7', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/blog7.jpg');

kt_download_media(2112, 'blog8', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/blog8.jpg');
