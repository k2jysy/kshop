<?php
 // Widgets
kt_add_widget( 'search', 'sidebar-primary', '2', 'YToxOntzOjU6InRpdGxlIjtzOjA6IiI7fQ==', '2' );

kt_add_widget( 'recent-posts', 'sidebar-primary', '2', 'YToyOntzOjU6InRpdGxlIjtzOjA6IiI7czo2OiJudW1iZXIiO2k6NTt9', '2' );

kt_add_widget( 'recent-comments', 'sidebar-primary', '2', 'YToyOntzOjU6InRpdGxlIjtzOjA6IiI7czo2OiJudW1iZXIiO2k6NTt9', '2' );

kt_add_widget( 'kt_image', 'sidebar-primary', '4', 'YTo0OntzOjQ6ImxpbmsiO3M6MDoiIjtzOjY6InRhcmdldCI7czo1OiJfc2VsZiI7czo0OiJzaXplIjtzOjA6IiI7czoxMDoiYXR0YWNobWVudCI7aToyMDkzO30=', '4' );

kt_add_widget( 'categories', 'sidebar-primary', '2', 'YTo0OntzOjU6InRpdGxlIjtzOjA6IiI7czo1OiJjb3VudCI7aTowO3M6MTI6ImhpZXJhcmNoaWNhbCI7aTowO3M6ODoiZHJvcGRvd24iO2k6MDt9', '2' );

kt_add_widget( 'tag_cloud', 'sidebar-primary', '3', 'YToyOntzOjU6InRpdGxlIjtzOjQ6IlRBR1MiO3M6ODoidGF4b25vbXkiO3M6ODoicG9zdF90YWciO30=', '3' );

kt_add_widget( 'kt_image', 'sidebar-primary', '3', 'YTo0OntzOjQ6ImxpbmsiO3M6MDoiIjtzOjY6InRhcmdldCI7czo1OiJfc2VsZiI7czo0OiJzaXplIjtzOjA6IiI7czoxMDoiYXR0YWNobWVudCI7aToyMDkyO30=', '3' );

kt_add_widget( 'woocommerce_product_categories', 'sidebar-shop', '2', 'YTo2OntzOjU6InRpdGxlIjtzOjE4OiJQcm9kdWN0IENhdGVnb3JpZXMiO3M6Nzoib3JkZXJieSI7czo0OiJuYW1lIjtzOjg6ImRyb3Bkb3duIjtpOjA7czo1OiJjb3VudCI7aTowO3M6MTI6ImhpZXJhcmNoaWNhbCI7czoxOiIxIjtzOjE4OiJzaG93X2NoaWxkcmVuX29ubHkiO3M6MToiMSI7fQ==', '2' );

kt_add_widget( 'woocommerce_price_filter', 'sidebar-shop', '2', 'YToxOntzOjU6InRpdGxlIjtzOjE1OiJGaWx0ZXIgYnkgcHJpY2UiO30=', '2' );

kt_add_widget( 'woocommerce_layered_nav', 'sidebar-shop', '2', 'YTo0OntzOjU6InRpdGxlIjtzOjU6IkNPTE9SIjtzOjEyOiJkaXNwbGF5X3R5cGUiO3M6NDoibGlzdCI7czoxMDoicXVlcnlfdHlwZSI7czozOiJhbmQiO3M6OToiYXR0cmlidXRlIjtzOjU6ImNvbG9yIjt9', '2' );

kt_add_widget( 'kt_image', 'sidebar-shop', '2', 'YTo0OntzOjQ6ImxpbmsiO3M6MDoiIjtzOjY6InRhcmdldCI7czo1OiJfc2VsZiI7czo0OiJzaXplIjtzOjA6IiI7czoxMDoiYXR0YWNobWVudCI7aToyMDkzO30=', '2' );

kt_add_widget( 'woocommerce_product_tag_cloud', 'sidebar-shop', '2', 'YToxOntzOjU6InRpdGxlIjtzOjEyOiJQcm9kdWN0IFRhZ3MiO30=', '2' );

kt_add_widget( 'woocommerce_products', 'sidebar-shop', '2', 'YTo3OntzOjU6InRpdGxlIjtzOjg6IlByb2R1Y3RzIjtzOjY6Im51bWJlciI7czoxOiI1IjtzOjQ6InNob3ciO3M6MDoiIjtzOjc6Im9yZGVyYnkiO3M6NDoiZGF0ZSI7czo1OiJvcmRlciI7czo0OiJkZXNjIjtzOjk6ImhpZGVfZnJlZSI7aTowO3M6MTE6InNob3dfaGlkZGVuIjtpOjA7fQ==', '2' );

kt_add_widget( 'widget_kt_testimonial', 'sidebar-shop', '2', 'YTo3OntzOjU6InRpdGxlIjtzOjEyOiJURVNUSU1PTklBTFMiO3M6ODoiYXV0b3BsYXkiO3M6Mjoib24iO3M6NDoibG9vcCI7czoyOiJvbiI7czoxMDoic2xpZGVzcGVlZCI7aToyNTA7czo2OiJudW1iZXIiO2k6MztzOjc6Im9yZGVyYnkiO3M6NDoiZGF0ZSI7czo1OiJvcmRlciI7czo0OiJkZXNjIjt9', '2' );

kt_add_widget( 'kt_image', 'sidebar-shop', '5', 'YTo0OntzOjQ6ImxpbmsiO3M6MDoiIjtzOjY6InRhcmdldCI7czo1OiJfc2VsZiI7czo0OiJzaXplIjtzOjA6IiI7czoxMDoiYXR0YWNobWVudCI7aTowO30=', '5' );

kt_add_widget( 'widget_kt_social', 'footer-menu-1', '2', 'YToxOntzOjY6Ind0aXRsZSI7czowOiIiO30=', '2' );

kt_add_widget( 'nav_menu', 'footer-menu-2', '3', 'YToyOntzOjU6InRpdGxlIjtzOjE2OiJDVVNUT01FUiBTRVJWSUNFIjtzOjg6Im5hdl9tZW51IjtpOjE2Mjt9', '3' );

kt_add_widget( 'woocommerce_product_tag_cloud', 'footer-menu-3', '3', 'YToxOntzOjU6InRpdGxlIjtzOjEyOiJQcm9kdWN0IFRhZ3MiO30=', '3' );

kt_add_widget( 'recent-posts', 'footer-menu-4', '3', 'YTozOntzOjU6InRpdGxlIjtzOjE2OiJSRUNFTlQgQkxPR1NQT1NUIjtzOjY6Im51bWJlciI7aTozO3M6OToic2hvd19kYXRlIjtiOjE7fQ==', '3' );

kt_add_widget( 'widget_kt_trademark_payment', 'footer-payment', '2', 'YTo1OntzOjY6Ind0aXRsZSI7czowOiIiO3M6NToidGl0bGUiO047czo1OiJpbWFnZSI7TjtzOjQ6ImxpbmsiO047czo2OiJ0YXJnZXQiO047fQ==', '2' );

kt_add_widget( 'nav_menu', 'footer-menu-bottom', '4', 'YToxOntzOjg6Im5hdl9tZW51IjtpOjE2MTt9', '4' );

kt_add_widget( 'nav_menu', 'footer-menu-bottom', '5', 'YToxOntzOjg6Im5hdl9tZW51IjtpOjE3Mzt9', '5' );

kt_add_widget( 'nav_menu', 'footer-menu-bottom', '6', 'YToxOntzOjg6Im5hdl9tZW51IjtpOjE3Nzt9', '6' );

