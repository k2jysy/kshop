<?php
kt_download_media(2115, 'band4', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/11/band4.png');

kt_download_media(2116, 'band5', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/11/band5.png');

kt_download_media(2117, 'band6', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/11/band6.png');

kt_download_media(2118, '4', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/11/4.png');

kt_download_media(2119, 'band7', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/11/band7.png');

kt_download_media(2120, '5', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/11/5.png');

kt_download_media(2192, 'banner', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/banner1.jpg');
