<?php
//Menu
$menu_id = kt_add_menu( 198, 'ASIAN', '' );

 // Menu Item
kt_add_menu_item( 1609, $menu_id, 0, 'Vietnamese Pho', 'custom', 1609, 'custom', '#', '', '', '' );

kt_add_menu_item( 1610, $menu_id, 0, 'Noodles', 'custom', 1610, 'custom', '#', '', '', '' );

kt_add_menu_item( 1611, $menu_id, 0, 'Seafood', 'custom', 1611, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 199, 'Categories', 'vertical' );

 // Menu Item
kt_add_menu_item( 1689, $menu_id, 0, 'Electronic', 'product_cat', 89, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/electronic/', '', '0', '1016' );

kt_add_menu_item( 2181, $menu_id, 0, 'Sports & Outdoors', 'custom', 2181, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/sports/', 'enabled', '589', '1017' );

kt_add_menu_item( 2177, $menu_id, 0, 'Smartphone', 'product_cat', 271, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/digital/smartphone/', '', '0', '1018' );

kt_add_menu_item( 1695, $menu_id, 0, 'Jewelry & Watches', 'product_cat', 102, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/jewelry/jewelry-watches/', '', '0', '1024' );

kt_add_menu_item( 2180, $menu_id, 0, 'Shoes & Accessories', 'custom', 2180, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/fashion/', 'enabled', '764', '1020' );

kt_add_menu_item( 1702, $menu_id, 0, 'Health & Beauty', 'product_cat', 96, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/fashion/health-beauty/', '', '0', '1019' );

kt_add_menu_item( 1699, $menu_id, 0, 'Television', 'product_cat', 140, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/electronic/television-2/', '', '0', '1026' );

kt_add_menu_item( 2182, $menu_id, 0, 'Toys & Hobbies', 'custom', 2182, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/furniture/', '', '0', '1019' );

kt_add_menu_item( 2183, $menu_id, 0, 'Flashlights & Lamp', 'custom', 2183, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/furniture/', '', '0', '1025' );

kt_add_menu_item( 1700, $menu_id, 0, 'Fashion', 'product_cat', 90, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/fashion/', '', '0', '1022' );

kt_add_menu_item( 1701, $menu_id, 0, 'Furniture', 'product_cat', 93, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/furniture/', '', '0', '1023' );

kt_add_menu_item( 2178, $menu_id, 0, 'Camera', 'product_cat', 165, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/digital/camera/', '', '0', '1027' );

kt_add_menu_item( 2179, $menu_id, 0, 'Computer', 'product_cat', 270, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/digital/computer/', '', '0', '1023' );

//Menu
$menu_id = kt_add_menu( 200, 'Chicken', '' );

 // Menu Item
kt_add_menu_item( 1621, $menu_id, 0, 'Italian Pizza', 'custom', 1621, 'custom', '#', '', '', '' );

kt_add_menu_item( 1622, $menu_id, 0, 'French Cakes', 'custom', 1622, 'custom', '#', '', '', '' );

kt_add_menu_item( 1623, $menu_id, 0, 'Tops', 'custom', 1623, 'custom', '#', '', '', '' );

kt_add_menu_item( 1624, $menu_id, 0, 'Tops', 'custom', 1624, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 201, 'Company', '' );

 // Menu Item
kt_add_menu_item( 1651, $menu_id, 0, 'About Us', 'custom', 1651, 'custom', '#', '', '', '' );

kt_add_menu_item( 1652, $menu_id, 0, 'Testimonials', 'custom', 1652, 'custom', '#', '', '', '' );

kt_add_menu_item( 1653, $menu_id, 0, 'Affiliate Program', 'custom', 1653, 'custom', '#', '', '', '' );

kt_add_menu_item( 1654, $menu_id, 0, 'Terms & Conditions', 'custom', 1654, 'custom', '#', '', '', '' );

kt_add_menu_item( 1655, $menu_id, 0, 'Contact Us', 'custom', 1655, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 202, 'Company Info - Partnerships', '' );

 // Menu Item
kt_add_menu_item( 1661, $menu_id, 0, 'Company Info - Partnerships', 'custom', 1661, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 204, 'Digital', '' );

 // Menu Item
kt_add_menu_item( 1636, $menu_id, 0, 'Mobile', 'custom', 1636, 'custom', '#', '', '', '' );

kt_add_menu_item( 1637, $menu_id, 0, 'Tablets', 'custom', 1637, 'custom', '#', '', '', '' );

kt_add_menu_item( 1638, $menu_id, 0, 'Laptop', 'custom', 1638, 'custom', '#', '', '', '' );

kt_add_menu_item( 1639, $menu_id, 0, 'Memory Cards', 'custom', 1639, 'custom', '#', '', '', '' );

kt_add_menu_item( 1640, $menu_id, 0, 'Accessories', 'custom', 1640, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 205, 'euro', '' );

 // Menu Item
kt_add_menu_item( 1614, $menu_id, 0, 'Greek Potatoes', 'custom', 1614, 'custom', '#', '', '', '' );

kt_add_menu_item( 1625, $menu_id, 0, 'Famous Spaghetti', 'custom', 1625, 'custom', '#', '', '', '' );

kt_add_menu_item( 1626, $menu_id, 0, 'Famous Spaghetti', 'custom', 1626, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 206, 'Fashion', '' );

 // Menu Item
kt_add_menu_item( 1714, $menu_id, 0, 'Skirts', 'custom', 1714, 'custom', '#', '', '', '' );

kt_add_menu_item( 1715, $menu_id, 0, 'Jackets', 'custom', 1715, 'custom', '#', '', '', '' );

kt_add_menu_item( 1716, $menu_id, 0, 'Tops', 'custom', 1716, 'custom', '#', '', '', '' );

kt_add_menu_item( 1717, $menu_id, 0, 'Scarves', 'custom', 1717, 'custom', '#', '', '', '' );

kt_add_menu_item( 1718, $menu_id, 0, 'Pants', 'custom', 1718, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 207, 'Fast', '' );

 // Menu Item
kt_add_menu_item( 1629, $menu_id, 0, 'Hamberger', 'custom', 1629, 'custom', '#', '', '', '' );

kt_add_menu_item( 1630, $menu_id, 0, 'Pizza', 'custom', 1630, 'custom', '#', '', '', '' );

kt_add_menu_item( 1631, $menu_id, 0, 'Noodles', 'custom', 1631, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 210, 'Kids', '' );

 // Menu Item
kt_add_menu_item( 1709, $menu_id, 0, 'Shoes', 'custom', 1709, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/fashion/', '', '0', '' );

kt_add_menu_item( 1710, $menu_id, 0, 'Clothing', 'custom', 1710, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/fashion/', '', '0', '' );

kt_add_menu_item( 1711, $menu_id, 0, 'Tops', 'custom', 1711, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/fashion/', '', '0', '' );

kt_add_menu_item( 1712, $menu_id, 0, 'Scarves', 'custom', 1712, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/fashion/', '', '0', '' );

kt_add_menu_item( 1713, $menu_id, 0, 'Accessories', 'custom', 1713, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/fashion/', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 211, 'Main menu', 'primary' );

 // Menu Item
kt_add_menu_item( 2041, $menu_id, 0, 'Home', 'page', 347, 'post_type', 'http://kutethemes.net/wordpress/kuteshop/option5/', '', '0', '' );

kt_add_menu_item( 1719, $menu_id, 2041, 'Home 1', 'custom', 1719, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option1', '', '0', '' );

kt_add_menu_item( 1720, $menu_id, 2041, 'Home 2', 'custom', 1720, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option2', '', '0', '' );

kt_add_menu_item( 2186, $menu_id, 2041, 'Home 5', 'custom', 2186, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option5/', '', '0', '' );

kt_add_menu_item( 1721, $menu_id, 2041, 'Home 6', 'custom', 1721, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option6', '', '0', '' );

kt_add_menu_item( 1615, $menu_id, 0, 'Fashion', 'product_cat', 90, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/fashion/', 'enabled', '23', '' );

kt_add_menu_item( 1616, $menu_id, 0, 'Foods', 'product_cat', 92, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/foods/', 'enabled', '40', '' );

kt_add_menu_item( 1617, $menu_id, 0, 'Sports', 'product_cat', 135, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/sports/', '', '0', '' );

kt_add_menu_item( 1618, $menu_id, 0, 'Digital', 'product_cat', 88, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/digital/', '', '0', '' );

kt_add_menu_item( 2161, $menu_id, 1618, 'Mobile', 'product_cat', 113, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/digital/mobile/', '', '0', '' );

kt_add_menu_item( 2162, $menu_id, 1618, 'Laptop', 'product_cat', 106, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/digital/laptop/', '', '0', '' );

kt_add_menu_item( 2163, $menu_id, 1618, 'Camera', 'product_cat', 165, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/digital/camera/', '', '0', '' );

kt_add_menu_item( 2164, $menu_id, 1618, 'Notebook', 'product_cat', 118, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/digital/notebook/', '', '0', '' );

kt_add_menu_item( 2165, $menu_id, 1618, 'Smartphone', 'product_cat', 271, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/digital/smartphone/', '', '0', '' );

kt_add_menu_item( 1619, $menu_id, 0, 'Furniture', 'product_cat', 93, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/furniture/', '', '0', '' );

kt_add_menu_item( 1620, $menu_id, 0, 'Jewelry', 'product_cat', 101, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/jewelry/', '', '0', '' );

kt_add_menu_item( 2040, $menu_id, 0, 'Blog', 'page', 975, 'post_type', 'http://kutethemes.net/wordpress/kuteshop/option5/sample-page-2/', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 212, 'Mens', '' );

 // Menu Item
kt_add_menu_item( 1600, $menu_id, 0, 'Jackets', 'product_cat', 100, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/fashion/jackets-fashion/', '', '0', '' );

kt_add_menu_item( 2125, $menu_id, 0, 'Casual', 'product_cat', 278, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/fashion/casual/', '', '0', '' );

kt_add_menu_item( 2126, $menu_id, 0, 'Jumpsuits', 'product_cat', 103, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/fashion/jumpsuits/', '', '0', '' );

kt_add_menu_item( 2127, $menu_id, 0, 'Beauty', 'product_cat', 280, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/fashion/beauty/', '', '0', '' );

kt_add_menu_item( 2128, $menu_id, 0, 'T- Shirts', 'custom', 2128, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/fashion/', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 213, 'Most Populars', '' );

 // Menu Item
kt_add_menu_item( 1669, $menu_id, 0, 'Most Populars', 'custom', 1669, 'custom', '#', '', '', '' );

kt_add_menu_item( 1670, $menu_id, 0, 'Best Sellers', 'custom', 1670, 'custom', '#', '', '', '' );

kt_add_menu_item( 1671, $menu_id, 0, 'New Arrivals', 'custom', 1671, 'custom', '#', '', '', '' );

kt_add_menu_item( 1672, $menu_id, 0, 'Special Products', 'custom', 1672, 'custom', '#', '', '', '' );

kt_add_menu_item( 1673, $menu_id, 0, 'Manufacturers', 'custom', 1673, 'custom', '#', '', '', '' );

kt_add_menu_item( 1674, $menu_id, 0, 'Our Stores', 'custom', 1674, 'custom', '#', '', '', '' );

kt_add_menu_item( 1675, $menu_id, 0, 'Shipping', 'custom', 1675, 'custom', '#', '', '', '' );

kt_add_menu_item( 1676, $menu_id, 0, 'Payments', 'custom', 1676, 'custom', '#', '', '', '' );

kt_add_menu_item( 1677, $menu_id, 0, 'Payments', 'custom', 1677, 'custom', '#', '', '', '' );

kt_add_menu_item( 1678, $menu_id, 0, 'Refunds', 'custom', 1678, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 214, 'My account', '' );

 // Menu Item
kt_add_menu_item( 1656, $menu_id, 0, 'My Order', 'custom', 1656, 'custom', '#', '', '', '' );

kt_add_menu_item( 1657, $menu_id, 0, 'My Wishlist', 'custom', 1657, 'custom', '#', '', '', '' );

kt_add_menu_item( 1658, $menu_id, 0, 'My Credit Slip', 'custom', 1658, 'custom', '#', '', '', '' );

kt_add_menu_item( 1659, $menu_id, 0, 'My Addresses', 'custom', 1659, 'custom', '#', '', '', '' );

kt_add_menu_item( 1660, $menu_id, 0, 'My Personal In', 'custom', 1660, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 217, 'OnlineShop', '' );

 // Menu Item
kt_add_menu_item( 1662, $menu_id, 0, 'Online Shopping', 'custom', 1662, 'custom', '#', '', '', '' );

kt_add_menu_item( 1663, $menu_id, 0, 'Promotions', 'custom', 1663, 'custom', '#', '', '', '' );

kt_add_menu_item( 1664, $menu_id, 0, 'My Orders', 'custom', 1664, 'custom', '#', '', '', '' );

kt_add_menu_item( 1665, $menu_id, 0, 'Help', 'custom', 1665, 'custom', '#', '', '', '' );

kt_add_menu_item( 1666, $menu_id, 0, 'Site Map', 'custom', 1666, 'custom', '#', '', '', '' );

kt_add_menu_item( 1667, $menu_id, 0, 'Customer Service', 'custom', 1667, 'custom', '#', '', '', '' );

kt_add_menu_item( 1668, $menu_id, 0, 'Support', 'custom', 1668, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 219, 'Sandwich', '' );

 // Menu Item
kt_add_menu_item( 1632, $menu_id, 0, 'Salad', 'custom', 1632, 'custom', '#', '', '', '' );

kt_add_menu_item( 1633, $menu_id, 0, 'Paste', 'custom', 1633, 'custom', '#', '', '', '' );

kt_add_menu_item( 1634, $menu_id, 0, 'Tops', 'custom', 1634, 'custom', '#', '', '', '' );

kt_add_menu_item( 1635, $menu_id, 0, 'Tops', 'custom', 1635, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 220, 'SAUSAGES', '' );

 // Menu Item
kt_add_menu_item( 1612, $menu_id, 0, 'Meat Dishes', 'custom', 1612, 'custom', '#', '', '', '' );

kt_add_menu_item( 1613, $menu_id, 0, 'Desserts', 'custom', 1613, 'custom', '#', '', '', '' );

kt_add_menu_item( 1627, $menu_id, 0, 'Tops', 'custom', 1627, 'custom', '#', '', '', '' );

kt_add_menu_item( 1628, $menu_id, 0, 'Tops', 'custom', 1628, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 222, 'Sports', '' );

 // Menu Item
kt_add_menu_item( 1703, $menu_id, 0, 'Tennis', 'custom', 1703, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/sports/', '', '0', '' );

kt_add_menu_item( 1704, $menu_id, 0, 'Coats & Jackets', 'custom', 1704, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/sports/', '', '0', '' );

kt_add_menu_item( 1705, $menu_id, 0, 'Blouses & Shirts', 'custom', 1705, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/sports/', '', '0', '' );

kt_add_menu_item( 1706, $menu_id, 0, 'Tops & Tees', 'custom', 1706, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/sports/', '', '0', '' );

kt_add_menu_item( 1707, $menu_id, 0, 'Hoodies & Sweatshirts', 'custom', 1707, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/sports/', '', '0', '' );

kt_add_menu_item( 1708, $menu_id, 0, 'Intimates', 'custom', 1708, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/sports/', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 223, 'Support', '' );

 // Menu Item
kt_add_menu_item( 1646, $menu_id, 0, 'About us', 'custom', 1646, 'custom', '#', '', '', '' );

kt_add_menu_item( 1647, $menu_id, 0, 'Testimonials', 'custom', 1647, 'custom', '#', '', '', '' );

kt_add_menu_item( 1648, $menu_id, 0, 'Affiliate Program', 'custom', 1648, 'custom', '#', '', '', '' );

kt_add_menu_item( 1649, $menu_id, 0, 'Terms & Conditions', 'custom', 1649, 'custom', '#', '', '', '' );

kt_add_menu_item( 1650, $menu_id, 0, 'Contact Us', 'custom', 1650, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 224, 'Terms &amp; Conditions', '' );

 // Menu Item
kt_add_menu_item( 1679, $menu_id, 0, 'Terms & Conditions', 'custom', 1679, 'custom', '#', '', '', '' );

kt_add_menu_item( 1680, $menu_id, 0, 'Policy', 'custom', 1680, 'custom', '#', '', '', '' );

kt_add_menu_item( 1681, $menu_id, 0, 'Policy', 'custom', 1681, 'custom', '#', '', '', '' );

kt_add_menu_item( 1682, $menu_id, 0, 'Shipping', 'custom', 1682, 'custom', '#', '', '', '' );

kt_add_menu_item( 1683, $menu_id, 0, 'Payments', 'custom', 1683, 'custom', '#', '', '', '' );

kt_add_menu_item( 1684, $menu_id, 0, 'Returns', 'custom', 1684, 'custom', '#', '', '', '' );

kt_add_menu_item( 1685, $menu_id, 0, 'Refunds', 'custom', 1685, 'custom', '#', '', '', '' );

kt_add_menu_item( 1686, $menu_id, 0, 'Warrantee', 'custom', 1686, 'custom', '#', '', '', '' );

kt_add_menu_item( 1687, $menu_id, 0, 'FAQ', 'custom', 1687, 'custom', '#', '', '', '' );

kt_add_menu_item( 1688, $menu_id, 0, 'Contact', 'custom', 1688, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 288, 'Topbar menu left', 'topbar_menuleft' );

 // Menu Item
kt_add_menu_item( 2239, $menu_id, 0, '<i class=\"fa fa-phone\"></i> +00 123 456 789', 'custom', 2239, 'custom', '#', '', '0', '' );

kt_add_menu_item( 2240, $menu_id, 0, '<i class=\"fa fa-envelope\"></i> Contact us today !', 'custom', 2240, 'custom', '#', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 289, 'Topbar menu right', 'topbar_menuright' );

 // Menu Item
kt_add_menu_item( 2241, $menu_id, 0, 'Support', 'page', 371, 'post_type', 'http://kutethemes.net/wordpress/kuteshop/option5/support/', '', '0', '' );

kt_add_menu_item( 2242, $menu_id, 0, 'Services', 'page', 369, 'post_type', 'http://kutethemes.net/wordpress/kuteshop/option5/services/', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 225, 'Trending', '' );

 // Menu Item
kt_add_menu_item( 1605, $menu_id, 0, 'Men\'s Clothing', 'custom', 1605, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/fashion/', '', '0', '' );

kt_add_menu_item( 1606, $menu_id, 0, 'Kid\'s Clothing', 'custom', 1606, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/fashion/', '', '0', '' );

kt_add_menu_item( 1607, $menu_id, 0, 'Women\'s Clothing', 'custom', 1607, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/fashion/', '', '0', '' );

kt_add_menu_item( 2134, $menu_id, 0, 'New Style', 'custom', 2134, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/fashion/', '', '0', '' );

kt_add_menu_item( 1608, $menu_id, 0, 'Accessories', 'custom', 1608, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/fashion/', '', '0', '' );

//Menu
$menu_id = kt_add_menu( 282, 'Women', '' );

 // Menu Item
kt_add_menu_item( 2129, $menu_id, 0, 'Beauty', 'product_cat', 280, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/fashion/beauty/', '', '0', '' );

kt_add_menu_item( 2130, $menu_id, 0, 'Casual', 'product_cat', 278, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/fashion/casual/', '', '0', '' );

kt_add_menu_item( 2131, $menu_id, 0, 'Jackets', 'product_cat', 100, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/fashion/jackets-fashion/', '', '0', '' );

kt_add_menu_item( 2132, $menu_id, 0, 'Jumpsuits', 'product_cat', 103, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/fashion/jumpsuits/', '', '0', '' );

kt_add_menu_item( 2133, $menu_id, 0, 'T- Shirts', 'custom', 2133, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option5/product-category/fashion/', '', '0', '' );

