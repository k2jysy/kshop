<?php
//Menu
$menu_id = kt_add_menu( 48, 'footer kuteshop', '' );

 // Menu Item
kt_add_menu_item( 208, $menu_id, 0, 'About us', 'custom', 208, 'custom', '#', '', '', '' );

kt_add_menu_item( 209, $menu_id, 0, 'Customer Service', 'custom', 209, 'custom', '#', '', '', '' );

kt_add_menu_item( 210, $menu_id, 0, 'New Collection', 'custom', 210, 'custom', '#', '', '', '' );

kt_add_menu_item( 211, $menu_id, 0, 'Manufacturers', 'custom', 211, 'custom', '#', '', '', '' );

kt_add_menu_item( 212, $menu_id, 0, 'Privacy policy', 'custom', 212, 'custom', '#', '', '', '' );

kt_add_menu_item( 213, $menu_id, 0, 'Terms & condition', 'custom', 213, 'custom', '#', '', '', '' );

kt_add_menu_item( 214, $menu_id, 0, 'Blog', 'custom', 214, 'custom', '#', '', '', '' );
