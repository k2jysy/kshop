<?php
// Attachment
kt_download_media(2017, '64', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/08/64.jpg');

kt_download_media(2018, '65', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/08/65.jpg');

kt_download_media(2019, '66', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/08/66.jpg');

kt_download_media(2020, '67', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/08/67.jpg');
