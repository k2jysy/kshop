<?php
kt_download_media(2274, 'icon-s3', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/icon-s3.png');

kt_download_media(2275, 'icon-s4', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/icon-s4.png');

kt_download_media(2276, 'icon-s5', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/icon-s5.png');

kt_download_media(2277, 'icon-s6', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/icon-s6.png');

kt_download_media(2279, 'logo', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/12/logo.png');
