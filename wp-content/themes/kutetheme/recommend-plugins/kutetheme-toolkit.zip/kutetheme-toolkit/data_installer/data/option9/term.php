<?php
// Custom term
kt_add_category( 11, 'actual', 'actual', 'product_tag', '0', 'Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Vivamus magna justo, lacinia eget consectetur sed' );

kt_add_category( 12, 'beauty', 'beauty', 'product_tag', '0', 'Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Vivamus magna justo, lacinia eget consectetur sed Proin eget tortor risus. Cras ultricies ligula sed magna dictum porta. Nulla porttitor accumsan tincidunt.' );

kt_add_brand( 15, 'Brand 2', 'brand-2', 'product_brand', '0', '', '842' );

kt_add_brand( 16, 'Brand 3', 'brand-3', 'product_brand', '0', '', '841' );

kt_add_brand( 17, 'Brand 4', 'brand-4', 'product_brand', '0', '', '840' );

kt_add_brand( 18, 'Brand 5', 'brand-5', 'product_brand', '0', '', '839' );

kt_add_brand( 19, 'Brand 6', 'brand-6', 'product_brand', '0', '', '838' );

kt_add_brand( 20, 'Brand 7', 'brand-7', 'product_brand', '0', '', '837' );

kt_add_category( 21, 'charming', 'charming', 'product_tag', '0', 'Nulla quis lorem ut libero malesuada feugiat. Donec sollicitudin molestie malesuada. Mauris blandit aliquet elit,' );

kt_add_category( 22, 'colorful', 'colorful', 'product_tag', '0', 'Nulla quis lorem ut libero malesuada feugiat. Donec sollicitudin molestie malesuada. Mauris blandit aliquet elit,' );

kt_add_category( 23, 'comfor', 'comfor', 'product_tag', '0', '' );

kt_add_category( 24, 'comfort', 'comfort', 'product_tag', '0', 'Nulla quis lorem ut libero malesuada feugiat. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus.' );

kt_add_category( 5, 'external', 'external', 'product_type', '0', '' );

kt_add_brand( 25, 'Git', 'git', 'product_brand', '0', '', '836' );

kt_add_category( 3, 'grouped', 'grouped', 'product_type', '0', '' );

kt_add_category( 27, 'long', 'long', 'product_tag', '0', 'Nulla quis lorem ut libero malesuada feugiat. Donec sollicitudin molestie malesuada. Mauris blandit aliquet elit,' );

kt_add_category( 28, 'modern', 'modern', 'product_tag', '0', 'Quisque velit nisi, pretium ut lacinia in, elementum id enim. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus' );

kt_add_category( 29, 'morden', 'morden', 'product_tag', '0', '' );

kt_add_category( 30, 'moving', 'moving', 'product_tag', '0', 'Nulla quis lorem ut libero malesuada feugiat. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus.' );

kt_add_category( 31, 'new', 'new', 'product_tag', '0', 'Nulla quis lorem ut libero malesuada feugiat. Donec sollicitudin molestie malesuada. Mauris blandit aliquet elit,' );

kt_add_category( 33, 'playing', 'playing', 'product_tag', '0', 'Nulla quis lorem ut libero malesuada feugiat. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus.' );

kt_add_category( 35, 'ruby', 'ruby', 'product_tag', '0', 'Nulla quis lorem ut libero malesuada feugiat. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus.' );

kt_add_category( 36, 'sexy', 'sexy', 'product_tag', '0', 'Nulla quis lorem ut libero malesuada feugiat. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus.' );

kt_add_category( 37, 'short', 'short', 'product_tag', '0', 'Nulla quis lorem ut libero malesuada feugiat. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus.' );

kt_add_category( 2, 'simple', 'simple', 'product_type', '0', '' );

kt_add_category( 38, 'style', 'style', 'product_tag', '0', 'Nulla quis lorem ut libero malesuada feugiat. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus.' );

kt_add_category( 4, 'variable', 'variable', 'product_type', '0', '' );

kt_add_product_cat( 39, 'Digital', 'digital', 'product_cat', '0', '', '' );

kt_add_product_cat( 40, 'Fashion', 'fashion', 'product_cat', '0', '', '' );

kt_add_product_cat( 41, 'Foods', 'foods', 'product_cat', '0', '', '' );

kt_add_product_cat( 42, 'Furniture', 'furniture', 'product_cat', '0', '', '' );

kt_add_product_cat( 43, 'Jewelry', 'jewelry', 'product_cat', '0', '', '' );

kt_add_product_cat( 44, 'Laptop', 'laptop', 'product_cat', '39', '', '' );

kt_add_product_cat( 45, 'Mobile', 'mobile', 'product_cat', '39', '', '' );

kt_add_product_cat( 46, 'Notebook', 'notebook', 'product_cat', '39', '', '' );

kt_add_product_cat( 47, 'Sport shirt', 'sport-shirt', 'product_cat', '0', 'Nullam aliquet vestibulum augue non varius. Cras nec congue elitos. Duis tristique del ante nec aliquam. Praesent urna tellus laoreet.
                    ', '855' );

kt_add_product_cat( 48, 'Sport shoes', 'sport-shoes', 'product_cat', '0', 'Nullam aliquet vestibulum augue non varius. Cras nec congue elitos. Duis tristique del ante nec aliquam. Praesent urna tellus laoreet.
                    ', '855' );

kt_add_product_cat( 49, 'Sport Trouser', 'sport-trouser', 'product_cat', '0', 'Nullam aliquet vestibulum augue non varius. Cras nec congue elitos. Duis tristique del ante nec aliquam. Praesent urna tellus laoreet.
                    ', '858' );

kt_add_product_cat( 50, 'Sports', 'sports', 'product_cat', '0', '', '' );

kt_add_product_cat( 51, 'Television', 'television', 'product_cat', '39', '', '' );

kt_add_product_cat( 52, 'Accessories', 'accessories', 'product_cat', '39', '', '' );
