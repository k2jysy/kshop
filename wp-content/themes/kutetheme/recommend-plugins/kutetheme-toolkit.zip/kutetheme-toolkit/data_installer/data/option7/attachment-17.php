<?php
kt_download_media(2613, 'blog7', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/blog7.jpg');

kt_download_media(2615, 'blog8', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/blog8.jpg');

kt_download_media(2618, 'blog11', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/blog11.jpg');

kt_download_media(2619, 'blog22', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/blog22.jpg');

kt_download_media(2620, 'blog31', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/blog31.jpg');

kt_download_media(2621, 'blog41', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/blog41.jpg');

kt_download_media(2652, 'bg13.png', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/revslider/kute-opt7/bg13.png');
