<?php
kt_download_media(2044, 'Jewelry', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/12/Jewelry.png');

kt_download_media(2045, 'shoes&acc', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/12/shoesacc.png');

kt_download_media(2046, 'smartphone', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/12/smartphone.png');

kt_download_media(2047, 'sports&o', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/12/sportso.png');

kt_download_media(2048, 'television', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/12/television.png');
