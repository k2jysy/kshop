<?php
// Attachment
kt_download_media(1814, 'digital', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/digital.png');

kt_download_media(1815, 'electronic', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/electronic.png');

kt_download_media(1816, 'fashion', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/fashion.png');

kt_download_media(1817, 'furniture', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/furniture.png');

kt_download_media(1818, 'sports', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/sports.png');

kt_download_media(1837, 'banner-botom1', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/banner-botom1.jpg');
