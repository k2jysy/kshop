<?php
kt_download_media(1000, 'trademark-dhl', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/trademark-dhl1.jpg');

kt_download_media(1001, 'trademark-fe', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/trademark-fe1.jpg');

kt_download_media(1016, 'electronic', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/electronic3.png');

kt_download_media(1017, 'sports&o', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/sportso1.png');

kt_download_media(1018, 'smartphone', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/smartphone1.png');

kt_download_media(1019, 'healthy', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/healthy1.png');
