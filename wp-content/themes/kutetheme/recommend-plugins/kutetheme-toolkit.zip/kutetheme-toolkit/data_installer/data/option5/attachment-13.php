<?php
kt_download_media(2201, 'Y2', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/Y22.jpg');

kt_download_media(2204, 'E3', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/E32.jpg');

kt_download_media(2206, 'i 32', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/i-32.jpg');

kt_download_media(2245, '10', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/10.jpg');

kt_download_media(2246, '13', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/13.jpg');
