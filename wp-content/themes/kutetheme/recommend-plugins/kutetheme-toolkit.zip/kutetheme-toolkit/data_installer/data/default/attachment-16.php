<?php
kt_download_media(2071, 'cate-product5', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/12/cate-product5.png');

kt_download_media(2072, 'cate-product1', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/12/cate-product1.png');

kt_download_media(2073, 'cate-product3', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/12/cate-product3.png');

kt_download_media(2074, 'cate-product7', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/12/cate-product7.png');

kt_download_media(2075, 'sp2', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/12/sp2.jpg');
