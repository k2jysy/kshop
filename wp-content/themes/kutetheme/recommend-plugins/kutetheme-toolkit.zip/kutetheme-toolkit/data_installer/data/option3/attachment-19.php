<?php
kt_download_media(2313, '40', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/10/40.jpg');

kt_download_media(2314, 'i 28', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/10/i-28.jpg');

kt_download_media(2315, 'i 29', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/10/i-29.jpg');

kt_download_media(2327, 'i 20', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/10/i-20.jpg');

kt_download_media(2342, 'slide-left', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/10/slide-left.jpg');

kt_download_media(2343, 'slide-left2', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/10/slide-left2.jpg');

kt_download_media(2344, 'slide-left3', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/10/slide-left3.png');

kt_download_media(2345, 'blog2', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/blog2.jpg');
