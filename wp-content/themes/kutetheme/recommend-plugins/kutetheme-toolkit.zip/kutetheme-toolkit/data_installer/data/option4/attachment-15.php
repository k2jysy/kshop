<?php
kt_download_media(2376, 'blog11', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/blog11.jpg');

kt_download_media(2377, 'blog22', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/blog22.jpg');

kt_download_media(2381, 'blog31', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/blog31.jpg');

kt_download_media(2391, 'blog41', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/blog41.jpg');

kt_download_media(2397, 'logo4', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/10/logo4.png');

kt_download_media(2398, 'bg12.png', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/revslider/kute-opt4/bg12.png');

kt_download_media(2399, 'line11.png', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/revslider/kute-opt4/line11.png');

kt_download_media(2400, 'line21.png', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/revslider/kute-opt4/line21.png');
