<?php
kt_download_media(2050, 'b3', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/b3.jpg');

kt_download_media(2052, 'l1', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/11/l1.jpg');

kt_download_media(2053, 'l2', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/11/l2.jpg');

kt_download_media(2054, 'l3', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/11/l3.jpg');
