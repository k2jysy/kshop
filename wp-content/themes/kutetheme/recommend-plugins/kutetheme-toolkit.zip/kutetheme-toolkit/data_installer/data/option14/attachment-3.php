<?php
kt_download_media(2024, '71', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/08/71.jpg');

kt_download_media(2025, '72', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/08/72.jpg');

kt_download_media(2026, '73', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/08/73.jpg');
