<?php
kt_download_media(844, 'banner2', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/banner2.jpg');

kt_download_media(845, 'banner3', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/banner3.jpg');

kt_download_media(846, 'banner4', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/banner4.jpg');

kt_download_media(847, 'banner5', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/banner5.jpg');

kt_download_media(848, 'banner6', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/banner6.jpg');

kt_download_media(849, 'banner7', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/banner7.jpg');
