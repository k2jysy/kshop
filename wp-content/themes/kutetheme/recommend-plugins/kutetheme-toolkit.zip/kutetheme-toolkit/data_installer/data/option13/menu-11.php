<?php
//Menu
$menu_id = kt_add_menu( 170, 'Kids', '' );

 // Menu Item
kt_add_menu_item( 1983, $menu_id, 0, 'Shoes', 'custom', 1983, 'custom', '#', '', '', '' );

kt_add_menu_item( 1984, $menu_id, 0, 'Clothing', 'custom', 1984, 'custom', '#', '', '', '' );

kt_add_menu_item( 1985, $menu_id, 0, 'Tops', 'custom', 1985, 'custom', '#', '', '', '' );

kt_add_menu_item( 1986, $menu_id, 0, 'Scarves', 'custom', 1986, 'custom', '#', '', '', '' );

kt_add_menu_item( 1987, $menu_id, 0, 'Accessories', 'custom', 1987, 'custom', '#', '', '', '' );
