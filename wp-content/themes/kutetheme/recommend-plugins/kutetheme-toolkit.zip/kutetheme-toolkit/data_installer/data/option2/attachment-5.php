<?php
kt_download_media(1235, 'F6', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/F6.jpg');

kt_download_media(1246, 'F1', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/F11.jpg');

kt_download_media(1247, 'L2', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/L21.jpg');

kt_download_media(1248, 'L5', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/L5.jpg');

kt_download_media(1249, 'F1', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/F12.jpg');

kt_download_media(1261, 'L1', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/L12.jpg');
