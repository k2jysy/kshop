<?php
kt_download_media(2086, '43043622_56_R', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/43043622_56_R.jpg');

kt_download_media(2087, '43060034_99', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/43060034_99.jpg');

kt_download_media(2088, '43080160_99', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/43080160_99.jpg');

kt_download_media(2089, '9', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/9.png');
