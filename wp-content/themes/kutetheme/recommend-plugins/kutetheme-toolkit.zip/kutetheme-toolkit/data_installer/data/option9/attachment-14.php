<?php
kt_download_media(853, 'banner11', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/banner11.jpg');

kt_download_media(854, 'banner12', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/banner12.jpg');

kt_download_media(855, 's1', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/s12.png');

kt_download_media(858, 's3', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/s32.png');

kt_download_media(873, 'kid', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/kid.png');
