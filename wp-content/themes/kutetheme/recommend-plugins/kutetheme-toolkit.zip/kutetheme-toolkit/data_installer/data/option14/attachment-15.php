<?php
kt_download_media(2118, 'payment', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/12/payment.png');

kt_download_media(2119, 'logo-top', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/12/logo-top.png');

kt_download_media(2120, 'logo', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/12/logo.png');
