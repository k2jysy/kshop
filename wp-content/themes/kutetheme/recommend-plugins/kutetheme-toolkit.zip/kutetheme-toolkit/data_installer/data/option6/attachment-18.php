<?php
kt_download_media(2006, '1', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/1.jpg');

kt_download_media(2007, 'television', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/12/television.png');

kt_download_media(2013, 'p54', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/p54.jpg');

kt_download_media(2014, 'p55', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/p55.jpg');

kt_download_media(2015, 'p56', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/p56.jpg');

kt_download_media(2016, 'p57', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/p57.jpg');

kt_download_media(2017, 'p58', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/p58.jpg');
