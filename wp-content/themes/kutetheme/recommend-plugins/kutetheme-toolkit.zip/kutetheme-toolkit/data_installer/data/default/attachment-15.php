<?php
kt_download_media(2065, 'f2', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/f2.jpg');

kt_download_media(2066, 'f3', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/f3.jpg');

kt_download_media(2067, 'f4', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/f4.jpg');

kt_download_media(2068, 'f5', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/f5.jpg');

kt_download_media(2069, 'f6', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/f6.jpg');
