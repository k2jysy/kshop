<?php
// Categories
kt_add_category(6,'About beauty','about-beauty','category','0','');

kt_add_category(7,'Baby &amp; Mum','baby-mum','category','0','');

kt_add_category(8,'Diet &amp; Fitness','diet-fitness','category','0','');

kt_add_category(9,'News','news','category','0','');

kt_add_category(10,'Promotions','promotions','category','0','');

kt_add_category(1,'Uncategorized','uncategorized','category','0','');
