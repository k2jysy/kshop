<?php
kt_download_media(2271, '33', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/33.jpg');

kt_download_media(2272, '34', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/34.jpg');

kt_download_media(2273, '35', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/35.jpg');

kt_download_media(2274, '36', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/36.jpg');

kt_download_media(2275, '37', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/37.jpg');

kt_download_media(2276, '38', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/38.jpg');

kt_download_media(2277, '39', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/39.jpg');
