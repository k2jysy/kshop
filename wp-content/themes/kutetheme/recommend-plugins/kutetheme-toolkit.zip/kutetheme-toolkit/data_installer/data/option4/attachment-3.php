<?php
kt_download_media(2006, 'E3', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/E3.jpg');

kt_download_media(2007, 'Y2', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/Y2.jpg');

kt_download_media(2008, 'Y2', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/Y21.jpg');

kt_download_media(2009, 'Y3', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/Y3.jpg');

kt_download_media(2010, 'Y4', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/Y4.jpg');

kt_download_media(2011, 'F2', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/F2.jpg');

kt_download_media(2012, 'F3', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/F3.jpg');
