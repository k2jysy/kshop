<?php
kt_download_media(128, '42', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/42.jpg');

kt_download_media(134, 'blog1', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/blog1.jpg');

kt_download_media(136, 'testimonial', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/testimonial.jpg');

kt_download_media(137, 'testimonials1', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/testimonials1.jpg');

kt_download_media(138, 'testimonials2', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/testimonials2.jpg');

kt_download_media(139, 'testimonials3', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/testimonials3.jpg');
