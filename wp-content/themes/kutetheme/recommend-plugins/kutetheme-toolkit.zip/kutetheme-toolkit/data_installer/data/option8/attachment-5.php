<?php
kt_download_media(2043, 'loock-boock3', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/11/loock-boock3.jpg');

kt_download_media(2044, 'loock-boock4', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/11/loock-boock4.jpg');

kt_download_media(2048, 'b1', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/b1.jpg');

kt_download_media(2049, 'b2', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/b2.jpg');
