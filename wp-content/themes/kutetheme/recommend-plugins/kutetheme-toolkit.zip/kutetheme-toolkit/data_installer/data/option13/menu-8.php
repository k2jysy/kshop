<?php
//Menu
$menu_id = kt_add_menu( 164, 'euro', '' );

 // Menu Item
kt_add_menu_item( 1888, $menu_id, 0, 'Greek Potatoes', 'custom', 1888, 'custom', '#', '', '', '' );

kt_add_menu_item( 1899, $menu_id, 0, 'Famous Spaghetti', 'custom', 1899, 'custom', '#', '', '', '' );

kt_add_menu_item( 1900, $menu_id, 0, 'Famous Spaghetti', 'custom', 1900, 'custom', '#', '', '', '' );
