<?php

//Menu
$menu_id = kt_add_menu( 17, 'Main menu', 'primary' );

 // Menu Item
kt_add_menu_item( 7, $menu_id, 0, 'Home', 'custom', 7, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option11/', '', '0', '' );

kt_add_menu_item( 930, $menu_id, 7, 'Home 1', 'custom', 930, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option1/', '', '0', '' );

kt_add_menu_item( 931, $menu_id, 7, 'Home 2', 'custom', 931, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option2/', '', '0', '' );

kt_add_menu_item( 932, $menu_id, 7, 'Home 3', 'custom', 932, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option13/', '', '0', '' );

kt_add_menu_item( 933, $menu_id, 7, 'Home 4', 'custom', 933, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option4/', '', '0', '' );

kt_add_menu_item( 934, $menu_id, 7, 'Home 5', 'custom', 934, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option5/', '', '0', '' );

kt_add_menu_item( 935, $menu_id, 7, 'Home 6', 'custom', 935, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option6/', '', '0', '' );

kt_add_menu_item( 936, $menu_id, 7, 'Home 7', 'custom', 936, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option7/', '', '0', '' );

kt_add_menu_item( 937, $menu_id, 7, 'Home 8', 'custom', 937, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option8/', '', '0', '' );

kt_add_menu_item( 938, $menu_id, 7, 'Home 9', 'custom', 938, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option9/', '', '0', '' );

kt_add_menu_item( 939, $menu_id, 7, 'Home 11', 'custom', 939, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option11/', '', '0', '' );

kt_add_menu_item( 940, $menu_id, 7, 'Home 12', 'custom', 940, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option12/', '', '0', '' );

kt_add_menu_item( 941, $menu_id, 7, 'Home 13', 'custom', 941, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option13/', '', '0', '' );

kt_add_menu_item( 942, $menu_id, 7, 'Home 14', 'custom', 942, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option14/', '', '0', '' );

kt_add_menu_item( 9, $menu_id, 0, 'Fashion', 'product_cat', 6, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option11/product-category/fashion/', 'enabled', '255', '' );

kt_add_menu_item( 10, $menu_id, 0, 'Foods', 'product_cat', 7, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option11/product-category/foods/', 'enabled', '835', '' );

kt_add_menu_item( 11, $menu_id, 0, 'Furniture', 'product_cat', 10, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option11/product-category/furniture/', '', '0', '' );

kt_add_menu_item( 13, $menu_id, 0, 'Sports', 'product_cat', 8, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option11/product-category/sports/', '', '0', '' );

kt_add_menu_item( 12, $menu_id, 0, 'Jewelry', 'product_cat', 11, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option11/product-category/jewelry/', '', '0', '' );

kt_add_menu_item( 8, $menu_id, 0, 'Digital', 'product_cat', 9, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option11/product-category/digital/', '', '0', '' );

kt_add_menu_item( 14, $menu_id, 8, 'Accessories', 'product_cat', 16, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option11/product-category/digital/accessories/', '', '0', '' );

kt_add_menu_item( 16, $menu_id, 8, 'Mobile', 'product_cat', 12, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option11/product-category/digital/mobile/', '', '0', '' );

kt_add_menu_item( 17, $menu_id, 8, 'Notebook', 'product_cat', 13, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option11/product-category/digital/notebook/', '', '0', '' );

kt_add_menu_item( 15, $menu_id, 8, 'Laptop', 'product_cat', 14, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option11/product-category/digital/laptop/', '', '0', '' );

kt_add_menu_item( 18, $menu_id, 8, 'Television', 'product_cat', 15, 'taxonomy', 'http://kutethemes.net/wordpress/kuteshop/option11/product-category/digital/television/', '', '0', '' );

kt_add_menu_item( 174, $menu_id, 0, 'Blog', 'page', 171, 'post_type', 'http://kutethemes.net/wordpress/kuteshop/option11/blog/', '', '0', '' );
