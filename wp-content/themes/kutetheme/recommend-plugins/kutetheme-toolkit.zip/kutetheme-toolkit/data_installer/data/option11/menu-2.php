<?php
//Menu
$menu_id = kt_add_menu( 64, 'Chicken', '' );

 // Menu Item
kt_add_menu_item( 894, $menu_id, 0, 'Italian Pizza', 'custom', 894, 'custom', '#', '', '0', '' );

kt_add_menu_item( 895, $menu_id, 0, 'French Cakes', 'custom', 895, 'custom', '#', '', '0', '' );

kt_add_menu_item( 896, $menu_id, 0, 'Shrimp', 'custom', 896, 'custom', '#', '', '0', '' );

kt_add_menu_item( 897, $menu_id, 0, 'Tops', 'custom', 897, 'custom', '#', '', '0', '' );
