<?php

kt_download_media(2210, 'band2', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/12/band2.png');

kt_download_media(2211, 'band3', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/12/band3.png');

kt_download_media(2212, 'band4', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/12/band4.png');

kt_download_media(2213, 'band5', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/12/band5.png');

kt_download_media(2214, 'band6', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/12/band6.png');

kt_download_media(2215, 'band7', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/12/band7.png');
