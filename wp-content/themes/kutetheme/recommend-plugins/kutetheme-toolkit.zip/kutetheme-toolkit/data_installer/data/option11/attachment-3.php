<?php
kt_download_media(43, '6', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/6.png');

kt_download_media(44, '7', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/7.png');

kt_download_media(45, '8', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/8.png');

kt_download_media(46, '9', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/9.png');

kt_download_media(47, '10', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/10.png');

kt_download_media(48, '11', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/11.png');
