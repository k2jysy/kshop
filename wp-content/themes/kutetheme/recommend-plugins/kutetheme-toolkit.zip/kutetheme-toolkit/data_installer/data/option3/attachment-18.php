<?php
kt_download_media(2288, 'Com&net', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/10/Comnet.png');

kt_download_media(2289, 'Jewelry', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/10/Jewelry.png');

kt_download_media(2290, 'Flashlights', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/10/Flashlights.png');

kt_download_media(2291, 'Lap&acc', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/10/Lapacc.png');

kt_download_media(2292, 'television', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/10/television.png');

kt_download_media(2293, 'shoes&acc', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/10/shoesacc1.png');

kt_download_media(2295, 'adv2', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/adv2.jpg');

kt_download_media(2299, 'adv4', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/adv4.jpg');
