<?php

kt_download_media(2225, '1', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/12/1.jpg');

kt_download_media(2226, '2', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/12/2.jpg');

kt_download_media(2228, '4', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/12/4.jpg');

kt_download_media(2229, '5', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/12/5.jpg');

kt_download_media(2230, '6', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/12/6.jpg');

kt_download_media(2231, '7', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/12/7.jpg');
