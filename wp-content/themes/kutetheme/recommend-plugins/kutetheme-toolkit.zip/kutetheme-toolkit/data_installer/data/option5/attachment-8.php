<?php
kt_download_media(1525, 'banner1', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/banner11.jpg');

kt_download_media(1526, 'banner2', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/banner2.jpg');

kt_download_media(1597, 'A1', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/A12.jpg');

kt_download_media(1598, 'A2', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/A21.jpg');

kt_download_media(1599, 'A3', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/A3.jpg');
