<?php
//Menu
$menu_id = kt_add_menu( 158, 'Categories', 'vertical' );

 // Menu Item
kt_add_menu_item( 1963, $menu_id, 0, 'Electronic', 'product_cat', 89, 'taxonomy', 'http://kutethemes.net/sample-data/kuteshop/default/product-category/electronic/', '', '0', '2041' );

kt_add_menu_item( 1964, $menu_id, 0, 'Sport & Outdoors', 'product_cat', 114, 'taxonomy', 'http://kutethemes.net/sample-data/kuteshop/default/product-category/sport-outdoor/', 'enabled', '766', '2047' );

kt_add_menu_item( 1965, $menu_id, 0, 'Smartphone & Tablets', 'product_cat', 113, 'taxonomy', 'http://kutethemes.net/sample-data/kuteshop/default/product-category/digital/smartphone-tablets/', '', '0', '2046' );

kt_add_menu_item( 1967, $menu_id, 0, 'Health & Beauty Bags', 'product_cat', 95, 'taxonomy', 'http://kutethemes.net/sample-data/kuteshop/default/product-category/fashion/health-beauty-bags/', '', '0', '2045' );

kt_add_menu_item( 1966, $menu_id, 0, 'Shoes & Accessories', 'product_cat', 111, 'taxonomy', 'http://kutethemes.net/sample-data/kuteshop/default/product-category/fashion/shoes-accessories/', '', '0', '2045' );

kt_add_menu_item( 1970, $menu_id, 0, 'Toys & Hobbies', 'product_cat', 122, 'taxonomy', 'http://kutethemes.net/sample-data/kuteshop/default/product-category/toys-hobbies/', '', '0', '2042' );

kt_add_menu_item( 1968, $menu_id, 0, 'Computers & Networking', 'product_cat', 140, 'taxonomy', 'http://kutethemes.net/sample-data/kuteshop/default/product-category/digital/computers-networking/', '', '0', '2040' );

kt_add_menu_item( 1969, $menu_id, 0, 'Jewelry & Watches', 'product_cat', 98, 'taxonomy', 'http://kutethemes.net/sample-data/kuteshop/default/product-category/jewelry/jewelry-watches/', '', '0', '2044' );

kt_add_menu_item( 1971, $menu_id, 0, 'Flashlights & Lamps', 'product_cat', 91, 'taxonomy', 'http://kutethemes.net/sample-data/kuteshop/default/product-category/electronic/flashlights-lamps/', '', '0', '2042' );

kt_add_menu_item( 1972, $menu_id, 0, 'Cameras & Photo', 'product_cat', 136, 'taxonomy', 'http://kutethemes.net/sample-data/kuteshop/default/product-category/digital/cameras-photo/', '', '0', '2048' );

kt_add_menu_item( 1973, $menu_id, 0, 'Television', 'product_cat', 118, 'taxonomy', 'http://kutethemes.net/sample-data/kuteshop/default/product-category/digital/television-2/', '', '0', '2041' );

kt_add_menu_item( 1974, $menu_id, 0, 'Fashion', 'product_cat', 90, 'taxonomy', 'http://kutethemes.net/sample-data/kuteshop/default/product-category/fashion/', '', '0', '2043' );
