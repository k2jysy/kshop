<?php
kt_download_media(2245, '7', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/7.jpg');

kt_download_media(2246, '8', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/8.jpg');

kt_download_media(2247, '9', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/9.jpg');

kt_download_media(2248, '10', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/10.jpg');

kt_download_media(2249, '11', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/11.jpg');

kt_download_media(2250, '12', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/12.jpg');
