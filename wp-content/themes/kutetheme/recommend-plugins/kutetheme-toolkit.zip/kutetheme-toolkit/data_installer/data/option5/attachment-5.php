<?php
kt_download_media(1314, 'S3', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/S31.jpg');

kt_download_media(1315, 'S5', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/S5.jpg');

kt_download_media(1325, 'R2', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/R21.jpg');

kt_download_media(1326, 'R3', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/R31.jpg');

kt_download_media(1327, 'R5', 'http://kutethemes.net/wordpress/kuteshop/option5/wp-content/uploads/2015/08/R5.jpg');
