<?php
kt_download_media(2346, 'testimonial', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/testimonial.jpg');

kt_download_media(2352, 'banner-megamenu', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/10/banner-megamenu.jpg');

kt_download_media(2398, 'category-slide', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/10/category-slide.jpg');

kt_download_media(2399, 'slide-cart2', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/10/slide-cart2.jpg');

kt_download_media(2453, 'bg1', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/10/bg1.png');

kt_download_media(2454, 'bg2', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/10/bg2.png');

kt_download_media(2455, 'bg3', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/10/bg3.png');

kt_download_media(2456, 'bg4', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/10/bg4.png');

kt_download_media(2474, 'television', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/12/television.png');