<?php
// Custom term
kt_add_category( 11, '1.5 pixel', '1-5-pixel', 'pa_pixel', '0', '' );

kt_add_category( 14, '2 pixel', '2-pixel', 'pa_pixel', '0', '' );

kt_add_category( 18, '34', '34', 'pa_size', '0', '' );

kt_add_category( 19, '35', '35', 'pa_size', '0', '' );

kt_add_category( 20, '36', '36', 'pa_size', '0', '' );

kt_add_category( 21, '37', '37', 'pa_size', '0', '' );

kt_add_category( 26, 'active', 'active', 'product_tag', '0', '' );

kt_add_category( 27, 'actual', 'actual', 'product_tag', '0', '' );

kt_add_category( 28, 'adf', 'adf', 'product_tag', '0', '' );

kt_add_brand( 29, 'Ame', 'ame', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_category( 30, 'auto', 'auto', 'product_tag', '0', '' );

kt_add_category( 31, 'beauty', 'beauty', 'product_tag', '0', '' );

kt_add_category( 186, 'Black', 'black', 'pa_color', '0', '' );

kt_add_category( 32, 'Blue', 'blue', 'pa_color', '0', '' );

kt_add_category( 33, 'chance', 'chance', 'product_tag', '0', '' );

kt_add_brand( 34, 'Chanee', 'chanee', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_brand( 35, 'Chanleno', 'chanleno', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_category( 36, 'charming', 'charming', 'product_tag', '0', '' );

kt_add_category( 37, 'colorful', 'colorful', 'product_tag', '0', '' );

kt_add_category( 38, 'comfort', 'comfort', 'product_tag', '0', '' );

kt_add_category( 39, 'cooker', 'cooker', 'product_tag', '0', '' );

kt_add_category( 41, 'Diamond', 'diamond', 'pa_material', '0', '' );

kt_add_category( 5, 'external', 'external', 'product_type', '0', '' );

kt_add_category( 188, 'Fabric', 'fabric', 'pa_material', '0', '' );

kt_add_category( 42, 'Gold', 'gold', 'pa_material', '0', '' );

kt_add_category( 43, 'Green', 'green', 'pa_color', '0', '' );

kt_add_category( 44, 'Grey', 'grey', 'pa_color', '0', '' );

kt_add_category( 3, 'grouped', 'grouped', 'product_type', '0', '' );

kt_add_brand( 45, 'Hermee', 'hermee', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_category( 187, 'Leather', 'leather', 'pa_material', '0', '' );

kt_add_category( 49, 'long', 'long', 'product_tag', '0', '' );

kt_add_brand( 50, 'Lorea', 'lorea', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_category( 51, 'M', 'm', 'pa_size', '0', '' );

kt_add_brand( 52, 'Mamypokon', 'mamypokon', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_category( 53, 'Maroon', 'maroon', 'pa_color', '0', '' );

kt_add_category( 54, 'Metal', 'metal', 'pa_material', '0', '' );

kt_add_category( 55, 'modern', 'modern', 'product_tag', '0', '' );

kt_add_category( 56, 'moving', 'moving', 'product_tag', '0', '' );

kt_add_category( 57, 'new', 'new', 'product_tag', '0', '' );

kt_add_category( 58, 'Orange', 'orange', 'pa_color', '0', '' );

kt_add_brand( 59, 'Pamperson', 'pamperson', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_category( 60, 'pearl', 'pearl', 'product_tag', '0', '' );

kt_add_category( 61, 'Pearl', 'pearl', 'pa_material', '0', '' );

kt_add_category( 62, 'picture', 'picture', 'product_tag', '0', '' );

kt_add_category( 63, 'Pink', 'pink', 'pa_color', '0', '' );

kt_add_category( 64, 'Plastic', 'plastic', 'pa_material', '0', '' );

kt_add_category( 65, 'playing', 'playing', 'product_tag', '0', '' );

kt_add_category( 66, 'pretty', 'pretty', 'product_tag', '0', '' );

kt_add_brand( 67, 'Pumano', 'pumano', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_category( 68, 'Red', 'red', 'pa_color', '0', '' );

kt_add_category( 69, 'Ruby', 'ruby', 'pa_material', '0', '' );

kt_add_category( 70, 'Ruby', 'ruby', 'product_tag', '0', '' );

kt_add_category( 71, 'S', 's', 'pa_size', '0', '' );

kt_add_category( 72, 'sexy', 'sexy', 'product_tag', '0', '' );

kt_add_category( 73, 'short', 'short', 'product_tag', '0', '' );

kt_add_category( 74, 'Silver', 'silver', 'pa_material', '0', '' );

kt_add_category( 2, 'simple', 'simple', 'product_type', '0', '' );

kt_add_category( 75, 'style', 'style', 'product_tag', '0', '' );

kt_add_brand( 76, 'Super', 'super', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_category( 77, 'transparent', 'transparent', 'product_tag', '0', '' );

kt_add_category( 4, 'variable', 'variable', 'product_type', '0', '' );

kt_add_category( 40, 'Violet', 'violet', 'pa_color', '0', '' );

kt_add_category( 78, 'wash', 'wash', 'product_tag', '0', '' );

kt_add_category( 79, 'women', 'women', 'product_tag', '0', '' );

kt_add_category( 80, 'Woo', 'woo', 'product_tag', '0', '' );

kt_add_category( 82, 'X', 'x', 'pa_size', '0', '' );

kt_add_category( 83, 'XL', 'xl', 'pa_size', '0', '' );

kt_add_category( 84, 'XS', 'xs', 'pa_size', '0', '' );

kt_add_category( 85, 'XXL', 'xxl', 'pa_size', '0', '' );

kt_add_category( 86, 'XXS', 'xxs', 'pa_size', '0', '' );

kt_add_category( 87, 'Yellow', 'yellow', 'pa_color', '0', '' );

kt_add_product_cat( 203, 'Access', 'access', 'product_cat', '0', '', '0' );

kt_add_product_cat( 204, 'Bags', 'bags', 'product_cat', '0', '', '0' );

kt_add_product_cat( 205, 'Beauty', 'beauty', 'product_cat', '0', '', '0' );

kt_add_product_cat( 88, 'Digital', 'digital', 'product_cat', '0', '', '0' );

kt_add_product_cat( 90, 'Fashion', 'fashion', 'product_cat', '0', '', '0' );

kt_add_product_cat( 92, 'Foods', 'foods', 'product_cat', '0', '', '' );

kt_add_product_cat( 93, 'Furniture', 'furniture', 'product_cat', '0', '', '0' );

kt_add_product_cat( 201, 'Glasses', 'glasses', 'product_cat', '0', '', '0' );

kt_add_product_cat( 95, 'Health &amp; Beauty Bags', 'health-beauty-bags', 'product_cat', '90', '', '' );

kt_add_product_cat( 97, 'Jewelry', 'jewelry', 'product_cat', '0', '', '0' );

kt_add_product_cat( 99, 'Kid\'s', 'kids', 'product_cat', '90', '', '' );

kt_add_product_cat( 100, 'Laptop', 'laptop', 'product_cat', '88', '', '' );

kt_add_product_cat( 101, 'Loveseats', 'loveseats', 'product_cat', '93', '', '' );

kt_add_product_cat( 103, 'Men\'s', 'mens', 'product_cat', '90', '', '' );

kt_add_product_cat( 104, 'Mobile', 'mobile', 'product_cat', '88', '', '' );

kt_add_product_cat( 107, 'Notebook', 'notebook', 'product_cat', '88', '', '' );

kt_add_product_cat( 108, 'Office Furniture', 'office-furniture', 'product_cat', '93', '', '' );

kt_add_product_cat( 109, 'Pearl Jewelry', 'pearl-jewelry', 'product_cat', '97', '', '' );

kt_add_product_cat( 110, 'Scarves', 'scarves', 'product_cat', '90', '', '' );

kt_add_product_cat( 111, 'Shoes &amp; Accessories', 'shoes-accessories', 'product_cat', '90', '', '' );

kt_add_product_cat( 199, 'Shoes and Bags', 'shoes-and-bags', 'product_cat', '0', '', '0' );

kt_add_product_cat( 112, 'Skirts', 'skirts', 'product_cat', '103', '', '' );

kt_add_product_cat( 113, 'Smartphone &amp; Tablets', 'smartphone-tablets', 'product_cat', '88', '', '' );

kt_add_product_cat( 89, 'Source', 'source', 'product_cat', '0', '', '0' );

kt_add_product_cat( 114, 'Sport &amp; Outdoors', 'sport-outdoor', 'product_cat', '0', '', '' );

kt_add_product_cat( 115, 'Sports', 'sports', 'product_cat', '114', '', '0' );

kt_add_product_cat( 116, 'Swimming', 'swimming', 'product_cat', '115', '', '' );

kt_add_product_cat( 117, 'T_Shirt', 't_shirt', 'product_cat', '90', '', '' );

kt_add_product_cat( 118, 'Television', 'television-2', 'product_cat', '88', '', '' );

kt_add_product_cat( 119, 'Tennis', 'tennis', 'product_cat', '115', '', '' );

kt_add_product_cat( 121, 'Tops', 'tops', 'product_cat', '103', '', '' );

kt_add_product_cat( 122, 'Toys &amp; Hobbies', 'toys-hobbies', 'product_cat', '0', '', '' );

kt_add_product_cat( 123, 'Trending', 'trending', 'product_cat', '90', '', '' );

kt_add_product_cat( 126, 'Women\'s', 'womens', 'product_cat', '90', '', '' );

kt_add_product_cat( 127, 'Accessories', 'accessories', 'product_cat', '97', '', '' );

kt_add_product_cat( 134, 'Bedding', 'bedding', 'product_cat', '93', '', '' );

kt_add_product_cat( 136, 'Cameras &amp; Photo', 'cameras-photo', 'product_cat', '88', '', '' );

kt_add_product_cat( 138, 'Chairs &amp; Recliners', 'chairs-recliners', 'product_cat', '93', '', '' );

kt_add_product_cat( 139, 'Climbing', 'climbing', 'product_cat', '115', '', '' );

kt_add_product_cat( 140, 'Computers &amp; Networking', 'computers-networking', 'product_cat', '88', '', '' );

kt_add_product_cat( 141, 'Diamond Jewelry', 'diamond-jewelry', 'product_cat', '97', '', '' );

kt_add_product_cat( 144, 'Football', 'football', 'product_cat', '115', '', '' );

kt_add_product_cat( 146, 'Gold Jewelry', 'gold-jewelry', 'product_cat', '97', '', '' );

