<?php

//Menu
$menu_id = kt_add_menu( 180, 'SAUSAGES', '' );

 // Menu Item
kt_add_menu_item( 1886, $menu_id, 0, 'Meat Dishes', 'custom', 1886, 'custom', '#', '', '', '' );

kt_add_menu_item( 1887, $menu_id, 0, 'Desserts', 'custom', 1887, 'custom', '#', '', '', '' );

kt_add_menu_item( 1901, $menu_id, 0, 'Tops', 'custom', 1901, 'custom', '#', '', '', '' );

kt_add_menu_item( 1902, $menu_id, 0, 'Tops', 'custom', 1902, 'custom', '#', '', '', '' );

