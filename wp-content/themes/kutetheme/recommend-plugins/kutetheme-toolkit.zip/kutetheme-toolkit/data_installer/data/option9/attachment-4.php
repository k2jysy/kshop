<?php
kt_download_media(98, '23', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/23.jpg');

kt_download_media(99, '24', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/24.jpg');

kt_download_media(107, '8 - Copy', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/8-Copy.jpg');

kt_download_media(108, '25', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/25.jpg');

kt_download_media(109, '26', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/26.jpg');
