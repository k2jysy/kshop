<?php // Tag
kt_add_category(207,'Buy','buy','post_tag','0','');

kt_add_category(206,'Celebrity','celebrity','post_tag','0','');

kt_add_category(208,'Concert','concert','post_tag','0','');

kt_add_category(214,'fashion','fashion','post_tag','0','');

kt_add_category(205,'Hair','hair','post_tag','0','');

kt_add_category(209,'Hungrier','hungrier','post_tag','0','');

kt_add_category(202,'Meal','meal','post_tag','0','');

kt_add_category(210,'omnis','omnis','post_tag','0','');

kt_add_category(203,'Plus','plus','post_tag','0','');

kt_add_category(204,'Rings','rings','post_tag','0','');

kt_add_category(213,'Share','share','post_tag','0','');

kt_add_category(211,'shop','shop','post_tag','0','');

kt_add_category(212,'summer','summer','post_tag','0','');
