<?php
kt_download_media(1963, 'i 38', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/i-38.jpg');

kt_download_media(1965, 'i 35', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/i-35.jpg');

kt_download_media(1966, 'i 33', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/i-33.jpg');

kt_download_media(1967, 'i 34', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/i-34.jpg');

kt_download_media(2004, '10', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/10.jpg');

kt_download_media(2005, '13', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/13.jpg');
