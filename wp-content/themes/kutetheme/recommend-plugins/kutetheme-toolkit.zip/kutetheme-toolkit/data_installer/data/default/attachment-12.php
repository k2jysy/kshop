<?php
kt_download_media(2049, 'toys', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/12/toys.png');

kt_download_media(2050, 'P11', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/P11.jpg');

kt_download_media(2051, 'ads2', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/ads2.jpg');

kt_download_media(2052, 'ads3', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/ads3.jpg');

kt_download_media(2053, 'ads6', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/ads6.jpg');
