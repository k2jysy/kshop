<?php
//Menu
$menu_id = kt_add_menu( 179, 'Sandwich', '' );

 // Menu Item
kt_add_menu_item( 1906, $menu_id, 0, 'Salad', 'custom', 1906, 'custom', '#', '', '', '' );

kt_add_menu_item( 1907, $menu_id, 0, 'Paste', 'custom', 1907, 'custom', '#', '', '', '' );

kt_add_menu_item( 1908, $menu_id, 0, 'Tops', 'custom', 1908, 'custom', '#', '', '', '' );

kt_add_menu_item( 1909, $menu_id, 0, 'Tops', 'custom', 1909, 'custom', '#', '', '', '' );
