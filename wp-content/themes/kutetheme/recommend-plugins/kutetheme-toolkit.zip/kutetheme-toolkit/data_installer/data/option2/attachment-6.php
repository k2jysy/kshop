<?php
kt_download_media(1262, 'U2', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/U22.jpg');

kt_download_media(1263, 'U4', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/U4.jpg');

kt_download_media(1274, 'U1', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/U1.jpg');

kt_download_media(1283, 'Z1', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/Z11.jpg');

kt_download_media(1284, 'Z3', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/Z31.jpg');

kt_download_media(1285, 'Z4', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/Z4.jpg');
