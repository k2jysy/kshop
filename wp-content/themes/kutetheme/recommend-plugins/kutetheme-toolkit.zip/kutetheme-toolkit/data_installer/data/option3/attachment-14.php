<?php
kt_download_media(2198, 'i 25', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/10/i-25.jpg');

kt_download_media(2210, 'logo3', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/10/logo3.png');

kt_download_media(2212, 'men', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/10/men.png');

kt_download_media(2213, 'women', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/10/women.png');

kt_download_media(2214, 'kid', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/10/kid.png');

kt_download_media(2215, 'trending', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/10/trending.png');

kt_download_media(2217, 'banner-topmenu', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/10/banner-topmenu.jpg');

kt_download_media(2223, 'adv1', 'http://kutethemes.net/wordpress/kuteshop/option3/wp-content/uploads/2015/08/adv1.jpg');
