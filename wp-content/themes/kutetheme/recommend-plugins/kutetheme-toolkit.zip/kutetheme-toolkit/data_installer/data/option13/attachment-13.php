<?php
kt_download_media(2127, '58', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/58.jpg');

kt_download_media(2128, '59', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/59.jpg');

kt_download_media(2129, '60', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/60.jpg');

kt_download_media(2130, '61', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/61.jpg');

kt_download_media(2131, '62', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/62.jpg');

kt_download_media(2132, '63', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/63.jpg');

kt_download_media(2135, '35', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/351.jpg');
