<?php
// Custom term
kt_add_category( 11, '1.5 pixel', '1-5-pixel', 'pa_pixel', '0', '' );

kt_add_category( 12, '2 pixel', '2-pixel', 'pa_pixel', '0', '' );

kt_add_category( 13, '34', '34', 'pa_size', '0', '' );

kt_add_category( 14, '35', '35', 'pa_size', '0', '' );

kt_add_category( 15, '36', '36', 'pa_size', '0', '' );

kt_add_category( 16, '37', '37', 'pa_size', '0', '' );

kt_add_category( 17, 'active', 'active', 'product_tag', '0', '' );

kt_add_category( 18, 'actual', 'actual', 'product_tag', '0', '' );

kt_add_category( 19, 'adf', 'adf', 'product_tag', '0', '' );

kt_add_brand( 20, 'Ame', 'ame', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_category( 21, 'auto', 'auto', 'product_tag', '0', '' );

kt_add_category( 22, 'beauty', 'beauty', 'product_tag', '0', '' );

kt_add_category( 177, 'Black', 'black', 'pa_color', '0', '' );

kt_add_category( 178, 'Blue', 'blue', 'pa_color', '0', '' );

kt_add_category( 185, 'Brown', 'brown', 'pa_color', '0', '' );

kt_add_category( 25, 'chance', 'chance', 'product_tag', '0', '' );

kt_add_brand( 26, 'Chanee', 'chanee', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_brand( 27, 'Chanleno', 'chanleno', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_category( 28, 'charming', 'charming', 'product_tag', '0', '' );

kt_add_category( 29, 'colorful', 'colorful', 'product_tag', '0', '' );

kt_add_category( 30, 'comfort', 'comfort', 'product_tag', '0', '' );

kt_add_category( 31, 'cooker', 'cooker', 'product_tag', '0', '' );

kt_add_category( 32, 'Diamond', 'diamond', 'pa_material', '0', '' );

kt_add_category( 5, 'external', 'external', 'product_type', '0', '' );

kt_add_category( 33, 'Fabric', 'fabric', 'pa_material', '0', '' );

kt_add_category( 34, 'Gold', 'gold', 'pa_material', '0', '' );

kt_add_category( 179, 'Gray', 'gray', 'pa_color', '0', '' );

kt_add_category( 180, 'Green', 'green', 'pa_color', '0', '' );

kt_add_category( 3, 'grouped', 'grouped', 'product_type', '0', '' );

kt_add_brand( 37, 'Hermee', 'hermee', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_category( 38, 'Leather', 'leather', 'pa_material', '0', '' );

kt_add_category( 39, 'long', 'long', 'product_tag', '0', '' );

kt_add_brand( 40, 'Lorea', 'lorea', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_category( 41, 'M', 'm', 'pa_size', '0', '' );

kt_add_brand( 42, 'Mamypokon', 'mamypokon', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_category( 44, 'Metal', 'metal', 'pa_material', '0', '' );

kt_add_category( 45, 'modern', 'modern', 'product_tag', '0', '' );

kt_add_category( 46, 'moving', 'moving', 'product_tag', '0', '' );

kt_add_category( 47, 'new', 'new', 'product_tag', '0', '' );

kt_add_category( 181, 'Orange', 'orange', 'pa_color', '0', '' );

kt_add_brand( 49, 'Pamperson', 'pamperson', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_category( 50, 'pearl', 'pearl', 'product_tag', '0', '' );

kt_add_category( 51, 'Pearl', 'pearl', 'pa_material', '0', '' );

kt_add_category( 52, 'picture', 'picture', 'product_tag', '0', '' );

kt_add_category( 182, 'Pink', 'pink', 'pa_color', '0', '' );

kt_add_category( 54, 'Plastic', 'plastic', 'pa_material', '0', '' );

kt_add_category( 55, 'playing', 'playing', 'product_tag', '0', '' );

kt_add_category( 56, 'pretty', 'pretty', 'product_tag', '0', '' );

kt_add_brand( 57, 'Pumano', 'pumano', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_category( 183, 'Red', 'red', 'pa_color', '0', '' );

kt_add_category( 59, 'Ruby', 'ruby', 'pa_material', '0', '' );

kt_add_category( 60, 'Ruby', 'ruby', 'product_tag', '0', '' );

kt_add_category( 61, 'S', 's', 'pa_size', '0', '' );

kt_add_category( 62, 'sexy', 'sexy', 'product_tag', '0', '' );

kt_add_category( 63, 'short', 'short', 'product_tag', '0', '' );

kt_add_category( 64, 'Silver', 'silver', 'pa_material', '0', '' );

kt_add_category( 2, 'simple', 'simple', 'product_type', '0', '' );

kt_add_category( 65, 'style', 'style', 'product_tag', '0', '' );

kt_add_brand( 66, 'Super', 'super', 'product_brand', '0', 'Whatever the occasion, complete your outfit with one of Hermes Fashionâ€™s stylish womenâ€™s bags. Discover our spring collection.', '' );

kt_add_category( 67, 'transparent', 'transparent', 'product_tag', '0', '' );

kt_add_category( 4, 'variable', 'variable', 'product_type', '0', '' );

kt_add_category( 186, 'Violet', 'violet', 'pa_color', '0', '' );

kt_add_category( 69, 'wash', 'wash', 'product_tag', '0', '' );

kt_add_category( 70, 'women', 'women', 'product_tag', '0', '' );

kt_add_category( 71, 'Woo', 'woo', 'product_tag', '0', '' );

kt_add_category( 72, 'X', 'x', 'pa_size', '0', '' );

kt_add_category( 73, 'XL', 'xl', 'pa_size', '0', '' );

kt_add_category( 74, 'XS', 'xs', 'pa_size', '0', '' );

kt_add_category( 75, 'XXL', 'xxl', 'pa_size', '0', '' );

kt_add_category( 76, 'XXS', 'xxs', 'pa_size', '0', '' );

kt_add_category( 184, 'Yellow', 'yellow', 'pa_color', '0', '' );

kt_add_product_cat( 189, 'Access', 'access', 'product_cat', '0', '', '0' );

kt_add_product_cat( 191, 'Bags', 'bags', 'product_cat', '0', '', '0' );

kt_add_product_cat( 192, 'Beauty', 'beauty', 'product_cat', '0', '', '0' );

kt_add_product_cat( 78, 'Digital', 'digital', 'product_cat', '0', '', '0' );

kt_add_product_cat( 79, 'Electronic', 'electronic', 'product_cat', '0', '', '' );

kt_add_product_cat( 80, 'Fashion', 'fashion', 'product_cat', '0', '', '0' );

kt_add_product_cat( 82, 'Foods', 'foods', 'product_cat', '0', '', '' );

kt_add_product_cat( 83, 'Furniture', 'furniture', 'product_cat', '0', '', '0' );

kt_add_product_cat( 188, 'Glasses', 'glasses', 'product_cat', '0', '', '0' );

kt_add_product_cat( 85, 'Health &amp; Beauty Bags', 'health-beauty-bags', 'product_cat', '80', '', '' );

kt_add_product_cat( 87, 'Jewelry', 'jewelry', 'product_cat', '0', '', '0' );

kt_add_product_cat( 89, 'Kid\'s', 'kids', 'product_cat', '80', '', '' );

kt_add_product_cat( 90, 'Laptop', 'laptop', 'product_cat', '78', '', '' );

kt_add_product_cat( 91, 'Loveseats', 'loveseats', 'product_cat', '83', '', '' );

kt_add_product_cat( 93, 'Men\'s', 'mens', 'product_cat', '80', '', '' );

kt_add_product_cat( 94, 'Mobile', 'mobile', 'product_cat', '78', '', '' );

kt_add_product_cat( 97, 'Notebook', 'notebook', 'product_cat', '78', '', '' );

kt_add_product_cat( 98, 'Office Furniture', 'office-furniture', 'product_cat', '83', '', '' );

kt_add_product_cat( 99, 'Pearl Jewelry', 'pearl-jewelry', 'product_cat', '87', '', '' );

kt_add_product_cat( 100, 'Scarves', 'scarves', 'product_cat', '80', '', '' );

kt_add_product_cat( 101, 'Shoes &amp; Accessories', 'shoes-accessories', 'product_cat', '80', '', '' );

kt_add_product_cat( 102, 'Shoes and Bags', 'shoes-and-bags', 'product_cat', '0', '', '' );

kt_add_product_cat( 103, 'Skirts', 'skirts', 'product_cat', '93', '', '' );

kt_add_product_cat( 104, 'Smartphone &amp; Tablets', 'smartphone-tablets', 'product_cat', '78', '', '' );

kt_add_product_cat( 190, 'Source', 'source', 'product_cat', '0', '', '0' );

kt_add_product_cat( 105, 'Sport &amp; Outdoors', 'sport-outdoor', 'product_cat', '0', '', '' );

kt_add_product_cat( 106, 'Sports', 'sports', 'product_cat', '105', '', '0' );

kt_add_product_cat( 107, 'Swimming', 'swimming', 'product_cat', '106', '', '' );

kt_add_product_cat( 108, 'T_Shirt', 't_shirt', 'product_cat', '80', '', '' );

kt_add_product_cat( 109, 'Television', 'television-2', 'product_cat', '78', '', '' );

kt_add_product_cat( 110, 'Tennis', 'tennis', 'product_cat', '106', '', '' );

kt_add_product_cat( 112, 'Tops', 'tops', 'product_cat', '93', '', '' );

kt_add_product_cat( 113, 'Toys &amp; Hobbies', 'toys-hobbies', 'product_cat', '0', '', '' );

kt_add_product_cat( 114, 'Trending', 'trending', 'product_cat', '80', '', '' );

kt_add_product_cat( 117, 'Women\'s', 'womens', 'product_cat', '80', '', '' );

kt_add_product_cat( 118, 'Accessories', 'accessories', 'product_cat', '87', '', '' );

kt_add_product_cat( 125, 'Bedding', 'bedding', 'product_cat', '83', '', '' );

kt_add_product_cat( 127, 'Cameras &amp; Photo', 'cameras-photo', 'product_cat', '78', '', '' );

kt_add_product_cat( 129, 'Chairs &amp; Recliners', 'chairs-recliners', 'product_cat', '83', '', '' );

kt_add_product_cat( 130, 'Climbing', 'climbing', 'product_cat', '106', '', '' );

kt_add_product_cat( 131, 'Computers &amp; Networking', 'computers-networking', 'product_cat', '78', '', '' );

kt_add_product_cat( 132, 'Diamond Jewelry', 'diamond-jewelry', 'product_cat', '87', '', '' );

kt_add_product_cat( 135, 'Football', 'football', 'product_cat', '106', '', '' );

kt_add_product_cat( 137, 'Gold Jewelry', 'gold-jewelry', 'product_cat', '87', '', '' );

kt_add_product_cat( 141, 'Jackets', 'jackets', 'product_cat', '93', '', '' );

