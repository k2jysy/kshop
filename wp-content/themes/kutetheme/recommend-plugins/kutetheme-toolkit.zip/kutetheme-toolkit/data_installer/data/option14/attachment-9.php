<?php
kt_download_media(2064, 'blog11', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/08/blog111.jpg');

kt_download_media(2065, 'blog22', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/08/blog22.jpg');

kt_download_media(2066, 'blog31', 'http://kutethemes.net/wordpress/kuteshop/option14/wp-content/uploads/2015/08/blog311.jpg');
