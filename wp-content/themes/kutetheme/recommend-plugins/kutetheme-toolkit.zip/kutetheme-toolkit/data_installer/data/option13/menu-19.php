<?php
//Menu
$menu_id = kt_add_menu( 183, 'Support', '' );

 // Menu Item
kt_add_menu_item( 1920, $menu_id, 0, 'About us', 'custom', 1920, 'custom', '#', '', '', '' );

kt_add_menu_item( 1921, $menu_id, 0, 'Testimonials', 'custom', 1921, 'custom', '#', '', '', '' );

kt_add_menu_item( 1922, $menu_id, 0, 'Affiliate Program', 'custom', 1922, 'custom', '#', '', '', '' );

kt_add_menu_item( 1923, $menu_id, 0, 'Terms & Conditions', 'custom', 1923, 'custom', '#', '', '', '' );

kt_add_menu_item( 1924, $menu_id, 0, 'Contact Us', 'custom', 1924, 'custom', '#', '', '', '' );

//Menu
$menu_id = kt_add_menu( 184, 'Terms &amp; Conditions', '' );

 // Menu Item
kt_add_menu_item( 1953, $menu_id, 0, 'Terms & Conditions', 'custom', 1953, 'custom', '#', '', '', '' );

kt_add_menu_item( 1954, $menu_id, 0, 'Policy', 'custom', 1954, 'custom', '#', '', '', '' );

kt_add_menu_item( 1955, $menu_id, 0, 'Policy', 'custom', 1955, 'custom', '#', '', '', '' );

kt_add_menu_item( 1956, $menu_id, 0, 'Shipping', 'custom', 1956, 'custom', '#', '', '', '' );

kt_add_menu_item( 1957, $menu_id, 0, 'Payments', 'custom', 1957, 'custom', '#', '', '', '' );

kt_add_menu_item( 1958, $menu_id, 0, 'Returns', 'custom', 1958, 'custom', '#', '', '', '' );

kt_add_menu_item( 1959, $menu_id, 0, 'Refunds', 'custom', 1959, 'custom', '#', '', '', '' );

kt_add_menu_item( 1960, $menu_id, 0, 'Warrantee', 'custom', 1960, 'custom', '#', '', '', '' );

kt_add_menu_item( 1961, $menu_id, 0, 'FAQ', 'custom', 1961, 'custom', '#', '', '', '' );

kt_add_menu_item( 1962, $menu_id, 0, 'Contact', 'custom', 1962, 'custom', '#', '', '', '' );
