<?php
kt_download_media(874, 'men', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/men.png');

kt_download_media(875, 'women', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/women.png');

kt_download_media(877, 'trending', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/trending.png');

kt_download_media(878, 'banner-topmenu', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/banner-topmenu.jpg');

kt_download_media(880, 'banner-megamenu', 'http://kutethemes.net/wordpress/kuteshop/option9/wp-content/uploads/2015/12/banner-megamenu.jpg');

