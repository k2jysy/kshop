<?php
kt_download_media(1133, 'icon-s5', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/icon-s5.png');

kt_download_media(1135, 'icon-s2', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/icon-s2.png');

kt_download_media(1137, 'icon-s4', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/icon-s4.png');

kt_download_media(1139, 'icon-s6', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/icon-s6.png');

kt_download_media(1172, 'x-20x20', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/x-20x20.png');

kt_download_media(1173, 'xl-20x20', 'http://kutethemes.net/wordpress/kuteshop/option6/wp-content/uploads/2015/08/xl-20x20.png');
