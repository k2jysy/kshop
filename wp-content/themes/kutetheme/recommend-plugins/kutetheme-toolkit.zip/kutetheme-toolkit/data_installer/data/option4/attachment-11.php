<?php
kt_download_media(2083, '32', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/32.png');

kt_download_media(2084, 'i 9', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/i-9.jpg');

kt_download_media(2085, 'i 10', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/i-10.jpg');

kt_download_media(2086, 'i 7', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/i-7.jpg');

kt_download_media(2087, 'i 11', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/i-11.jpg');

kt_download_media(2088, 'i 31', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/i-31.jpg');

kt_download_media(2089, 'i 42', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/i-42.jpg');

kt_download_media(2090, 'i 8', 'http://kutethemes.net/wordpress/kuteshop/option4/wp-content/uploads/2015/08/i-8.jpg');
