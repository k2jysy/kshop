<?php
kt_download_media(2258, '20', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/20.jpg');

kt_download_media(2259, '21', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/211.jpg');

kt_download_media(2260, '22', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/22.jpg');

kt_download_media(2261, '23', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/23.jpg');

kt_download_media(2262, '24jpg', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/24jpg.jpg');

kt_download_media(2263, '25', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/25.jpg');

kt_download_media(2264, '26', 'http://kutethemes.net/wordpress/kuteshop/option7/wp-content/uploads/2015/08/26.jpg');
