<?php
//Menu
$menu_id = kt_add_menu( 63, 'Euro', '' );

 // Menu Item
kt_add_menu_item( 891, $menu_id, 0, 'Greek Potatoes', 'custom', 891, 'custom', '#', '', '0', '' );

kt_add_menu_item( 892, $menu_id, 0, 'Famous Spaghetti', 'custom', 892, 'custom', '#', '', '0', '' );

kt_add_menu_item( 893, $menu_id, 0, 'Famous Noodles', 'custom', 893, 'custom', '#', '', '0', '' );
