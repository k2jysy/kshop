<?php

//Menu
$menu_id = kt_add_menu( 161, 'Company Info - Partnerships', '' );

 // Menu Item
kt_add_menu_item( 1935, $menu_id, 0, 'Company Info - Partnerships', 'custom', 1935, 'custom', '#', '', '', '' );
