<?php
kt_download_media(2085, 'ld4', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/10/ld4.jpg');

kt_download_media(2086, 'logo2', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/12/logo2.png');

kt_download_media(2087, 'icon-digital', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/icon-digital.png');

kt_download_media(2088, 'icon-fashion', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/icon-fashion.png');

kt_download_media(2089, 'icon-electronic', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/icon-electronic.png');

kt_download_media(2090, 'icon-jewelry', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/icon-jewelry.png');
