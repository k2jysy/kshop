<?php
kt_download_media(2180, 'b1', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/08/b11.png');

kt_download_media(2183, 'logo', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/12/logo.png');

kt_download_media(2191, 'icon-new', 'http://kutethemes.net/wordpress/kuteshop/option12/wp-content/uploads/2015/12/icon-new.png');
