<?php
kt_download_media(1876, 'trademark-ups', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/10/trademark-ups.jpg');

kt_download_media(1877, 'trademark-visa', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/10/trademark-visa.jpg');

kt_download_media(1878, 'trademark-wm', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/10/trademark-wm.jpg');

kt_download_media(1879, 'trademark-wu', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/10/trademark-wu.jpg');

kt_download_media(1880, 's1', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/s1.png');

kt_download_media(1881, 's2', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/s2.png');
