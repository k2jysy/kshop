<?php
// Attachment
kt_download_media(6, 'logo', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/logo.png');

kt_download_media(26, '12', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/12.png');

kt_download_media(27, '13', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/13.png');

kt_download_media(28, '14', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/14.png');

kt_download_media(29, '15', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/15.png');

kt_download_media(30, '16', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/16.png');

kt_download_media(31, '17', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/17.png');

kt_download_media(32, '18', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/18.png');

kt_download_media(33, '19', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/19.png');

kt_download_media(34, '20', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/20.png');

kt_download_media(35, '21', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/21.png');

kt_download_media(36, '22', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/22.png');
