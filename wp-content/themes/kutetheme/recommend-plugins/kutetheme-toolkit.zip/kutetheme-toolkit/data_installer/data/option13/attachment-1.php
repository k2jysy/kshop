<?php
// Attachment
kt_download_media(2003, '1', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/1.jpg');

kt_download_media(2004, '2', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/2.jpg');

kt_download_media(2005, '3', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/3.jpg');

kt_download_media(2006, '4', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/4.jpg');

kt_download_media(2272, '22', 'http://kutethemes.net/wordpress/kuteshop/option13/wp-content/uploads/2015/08/22.jpg');
