<?php
//Menu
$menu_id = kt_add_menu( 166, 'Fast', '' );

 // Menu Item
kt_add_menu_item( 1903, $menu_id, 0, 'Hamberger', 'custom', 1903, 'custom', '#', '', '', '' );

kt_add_menu_item( 1904, $menu_id, 0, 'Pizza', 'custom', 1904, 'custom', '#', '', '', '' );

kt_add_menu_item( 1905, $menu_id, 0, 'Noodles', 'custom', 1905, 'custom', '#', '', '', '' );
