<?php
//Menu
$menu_id = kt_add_menu( 62, 'Sausages', '' );

 // Menu Item
kt_add_menu_item( 887, $menu_id, 0, 'Meat Dishes', 'custom', 887, 'custom', '#', '', '0', '' );

kt_add_menu_item( 888, $menu_id, 0, 'Dessert', 'custom', 888, 'custom', '#', '', '0', '' );

kt_add_menu_item( 889, $menu_id, 0, 'Hotdog', 'custom', 889, 'custom', '#', '', '0', '' );

kt_add_menu_item( 890, $menu_id, 0, 'Tops', 'custom', 890, 'custom', '#', '', '0', '' );
