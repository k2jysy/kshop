<?php
kt_download_media(2113, 'blog11', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/blog11.jpg');

kt_download_media(2114, 'blog22', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/blog22.jpg');

kt_download_media(2115, 'blog31', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/blog31.jpg');

kt_download_media(2116, 'blog41', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/blog41.jpg');
