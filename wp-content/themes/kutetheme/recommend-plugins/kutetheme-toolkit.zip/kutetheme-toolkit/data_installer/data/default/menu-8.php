<?php
//Menu
$menu_id = kt_add_menu( 171, 'Main menu', 'primary' );

 // Menu Item
kt_add_menu_item( 1994, $menu_id, 0, 'Home', 'page', 347, 'post_type', 'http://kutethemes.net/sample-data/kuteshop/default/', '', '0', '' );

kt_add_menu_item( 1997, $menu_id, 1994, 'Home 1', 'custom', 1997, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option1/', '', '0', '' );

kt_add_menu_item( 1998, $menu_id, 1994, 'Home 2', 'custom', 1998, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option2/', '', '0', '' );

kt_add_menu_item( 1999, $menu_id, 1994, 'Home 6', 'custom', 1999, 'custom', 'http://kutethemes.net/wordpress/kuteshop/option6/', '', '0', '' );

kt_add_menu_item( 1889, $menu_id, 0, 'Fashion', 'product_cat', 90, 'taxonomy', 'http://kutethemes.net/sample-data/kuteshop/default/product-category/fashion/', 'enabled', '55', '' );

kt_add_menu_item( 1890, $menu_id, 0, 'Foods', 'product_cat', 92, 'taxonomy', 'http://kutethemes.net/sample-data/kuteshop/default/product-category/foods/', 'enabled', '835', '' );

kt_add_menu_item( 1891, $menu_id, 0, 'Sports', 'product_cat', 115, 'taxonomy', 'http://kutethemes.net/sample-data/kuteshop/default/product-category/sport-outdoor/sports/', '', '0', '' );

kt_add_menu_item( 1892, $menu_id, 0, 'Digital', 'product_cat', 88, 'taxonomy', 'http://kutethemes.net/sample-data/kuteshop/default/product-category/digital/', '', '0', '' );

kt_add_menu_item( 1915, $menu_id, 1892, 'Mobile', 'custom', 1915, 'custom', '#', '', '0', '' );

kt_add_menu_item( 1916, $menu_id, 1892, 'Tablets', 'custom', 1916, 'custom', '#', '', '0', '' );

kt_add_menu_item( 1917, $menu_id, 1892, 'Laptop', 'custom', 1917, 'custom', '#', '', '0', '' );

kt_add_menu_item( 1918, $menu_id, 1892, 'Memory Cards', 'custom', 1918, 'custom', '#', '', '0', '' );

kt_add_menu_item( 1919, $menu_id, 1892, 'Accessories', 'custom', 1919, 'custom', '#', '', '0', '' );

kt_add_menu_item( 1893, $menu_id, 0, 'Furniture', 'product_cat', 93, 'taxonomy', 'http://kutethemes.net/sample-data/kuteshop/default/product-category/furniture/', '', '0', '' );

kt_add_menu_item( 1894, $menu_id, 0, 'Jewelry', 'product_cat', 97, 'taxonomy', 'http://kutethemes.net/sample-data/kuteshop/default/product-category/jewelry/', '', '0', '' );

kt_add_menu_item( 1993, $menu_id, 0, 'Blog', 'page', 1188, 'post_type', 'http://kutethemes.net/sample-data/kuteshop/default/sample-page-2/', '', '0', '' );
