<?php
kt_download_media(2064, '4684puantiyeli-klos-elbise7207', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/4684puantiyeli-klos-elbise7207.jpg');

kt_download_media(2065, '4684puantiyeli-klos-elbise8804', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/4684puantiyeli-klos-elbise8804.jpg');

kt_download_media(2066, '4692neopren-gorunumlu-puantiyeli-elbise1358', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/4692neopren-gorunumlu-puantiyeli-elbise1358.jpg');

kt_download_media(2067, '4692neopren-gorunumlu-puantiyeli-elbise5739', 'http://kutethemes.net/wordpress/kuteshop/option8/wp-content/uploads/2015/08/4692neopren-gorunumlu-puantiyeli-elbise5739.jpg');
