<?php

kt_download_media(908, '53', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/53.jpg');

kt_download_media(910, '65', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/65.jpg');

kt_download_media(912, '66', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/66.jpg');

kt_download_media(913, '68', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/68.jpg');

kt_download_media(914, '70', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/70.jpg');

kt_download_media(915, '71', 'http://kutethemes.net/wordpress/kuteshop/option11/wp-content/uploads/2015/12/71.jpg');
