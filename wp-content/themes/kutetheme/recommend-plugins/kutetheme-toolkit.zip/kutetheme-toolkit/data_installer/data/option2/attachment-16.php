<?php
kt_download_media(2118, 'p45', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/p45.jpg');

kt_download_media(2119, 'p63', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/p63.jpg');

kt_download_media(2120, 'p64', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/p64.jpg');

kt_download_media(2121, 'p65', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/p65.jpg');

kt_download_media(2122, 'p66', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/p66.jpg');

kt_download_media(2123, 'p61', 'http://kutethemes.net/wordpress/kuteshop/option2/wp-content/uploads/2015/08/p61.jpg');
