<?php
//Menu
$menu_id = kt_add_menu( 157, 'ASIAN', '' );

 // Menu Item
kt_add_menu_item( 1875, $menu_id, 0, 'Vietnamese Pho', 'custom', 1875, 'custom', '#', '', '', '' );

kt_add_menu_item( 1884, $menu_id, 0, 'Noodles', 'custom', 1884, 'custom', '#', '', '', '' );

kt_add_menu_item( 1885, $menu_id, 0, 'Seafood', 'custom', 1885, 'custom', '#', '', '', '' );

