<?php
kt_download_media(2026, 'i 42', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/i-42.jpg');

kt_download_media(2027, 'i 7', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/i-7.jpg');

kt_download_media(2028, 'i 31', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/i-31.jpg');

kt_download_media(2030, '15', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/15.jpg');

kt_download_media(2031, '16', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/16.jpg');

kt_download_media(2032, '17', 'http://kutethemes.net/sample-data/kuteshop/default/wp-content/uploads/2015/08/17.jpg');
